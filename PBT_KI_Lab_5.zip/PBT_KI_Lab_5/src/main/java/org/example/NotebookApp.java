package org.example;

import org.example.dao.NotebookDAO;
import org.example.entity.Notebook;

import java.util.List;
import java.util.Scanner;

/**
 * Головний клас програми для демонстрації роботи з базою даних блокнотів
 * Містить меню для взаємодії з користувачем та тестові дані
 */
public class NotebookApp {

    private NotebookDAO notebookDAO;
    private Scanner scanner;

    /**
     * Конструктор, який ініціалізує DAO та сканер для вводу
     */
    public NotebookApp() {
        notebookDAO = new NotebookDAO();
        scanner = new Scanner(System.in);
    }

    /**
     * Головний метод програми
     * @param args Аргументи командного рядка (не використовуються)
     */
    public static void main(String[] args) {
        NotebookApp app = new NotebookApp();
        app.run();
    }

    /**
     * Основний цикл роботи програми
     * Відображає меню та обробляє вибір користувача
     */
    public void run() {
        System.out.println("Вітаємо в системі управління базою даних 'Блокнот'!");

        // Додаємо тестові дані для демонстрації
        addSampleData();

        boolean running = true;

        while (running) {
            displayMenu();
            System.out.print("\nОберіть опцію: ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    notebookDAO.connect();
                    break;
                case "2":
                    notebookDAO.disconnect();
                    break;
                case "3":
                    addNewNotebook();
                    break;
                case "4":
                    deleteNotebook();
                    break;
                case "5":
                    updateNotebook();
                    break;
                case "6":
                    showAllNotebooks();
                    break;
                case "7":
                    notebookDAO.showCountriesWithNotebookCount();
                    break;
                case "8":
                    notebookDAO.showManufacturersWithNotebookCount();
                    break;
                case "9":
                    notebookDAO.showCountryWithMostNotebooks();
                    break;
                case "10":
                    notebookDAO.showCountryWithLeastNotebooks();
                    break;
                case "11":
                    notebookDAO.showManufacturerWithMostNotebooks();
                    break;
                case "12":
                    notebookDAO.showManufacturerWithLeastNotebooks();
                    break;
                case "13":
                    showNotebooks(notebookDAO.getHardcoverNotebooks());
                    break;
                case "14":
                    showNotebooks(notebookDAO.getSoftcoverNotebooks());
                    break;
                case "15":
                    showNotebooksByCountry();
                    break;
                case "16":
                    filterByPageAppearance();
                    break;
                case "17":
                    filterByPageCount();
                    break;
                case "18":
                    filterByCirculation();
                    break;
                case "0":
                    running = false;
                    System.out.println("Дякуємо за використання програми! До побачення!");
                    break;
                default:
                    System.err.println("Невірний вибір. Спробуйте ще раз.");
            }

            if (running) {
                System.out.println("\nНатисніть Enter для продовження...");
                scanner.nextLine();
            }
        }

        scanner.close();
    }

    /**
     * Відображення головного меню програми
     */
    private void displayMenu() {
        System.out.println("\n" + "=".repeat(70));
        System.out.println(" СИСТЕМА УПРАВЛІННЯ БАЗОЮ ДАНИХ 'БЛОКНОТ'");
        System.out.println("=".repeat(70));
        System.out.println("1.  Підключитися до бази даних");
        System.out.println("2.  Відключитися від бази даних");
        System.out.println("3.  Додати новий блокнот");
        System.out.println("4.  Видалити інформацію про блокнот");
        System.out.println("5.  Оновити інформацію про блокнот");
        System.out.println("6.  Показати всі блокноти");
        System.out.println("7.  Показати країни-виробники з кількістю блокнотів");
        System.out.println("8.  Показати виробників з кількістю блокнотів");
        System.out.println("9.  Показати країну з найбільшою кількістю блокнотів");
        System.out.println("10. Показати країну з найменшою кількістю блокнотів");
        System.out.println("11. Показати виробника з найбільшою кількістю блокнотів");
        System.out.println("12. Показати виробника з найменшою кількістю блокнотів");
        System.out.println("13. Показати блокноти з твердою обкладинкою");
        System.out.println("14. Показати блокноти з м'якою обкладинкою");
        System.out.println("15. Показати блокноти з конкретної країни");
        System.out.println("16. Фільтр за типом сторінки");
        System.out.println("17. Фільтр за кількістю сторінок");
        System.out.println("18. Фільтр за тиражем");
        System.out.println("0.  Вийти з програми");
        System.out.println("=".repeat(70));
    }

    /**
     * Додавання тестових даних для демонстрації роботи програми
     */
    private void addSampleData() {
        System.out.println("\n Додаємо тестові дані...");

        // Створюємо кілька тестових блокнотів
        Notebook notebook1 = new Notebook(
                "Moleskine", "Classic Notebook", 192,
                Notebook.CoverType.HARD, "Італія", 50000,
                Notebook.PageAppearance.RULER
        );

        Notebook notebook2 = new Notebook(
                "Leuchtturm1917", "Medium A5", 249,
                Notebook.CoverType.SOFT, "Німеччина", 30000,
                Notebook.PageAppearance.CELL
        );

        Notebook notebook3 = new Notebook(
                "Rhodia", "Webbie", 96,
                Notebook.CoverType.SOFT, "Франція", 25000,
                Notebook.PageAppearance.RULER
        );

        Notebook notebook4 = new Notebook(
                "Moleskine", "Pocket Notebook", 80,
                Notebook.CoverType.SOFT, "Італія", 75000,
                Notebook.PageAppearance.EMPTY
        );

        Notebook notebook5 = new Notebook(
                "Paperblanks", "Midnight Sun", 144,
                Notebook.CoverType.HARD, "Ірландія", 15000,
                Notebook.PageAppearance.RULER
        );

        Notebook notebook6 = new Notebook(
                "Leuchtturm1917", "Hardcover A4", 120,
                Notebook.CoverType.HARD, "Німеччина", 20000,
                Notebook.PageAppearance.CELL
        );

        // Додаємо блокноти до бази даних
        notebookDAO.addNotebook(notebook1);
        notebookDAO.addNotebook(notebook2);
        notebookDAO.addNotebook(notebook3);
        notebookDAO.addNotebook(notebook4);
        notebookDAO.addNotebook(notebook5);
        notebookDAO.addNotebook(notebook6);

        System.out.println("Тестові дані успішно додано!");
    }

    /**
     * Додавання нового блокнота через ввід користувача
     */
    private void addNewNotebook() {
        System.out.println("\n➕ ДОДАВАННЯ НОВОГО БЛОКНОТА");

        System.out.print("Назва компанії-виробника: ");
        String companyName = scanner.nextLine();

        System.out.print("Назва/код моделі: ");
        String modelName = scanner.nextLine();

        System.out.print("Кількість сторінок: ");
        int pageCount = Integer.parseInt(scanner.nextLine());

        System.out.print("Тип обкладинки (HARD/SOFT): ");
        Notebook.CoverType coverType = Notebook.CoverType.valueOf(scanner.nextLine().toUpperCase());

        System.out.print("Країна-виробник: ");
        String country = scanner.nextLine();

        System.out.print("Тираж (або Enter для пропуску): ");
        String circulationInput = scanner.nextLine();
        Integer circulation = circulationInput.isEmpty() ? null : Integer.parseInt(circulationInput);

        System.out.print("Тип сторінки (CELL/RULER/EMPTY): ");
        Notebook.PageAppearance pageAppearance = Notebook.PageAppearance.valueOf(scanner.nextLine().toUpperCase());

        Notebook notebook = new Notebook(companyName, modelName, pageCount, coverType, country, circulation, pageAppearance);
        notebookDAO.addNotebook(notebook);
    }

    /**
     * Видалення блокнота за ID
     */
    private void deleteNotebook() {
        System.out.println("\n ВИДАЛЕННЯ БЛОКНОТА");
        showAllNotebooks();

        System.out.print("Введіть ID блокнота для видалення: ");
        Long id = Long.parseLong(scanner.nextLine());

        notebookDAO.deleteNotebook(id);
    }

    /**
     * Оновлення інформації про блокнот
     */
    private void updateNotebook() {
        System.out.println("\n️ ОНОВЛЕННЯ ІНФОРМАЦІЇ ПРО БЛОКНОТ");
        showAllNotebooks();

        System.out.print("Введіть ID блокнота для оновлення: ");
        Long id = Long.parseLong(scanner.nextLine());

        Notebook notebook = notebookDAO.getNotebookById(id);
        if (notebook == null) {
            System.err.println("Блокнот з ID " + id + " не знайдено");
            return;
        }

        System.out.println("Поточні дані: " + notebook);
        System.out.println("\nВведіть нові дані (Enter для залишення поточних):");

        System.out.print("Назва компанії [" + notebook.getCompanyName() + "]: ");
        String companyName = scanner.nextLine();
        if (!companyName.isEmpty()) {
            notebook.setCompanyName(companyName);
        }

        System.out.print("Назва моделі [" + notebook.getModelName() + "]: ");
        String modelName = scanner.nextLine();
        if (!modelName.isEmpty()) {
            notebook.setModelName(modelName);
        }

        System.out.print("Кількість сторінок [" + notebook.getPageCount() + "]: ");
        String pageCountInput = scanner.nextLine();
        if (!pageCountInput.isEmpty()) {
            notebook.setPageCount(Integer.parseInt(pageCountInput));
        }

        System.out.print("Тираж [" + (notebook.getCirculation() != null ? notebook.getCirculation() : "не вказано") + "]: ");
        String circulationInput = scanner.nextLine();
        if (!circulationInput.isEmpty()) {
            notebook.setCirculation(Integer.parseInt(circulationInput));
        }

        notebookDAO.updateNotebook(notebook);
    }

    /**
     * Відображення всіх блокнотів
     */
    private void showAllNotebooks() {
        List<Notebook> notebooks = notebookDAO.getAllNotebooks();
        showNotebooks(notebooks);
    }

    /**
     * Відображення списку блокнотів
     * @param notebooks Список блокнотів для відображення
     */
    private void showNotebooks(List<Notebook> notebooks) {
        if (notebooks.isEmpty()) {
            System.out.println("   Немає блокнотів для відображення");
        } else {
            for (Notebook notebook : notebooks) {
                System.out.println("   " + notebook);
            }
        }
    }

    /**
     * Відображення блокнотів за країною
     */
    private void showNotebooksByCountry() {
        System.out.print("\nВведіть назву країни: ");
        String country = scanner.nextLine();
        List<Notebook> notebooks = notebookDAO.getNotebooksByCountry(country);
        showNotebooks(notebooks);
    }

    /**
     * Фільтрація за типом сторінки
     */
    private void filterByPageAppearance() {
        System.out.println("\n ФІЛЬТР ЗА ТИПОМ СТОРІНКИ");
        System.out.println("Доступні типи: CELL (клітинка), RULER (лінійка), EMPTY (порожня)");
        System.out.print("Введіть тип сторінки: ");
        String type = scanner.nextLine().toUpperCase();

        try {
            Notebook.PageAppearance appearance = Notebook.PageAppearance.valueOf(type);
            List<Notebook> notebooks = notebookDAO.filterByPageAppearance(appearance);
            showNotebooks(notebooks);
        } catch (IllegalArgumentException e) {
            System.err.println("Невірний тип сторінки. Спробуйте CELL, RULER або EMPTY.");
        }
    }

    /**
     * Фільтрація за кількістю сторінок
     */
    private void filterByPageCount() {
        System.out.println("\n ФІЛЬТР ЗА КІЛЬКІСТЮ СТОРІНОК");

        System.out.print("Мінімальна кількість сторінок (або Enter для відсутності обмеження): ");
        String minInput = scanner.nextLine();
        Integer minPages = minInput.isEmpty() ? null : Integer.parseInt(minInput);

        System.out.print("Максимальна кількість сторінок (або Enter для відсутності обмеження): ");
        String maxInput = scanner.nextLine();
        Integer maxPages = maxInput.isEmpty() ? null : Integer.parseInt(maxInput);

        List<Notebook> notebooks = notebookDAO.filterByPageCount(minPages, maxPages);
        showNotebooks(notebooks);
    }

    /**
     * Фільтрація за тиражем
     */
    private void filterByCirculation() {
        System.out.println("\n ФІЛЬТР ЗА ТИРАЖЕМ");

        System.out.print("Мінімальний тираж (або Enter для відсутності обмеження): ");
        String minInput = scanner.nextLine();
        Integer minCirculation = minInput.isEmpty() ? null : Integer.parseInt(minInput);

        System.out.print("Максимальний тираж (або Enter для відсутності обмеження): ");
        String maxInput = scanner.nextLine();
        Integer maxCirculation = maxInput.isEmpty() ? null : Integer.parseInt(maxInput);

        List<Notebook> notebooks = notebookDAO.filterByCirculation(minCirculation, maxCirculation);
        showNotebooks(notebooks);
    }
}