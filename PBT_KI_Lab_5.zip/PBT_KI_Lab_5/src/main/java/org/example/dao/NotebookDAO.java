package org.example.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.example.entity.Notebook;

import java.util.List;

/**
 * Data Access Object (DAO) клас для роботи з сутністю Notebook
 * Відповідає за всі операції з базою даних
 */
public class NotebookDAO {

    private SessionFactory sessionFactory;

    /**
     * Конструктор, який ініціалізує фабрику сесій Hibernate
     * Використовує конфігураційний файл hibernate.cfg.xml
     */
    public NotebookDAO() {
        try {
            sessionFactory = new Configuration().configure().buildSessionFactory();
            System.out.println("Фабрику сесій Hibernate успішно створено");
        } catch (Exception e) {
            System.err.println("Помилка при створенні фабрики сесій: " + e.getMessage());
            throw new RuntimeException("Не вдалося ініціалізувати Hibernate", e);
        }
    }

    /**
     * Підключення до бази даних
     * Фабрика сесій створюється при ініціалізації об'єкта
     */
    public void connect() {
        if (sessionFactory != null && !sessionFactory.isClosed()) {
            System.out.println("Підключення до бази даних активне");
        } else {
            System.err.println("Підключення до бази даних не активне");
        }
    }

    /**
     * Відключення від бази даних
     * Закриває фабрику сесій для коректного завершення роботи
     */
    public void disconnect() {
        if (sessionFactory != null && !sessionFactory.isClosed()) {
            sessionFactory.close();
            System.out.println("Відключення від бази даних виконано успішно");
        }
    }

    /**
     * Додавання нового блокнота до бази даних
     * @param notebook Об'єкт блокнота для збереження
     */
    public void addNotebook(Notebook notebook) {
        Transaction transaction = null;
        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();
            session.save(notebook);
            transaction.commit();
            System.out.println("Блокнот успішно додано до бази даних: " + notebook.getModelName());
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            System.err.println("Помилка при додаванні блокнота: " + e.getMessage());
        }
    }

    /**
     * Видалення інформації про існуючий блокнот
     * @param id Унікальний ідентифікатор блокнота для видалення
     */
    public void deleteNotebook(Long id) {
        Transaction transaction = null;
        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();
            Notebook notebook = session.get(Notebook.class, id);
            if (notebook != null) {
                session.delete(notebook);
                transaction.commit();
                System.out.println("Блокнот з ID " + id + " успішно видалено");
            } else {
                System.err.println("Блокнот з ID " + id + " не знайдено");
            }
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            System.err.println("Помилка при видаленні блокнота: " + e.getMessage());
        }
    }

    /**
     * Оновлення інформації про блокнот
     * @param notebook Оновлений об'єкт блокнота
     */
    public void updateNotebook(Notebook notebook) {
        Transaction transaction = null;
        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();
            session.update(notebook);
            transaction.commit();
            System.out.println("Інформацію про блокнот оновлено: " + notebook.getModelName());
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            System.err.println("Помилка при оновленні блокнота: " + e.getMessage());
        }
    }

    /**
     * Показати всі блокноти в базі даних
     * @return Список всіх блокнотів
     */
    public List<Notebook> getAllNotebooks() {
        try (Session session = sessionFactory.openSession()) {
            Query<Notebook> query = session.createQuery("FROM Notebook", Notebook.class);
            List<Notebook> notebooks = query.list();
            System.out.println("Знайдено блокнотів: " + notebooks.size());
            return notebooks;
        } catch (Exception e) {
            System.err.println("Помилка при отриманні списку блокнотів: " + e.getMessage());
            return List.of();
        }
    }

    /**
     * Показати всі країни-виробники з кількістю блокнотів кожної країни
     * Використовує HQL для групування даних
     */
    public void showCountriesWithNotebookCount() {
        try (Session session = sessionFactory.openSession()) {
            Query<Object[]> query = session.createQuery(
                    "SELECT n.manufacturerCountry, COUNT(n) FROM Notebook n GROUP BY n.manufacturerCountry",
                    Object[].class
            );
            List<Object[]> results = query.list();

            System.out.println("\n Країни-виробники та кількість блокнотів:");
            if (results.isEmpty()) {
                System.out.println("   Немає даних для відображення");
            } else {
                for (Object[] result : results) {
                    System.out.printf("   %s: %d блокнотів\n", result[0], result[1]);
                }
            }
        } catch (Exception e) {
            System.err.println("Помилка при отриманні статистики по країнах: " + e.getMessage());
        }
    }

    /**
     * Показати назви виробників та кількість блокнотів кожного виробника
     */
    public void showManufacturersWithNotebookCount() {
        try (Session session = sessionFactory.openSession()) {
            Query<Object[]> query = session.createQuery(
                    "SELECT n.companyName, COUNT(n) FROM Notebook n GROUP BY n.companyName",
                    Object[].class
            );
            List<Object[]> results = query.list();

            System.out.println("\n Виробники та кількість блокнотів:");
            if (results.isEmpty()) {
                System.out.println("   Немає даних для відображення");
            } else {
                for (Object[] result : results) {
                    System.out.printf("   %s: %d блокнотів\n", result[0], result[1]);
                }
            }
        } catch (Exception e) {
            System.err.println("Помилка при отриманні статистики по виробникам: " + e.getMessage());
        }
    }

    /**
     * Показати країну з найбільшою кількістю блокнотів
     */
    public void showCountryWithMostNotebooks() {
        try (Session session = sessionFactory.openSession()) {
            Query<Object[]> query = session.createQuery(
                    "SELECT n.manufacturerCountry, COUNT(n) as count FROM Notebook n " +
                            "GROUP BY n.manufacturerCountry ORDER BY count DESC",
                    Object[].class
            );
            query.setMaxResults(1);
            List<Object[]> results = query.list();

            System.out.println("\n Країна з найбільшою кількістю блокнотів:");
            if (!results.isEmpty()) {
                Object[] result = results.get(0);
                System.out.printf("   %s: %d блокнотів\n", result[0], result[1]);
            } else {
                System.out.println("   Немає даних для відображення");
            }
        } catch (Exception e) {
            System.err.println("Помилка при пошуку країни з найбільшою кількістю блокнотів: " + e.getMessage());
        }
    }

    /**
     * Показати країну з найменшою кількістю блокнотів
     */
    public void showCountryWithLeastNotebooks() {
        try (Session session = sessionFactory.openSession()) {
            Query<Object[]> query = session.createQuery(
                    "SELECT n.manufacturerCountry, COUNT(n) as count FROM Notebook n " +
                            "GROUP BY n.manufacturerCountry ORDER BY count ASC",
                    Object[].class
            );
            query.setMaxResults(1);
            List<Object[]> results = query.list();

            System.out.println("\n Країна з найменшою кількістю блокнотів:");
            if (!results.isEmpty()) {
                Object[] result = results.get(0);
                System.out.printf("   %s: %d блокнотів\n", result[0], result[1]);
            } else {
                System.out.println("   Немає даних для відображення");
            }
        } catch (Exception e) {
            System.err.println("Помилка при пошуку країни з найменшою кількістю блокнотів: " + e.getMessage());
        }
    }

    /**
     * Показати виробника з найбільшою кількістю блокнотів
     */
    public void showManufacturerWithMostNotebooks() {
        try (Session session = sessionFactory.openSession()) {
            Query<Object[]> query = session.createQuery(
                    "SELECT n.companyName, COUNT(n) as count FROM Notebook n " +
                            "GROUP BY n.companyName ORDER BY count DESC",
                    Object[].class
            );
            query.setMaxResults(1);
            List<Object[]> results = query.list();

            System.out.println("\n Виробник з найбільшою кількістю блокнотів:");
            if (!results.isEmpty()) {
                Object[] result = results.get(0);
                System.out.printf("   %s: %d блокнотів\n", result[0], result[1]);
            } else {
                System.out.println("   Немає даних для відображення");
            }
        } catch (Exception e) {
            System.err.println("Помилка при пошуку виробника з найбільшою кількістю блокнотів: " + e.getMessage());
        }
    }

    /**
     * Показати виробника з найменшою кількістю блокнотів
     */
    public void showManufacturerWithLeastNotebooks() {
        try (Session session = sessionFactory.openSession()) {
            Query<Object[]> query = session.createQuery(
                    "SELECT n.companyName, COUNT(n) as count FROM Notebook n " +
                            "GROUP BY n.companyName ORDER BY count ASC",
                    Object[].class
            );
            query.setMaxResults(1);
            List<Object[]> results = query.list();

            System.out.println("\n Виробник з найменшою кількістю блокнотів:");
            if (!results.isEmpty()) {
                Object[] result = results.get(0);
                System.out.printf("   %s: %d блокнотів\n", result[0], result[1]);
            } else {
                System.out.println("   Немає даних для відображення");
            }
        } catch (Exception e) {
            System.err.println("Помилка при пошуку виробника з найменшою кількістю блокнотів: " + e.getMessage());
        }
    }

    /**
     * Показати всі блокноти з твердою обкладинкою
     * @return Список блокнотів з твердою обкладинкою
     */
    public List<Notebook> getHardcoverNotebooks() {
        try (Session session = sessionFactory.openSession()) {
            Query<Notebook> query = session.createQuery(
                    "FROM Notebook n WHERE n.coverType = :coverType", Notebook.class
            );
            query.setParameter("coverType", Notebook.CoverType.HARD);
            List<Notebook> notebooks = query.list();
            System.out.println("\n Блокноти з твердою обкладинкою (" + notebooks.size() + " шт.):");
            return notebooks;
        } catch (Exception e) {
            System.err.println("Помилка при пошуку блокнотів з твердою обкладинкою: " + e.getMessage());
            return List.of();
        }
    }

    /**
     * Показати всі блокноти з м'якою обкладинкою
     * @return Список блокнотів з м'якою обкладинкою
     */
    public List<Notebook> getSoftcoverNotebooks() {
        try (Session session = sessionFactory.openSession()) {
            Query<Notebook> query = session.createQuery(
                    "FROM Notebook n WHERE n.coverType = :coverType", Notebook.class
            );
            query.setParameter("coverType", Notebook.CoverType.SOFT);
            List<Notebook> notebooks = query.list();
            System.out.println("\n Блокноти з м'якою обкладинкою (" + notebooks.size() + " шт.):");
            return notebooks;
        } catch (Exception e) {
            System.err.println("Помилка при пошуку блокнотів з м'якою обкладинкою: " + e.getMessage());
            return List.of();
        }
    }

    /**
     * Показати всі блокноти з конкретної країни
     * @param country Назва країни для фільтрації
     * @return Список блокнотів з вказаної країни
     */
    public List<Notebook> getNotebooksByCountry(String country) {
        try (Session session = sessionFactory.openSession()) {
            Query<Notebook> query = session.createQuery(
                    "FROM Notebook n WHERE n.manufacturerCountry = :country", Notebook.class
            );
            query.setParameter("country", country);
            List<Notebook> notebooks = query.list();
            System.out.println("\n🇺🇦 Блокноти з країни " + country + " (" + notebooks.size() + " шт.):");
            return notebooks;
        } catch (Exception e) {
            System.err.println("Помилка при пошуку блокнотів за країною: " + e.getMessage());
            return List.of();
        }
    }

    /**
     * Фільтр для відображення блокнотів за типом сторінки
     * @param pageAppearance Тип сторінки для фільтрації
     * @return Список блокнотів з вказаним типом сторінки
     */
    public List<Notebook> filterByPageAppearance(Notebook.PageAppearance pageAppearance) {
        try (Session session = sessionFactory.openSession()) {
            Query<Notebook> query = session.createQuery(
                    "FROM Notebook n WHERE n.pageAppearance = :appearance", Notebook.class
            );
            query.setParameter("appearance", pageAppearance);
            List<Notebook> notebooks = query.list();
            System.out.println("\n Блокноти з типом сторінки '" + pageAppearance.getDisplayName() +
                    "' (" + notebooks.size() + " шт.):");
            return notebooks;
        } catch (Exception e) {
            System.err.println("Помилка при фільтрації за типом сторінки: " + e.getMessage());
            return List.of();
        }
    }

    /**
     * Фільтр за кількістю сторінок
     * @param minPages Мінімальна кількість сторінок
     * @param maxPages Максимальна кількість сторінок
     * @return Список блокнотів, що відповідають критеріям
     */
    public List<Notebook> filterByPageCount(Integer minPages, Integer maxPages) {
        try (Session session = sessionFactory.openSession()) {
            String hql = "FROM Notebook n WHERE 1=1";

            if (minPages != null) {
                hql += " AND n.pageCount >= :minPages";
            }
            if (maxPages != null) {
                hql += " AND n.pageCount <= :maxPages";
            }

            Query<Notebook> query = session.createQuery(hql, Notebook.class);

            if (minPages != null) {
                query.setParameter("minPages", minPages);
            }
            if (maxPages != null) {
                query.setParameter("maxPages", maxPages);
            }

            List<Notebook> notebooks = query.list();
            System.out.println("\n Блокноти за кількістю сторінок (" + notebooks.size() + " шт.):");
            return notebooks;
        } catch (Exception e) {
            System.err.println("Помилка при фільтрації за кількістю сторінок: " + e.getMessage());
            return List.of();
        }
    }

    /**
     * Фільтр за тиражем блокнота
     * @param minCirculation Мінімальний тираж
     * @param maxCirculation Максимальний тираж
     * @return Список блокнотів, що відповідають критеріям
     */
    public List<Notebook> filterByCirculation(Integer minCirculation, Integer maxCirculation) {
        try (Session session = sessionFactory.openSession()) {
            String hql = "FROM Notebook n WHERE n.circulation IS NOT NULL";

            if (minCirculation != null) {
                hql += " AND n.circulation >= :minCirculation";
            }
            if (maxCirculation != null) {
                hql += " AND n.circulation <= :maxCirculation";
            }

            Query<Notebook> query = session.createQuery(hql, Notebook.class);

            if (minCirculation != null) {
                query.setParameter("minCirculation", minCirculation);
            }
            if (maxCirculation != null) {
                query.setParameter("maxCirculation", maxCirculation);
            }

            List<Notebook> notebooks = query.list();
            System.out.println("\n Блокноти за тиражем (" + notebooks.size() + " шт.):");
            return notebooks;
        } catch (Exception e) {
            System.err.println("Помилка при фільтрації за тиражем: " + e.getMessage());
            return List.of();
        }
    }

    /**
     * Отримати блокнот за ID
     * @param id Ідентифікатор блокнота
     * @return Об'єкт блокнота або null, якщо не знайдено
     */
    public Notebook getNotebookById(Long id) {
        try (Session session = sessionFactory.openSession()) {
            return session.get(Notebook.class, id);
        } catch (Exception e) {
            System.err.println("Помилка при отриманні блокнота за ID: " + e.getMessage());
            return null;
        }
    }
}