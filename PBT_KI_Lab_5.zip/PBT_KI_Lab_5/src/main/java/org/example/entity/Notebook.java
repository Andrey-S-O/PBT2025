package org.example.entity;

import javax.persistence.*;

/**
 * Клас-сутність, що представляє блокнот у базі даних
 * Відображає таблицю з інформацією про блокноти
 */
@Entity
@Table(name = "notebooks")
public class Notebook {

    /**
     * Унікальний ідентифікатор блокнота
     * Генерується автоматично базою даних
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    /**
     * Назва компанії-виробника блокнота
     * Обов'язкове поле, не може бути порожнім
     */
    @Column(name = "company_name", nullable = false)
    private String companyName;

    /**
     * Назва або код моделі блокнота
     * Обов'язкове поле для ідентифікації моделі
     */
    @Column(name = "model_name", nullable = false)
    private String modelName;

    /**
     * Кількість сторінок у блокноті
     * Має бути додатнім числом
     */
    @Column(name = "page_count", nullable = false)
    private Integer pageCount;

    /**
     * Тип обкладинки блокнота
     * Використовуємо Enum для обмеження можливих значень
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "cover_type", nullable = false)
    private CoverType coverType;

    /**
     * Країна-виробник блокнота
     * Вказує на походження продукту
     */
    @Column(name = "manufacturer_country", nullable = false)
    private String manufacturerCountry;

    /**
     * Тираж блокнота (кількість виготовлених копій)
     * Може бути null, якщо інформація недоступна
     */
    @Column(name = "circulation")
    private Integer circulation;

    /**
     * Тип розмітки сторінки блокнота
     * Визначає візуальне оформлення сторінок
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "page_appearance", nullable = false)
    private PageAppearance pageAppearance;

    // Конструктори
    public Notebook() {
        // Порожній конструктор необхідний для Hibernate
    }

    public Notebook(String companyName, String modelName, Integer pageCount,
                    CoverType coverType, String manufacturerCountry,
                    Integer circulation, PageAppearance pageAppearance) {
        this.companyName = companyName;
        this.modelName = modelName;
        this.pageCount = pageCount;
        this.coverType = coverType;
        this.manufacturerCountry = manufacturerCountry;
        this.circulation = circulation;
        this.pageAppearance = pageAppearance;
    }

    // Перелік можливих типів обкладинки
    public enum CoverType {
        HARD("Тверда"),
        SOFT("М'яка");

        private final String displayName;

        CoverType(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }
    }

    // Перелік можливих типів сторінок
    public enum PageAppearance {
        CELL("Клітинка"),
        RULER("Лінійка"),
        EMPTY("Порожня");

        private final String displayName;

        PageAppearance(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }
    }

    // Гетери та сетери
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public Integer getPageCount() {
        return pageCount;
    }

    public void setPageCount(Integer pageCount) {
        this.pageCount = pageCount;
    }

    public CoverType getCoverType() {
        return coverType;
    }

    public void setCoverType(CoverType coverType) {
        this.coverType = coverType;
    }

    public String getManufacturerCountry() {
        return manufacturerCountry;
    }

    public void setManufacturerCountry(String manufacturerCountry) {
        this.manufacturerCountry = manufacturerCountry;
    }

    public Integer getCirculation() {
        return circulation;
    }

    public void setCirculation(Integer circulation) {
        this.circulation = circulation;
    }

    public PageAppearance getPageAppearance() {
        return pageAppearance;
    }

    public void setPageAppearance(PageAppearance pageAppearance) {
        this.pageAppearance = pageAppearance;
    }

    /**
     * Перевизначений метод для зручного відображення інформації про блокнот
     * @return Рядок з усіма характеристиками блокнота
     */
    @Override
    public String toString() {
        return String.format(
                "Блокнот ID: %d | Виробник: %s | Модель: %s | Сторінок: %d | " +
                        "Обкладинка: %s | Країна: %s | Тираж: %s | Сторінка: %s",
                id, companyName, modelName, pageCount,
                coverType.getDisplayName(), manufacturerCountry,
                circulation != null ? circulation : "не вказано",
                pageAppearance.getDisplayName()
        );
    }
}