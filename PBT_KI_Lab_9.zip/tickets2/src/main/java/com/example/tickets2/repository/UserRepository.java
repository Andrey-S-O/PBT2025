package com.example.tickets2.repository;

import com.example.tickets2.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

/**
 * Репозиторій для роботи з користувачами системи
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    /**
     * Пошук користувача за іменем користувача
     * @param username ім'я користувача
     * @return Optional з користувачем, якщо знайдено
     */
    Optional<User> findByUsername(String username);

    /**
     * Пошук користувача за електронною поштою
     * @param email електронна пошта
     * @return Optional з користувачем, якщо знайдено
     */
    Optional<User> findByEmail(String email);

    /**
     * Перевірка існування користувача за іменем користувача
     * @param username ім'я користувача
     * @return true, якщо користувач існує
     */
    boolean existsByUsername(String username);

    /**
     * Перевірка існування користувача за електронною поштою
     * @param email електронна пошта
     * @return true, якщо користувач існує
     */
    boolean existsByEmail(String email);
}