package com.example.tickets2.repository;

import com.example.tickets2.model.Place;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

/**
 * Репозиторій для роботи з місцями проведення заходів
 */
@Repository
public interface PlaceRepository extends JpaRepository<Place, Long> {

    /**
     * Пошук місця за назвою
     * @param name назва місця
     * @return Optional з місцем, якщо знайдено
     */
    Optional<Place> findByName(String name);
}