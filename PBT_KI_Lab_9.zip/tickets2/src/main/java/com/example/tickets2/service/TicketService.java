package com.example.tickets2.service;

import com.example.tickets2.dto.TicketPackDTO;
import com.example.tickets2.model.Event;
import com.example.tickets2.model.Ticket;
import com.example.tickets2.model.TicketStatus;
import com.example.tickets2.repository.TicketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Сервіс для роботи з квитками
 * Відповідає за бізнес-логіку пов'язану з квитками
 */
@Service
public class TicketService {

    @Autowired
    private TicketRepository ticketRepository;

    /**
     * Створення квитків для події на основі пачок квитків
     * @param event подія, для якої створюються квитки
     * @param ticketPacks список пачок квитків (ціна та кількість)
     */
    public void createTicketsForEvent(Event event, List<TicketPackDTO> ticketPacks) {
        List<Ticket> tickets = new ArrayList<>();
        int ticketCounter = 1;

        for (TicketPackDTO pack : ticketPacks) {
            for (int i = 0; i < pack.getCount(); i++) {
                Ticket ticket = new Ticket();
                ticket.setCost(pack.getCost());
                ticket.setNumber("M" + ticketCounter++); // Генерація номера місця
                ticket.setEvent(event);
                ticket.setStatus(TicketStatus.FREE);
                tickets.add(ticket);
            }
        }

        ticketRepository.saveAll(tickets);
    }

    /**
     * Пошук вільних квитків за назвою події
     * @param eventName назва події
     * @return список вільних квитків
     */
    public List<Ticket> findFreeTicketsByEventName(String eventName) {
        return ticketRepository.findFreeTicketsByEventName(eventName);
    }

    /**
     * Призначення квитка покупцю
     * @param ticketId ідентифікатор квитка
     * @param customerId ідентифікатор покупця
     * @return оновлений квиток
     */
    public Ticket assignTicketToCustomer(Long ticketId, Long customerId) {
        Ticket ticket = ticketRepository.findById(ticketId)
                .orElseThrow(() -> new RuntimeException("Квиток не знайдено"));

        if (ticket.getStatus() == TicketStatus.SOLD) {
            throw new RuntimeException("Квиток вже проданий");
        }

        // Тут має бути логіка для встановлення покупця
        // Для спрощення припускаємо, що customerService вже існує
        ticket.setStatus(TicketStatus.SOLD);
        return ticketRepository.save(ticket);
    }

    /**
     * Отримання всіх квитків
     * @return список всіх квитків
     */
    public List<Ticket> getAllTickets() {
        return ticketRepository.findAll();
    }
}