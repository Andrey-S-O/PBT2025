package com.example.tickets2.repository;

import com.example.tickets2.model.Ticket;
import com.example.tickets2.model.TicketStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

/**
 * Репозиторій для роботи з квитками
 */
@Repository
public interface TicketRepository extends JpaRepository<Ticket, Long> {

    /**
     * Пошук вільних квитків для події за назвою
     * @param eventName назва події
     * @return список вільних квитків
     */
    @Query("SELECT t FROM Ticket t WHERE t.event.name = :eventName AND t.status = 'FREE'")
    List<Ticket> findFreeTicketsByEventName(String eventName);

    /**
     * Пошук квитків за статусом
     * @param status статус квитка
     * @return список квитків з вказаним статусом
     */
    List<Ticket> findByStatus(TicketStatus status);

    /**
     * Пошук квитків за ідентифікатором клієнта
     * @param customerId ідентифікатор клієнта
     * @return список квитків клієнта
     */
    List<Ticket> findByCustomerId(Long customerId);
}