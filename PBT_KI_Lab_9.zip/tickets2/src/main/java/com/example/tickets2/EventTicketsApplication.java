package com.example.tickets2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Головний клас Spring Boot додатку
 * Запускає весь додаток для системи покупки квитків на заходи
 */
@SpringBootApplication
public class EventTicketsApplication {

    public static void main(String[] args) {
        SpringApplication.run(EventTicketsApplication.class, args);
    }
}