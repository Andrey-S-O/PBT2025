package com.example.tickets2.service;

import com.example.tickets2.model.Ticket;
import com.example.tickets2.model.TicketStatus;
import com.example.tickets2.model.User;
import com.example.tickets2.repository.TicketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Захищений сервіс для роботи з квитками
 * Містить логіку покупки квитків з перевірками прав доступу
 */
@Service
public class SecureTicketService {

    @Autowired
    private TicketRepository ticketRepository;

    @Autowired
    private UserService userService;

    /**
     * Пошук вільних квитків за назвою події
     * Доступно для всіх автентифікованих користувачів
     */
    @PreAuthorize("isAuthenticated()")
    public List<Ticket> findFreeTicketsByEventName(String eventName) {
        return ticketRepository.findFreeTicketsByEventName(eventName);
    }

    /**
     * Покупка квитка користувачем
     * Доступно для всіх автентифікованих користувачів
     */
    @Transactional
    @PreAuthorize("isAuthenticated()")
    public Ticket purchaseTicket(Long ticketId) {
        // Отримання поточного користувача
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        User user = userService.getUserByUsername(username);

        // Пошук квитка
        Ticket ticket = ticketRepository.findById(ticketId)
                .orElseThrow(() -> new RuntimeException("Квиток не знайдено"));

        // Перевірка, чи квиток вільний
        if (ticket.getStatus() == TicketStatus.SOLD) {
            throw new RuntimeException("Квиток вже проданий");
        }

        // Призначення квитка користувачу
        ticket.setCustomer(user.getCustomer());
        ticket.setStatus(TicketStatus.SOLD);

        return ticketRepository.save(ticket);
    }

    /**
     * Отримання квитків поточного користувача
     * Доступно тільки для власника квитків
     */
    @PreAuthorize("isAuthenticated()")
    public List<Ticket> getUserTickets() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        User user = userService.getUserByUsername(username);

        return ticketRepository.findByCustomerId(user.getCustomer().getId());
    }

    /**
     * Отримання всіх квитків (для адміністраторів)
     * Доступно тільки для адміністраторів
     */
    @PreAuthorize("hasRole('ADMIN')")
    public List<Ticket> getAllTickets() {
        return ticketRepository.findAll();
    }

    /**
     * Скасування покупки квитка
     * Доступно для власника квитка або адміністратора
     */
    @Transactional
    @PreAuthorize("isAuthenticated()")
    public Ticket cancelTicketPurchase(Long ticketId) {
        Ticket ticket = ticketRepository.findById(ticketId)
                .orElseThrow(() -> new RuntimeException("Квиток не знайдено"));

        // Отримання поточного користувача
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        User user = userService.getUserByUsername(username);

        // Перевірка прав доступу
        boolean isOwner = ticket.getCustomer() != null &&
                ticket.getCustomer().getId().equals(user.getCustomer().getId());
        boolean isAdmin = authentication.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));

        if (!isOwner && !isAdmin) {
            throw new RuntimeException("Недостатньо прав для скасування покупки");
        }

        // Скасування покупки
        ticket.setCustomer(null);
        ticket.setStatus(TicketStatus.FREE);

        return ticketRepository.save(ticket);
    }
}