package com.example.tickets2.config;

import com.example.tickets2.service.CustomUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Конфігурація Spring Security
 * Визначає правила безпеки, автентифікації та авторизації
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

    @Autowired
    private CustomUserDetailsService userDetailsService;

    /**
     * Бін для кодування паролів
     * Використовується BCrypt для безпечного зберігання паролів
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * Конфігурація ланцюга фільтрів безпеки
     * Визначає правила доступу до URL та налаштування автентифікації
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                // Налаштування авторизації запитів
                .authorizeHttpRequests(authz -> authz
                        // Публічні ресурси
                        .requestMatchers(
                                "/",
                                "/home",
                                "/events/**",
                                "/css/**",
                                "/js/**",
                                "/images/**",
                                "/register",
                                "/api/events/**"
                        ).permitAll()

                        // Адміністративні ресурси тільки для адміністраторів
                        .requestMatchers(
                                "/admin/**",
                                "/api/admin/**"
                        ).hasRole("ADMIN")

                        // Ресурси організатора для організаторів та адміністраторів
                        .requestMatchers(
                                "/organizer/**",
                                "/api/organizer/**"
                        ).hasAnyRole("ORGANIZER", "ADMIN")

                        // Особистий кабінет для автентифікованих користувачів
                        .requestMatchers(
                                "/profile/**",
                                "/api/tickets/**"
                        ).authenticated()

                        // Всі інші запити вимагають автентифікації
                        .anyRequest().authenticated()
                )

                // Налаштування форми логіну
                .formLogin(form -> form
                        .loginPage("/login")
                        .defaultSuccessUrl("/events", true)
                        .permitAll()
                )

                // Налаштування виходу
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/events")
                        .permitAll()
                )

                // Налаштування remember-me
                .rememberMe(remember -> remember
                        .key("uniqueAndSecret")
                        .tokenValiditySeconds(86400) // 24 години
                        .userDetailsService(userDetailsService)
                );

        return http.build();
    }
}