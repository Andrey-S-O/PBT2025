package com.example.tickets2.config;

import com.example.tickets2.model.*;
import com.example.tickets2.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * Клас для ініціалізації тестових даних при запуску додатку
 * Створює тестових користувачів з різними ролями
 */
@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        // Створення тестового адміністратора
        if (!userRepository.existsByUsername("admin")) {
            User admin = new User();
            admin.setUsername("admin");
            admin.setPassword(passwordEncoder.encode("admin123"));
            admin.setEmail("admin@tickets.com");
            admin.setFullName("Адміністратор Системи");
            admin.addRole(Role.ROLE_ADMIN);
            admin.addRole(Role.ROLE_ORGANIZER);
            admin.addRole(Role.ROLE_USER);

            Customer adminCustomer = new Customer();
            adminCustomer.setName("Адміністратор Системи");
            adminCustomer.setEmail("admin@tickets.com");
            adminCustomer.setPhone("+380001112233");
            admin.setCustomer(adminCustomer);

            userRepository.save(admin);
        }

        // Створення тестового організатора
        if (!userRepository.existsByUsername("organizer")) {
            User organizer = new User();
            organizer.setUsername("organizer");
            organizer.setPassword(passwordEncoder.encode("organizer123"));
            organizer.setEmail("organizer@tickets.com");
            organizer.setFullName("Організатор Подій");
            organizer.addRole(Role.ROLE_ORGANIZER);
            organizer.addRole(Role.ROLE_USER);

            Customer organizerCustomer = new Customer();
            organizerCustomer.setName("Організатор Подій");
            organizerCustomer.setEmail("organizer@tickets.com");
            organizerCustomer.setPhone("+380002223344");
            organizer.setCustomer(organizerCustomer);

            userRepository.save(organizer);
        }

        // Створення тестового користувача
        if (!userRepository.existsByUsername("user")) {
            User user = new User();
            user.setUsername("user");
            user.setPassword(passwordEncoder.encode("user123"));
            user.setEmail("user@tickets.com");
            user.setFullName("Звичайний Користувач");
            user.addRole(Role.ROLE_USER);

            Customer userCustomer = new Customer();
            userCustomer.setName("Звичайний Користувач");
            userCustomer.setEmail("user@tickets.com");
            userCustomer.setPhone("+380003334455");
            user.setCustomer(userCustomer);

            userRepository.save(user);
        }
    }
}