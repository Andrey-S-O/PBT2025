package com.example.tickets2.controller;

import com.example.tickets2.dto.UserRegistrationDTO;
import com.example.tickets2.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * Контролер для автентифікації та реєстрації користувачів
 */
@Controller
public class AuthController {

    @Autowired
    private UserService userService;

    /**
     * Відображення форми логіну
     */
    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    /**
     * Відображення форми реєстрації
     */
    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("userRegistrationDTO", new UserRegistrationDTO());
        return "register";
    }

    /**
     * Обробка реєстрації нового користувача
     */
    @PostMapping("/register")
    public String registerUser(
            @Valid @ModelAttribute UserRegistrationDTO userRegistrationDTO,
            BindingResult bindingResult,
            Model model) {

        // Перевірка валідації
        if (bindingResult.hasErrors()) {
            return "register";
        }

        try {
            // Спроба реєстрації користувача
            userService.registerUser(userRegistrationDTO);
            model.addAttribute("successMessage", "Реєстрація успішна! Тепер ви можете увійти в систему.");
            return "login";

        } catch (RuntimeException e) {
            model.addAttribute("errorMessage", e.getMessage());
            return "register";
        }
    }

    /**
     * Головна сторінка
     */
    @GetMapping("/")
    public String home() {
        return "redirect:/events";
    }

    /**
     * Головна сторінка для автентифікованих користувачів
     */
    @GetMapping("/home")
    public String authenticatedHome() {
        return "redirect:/events";
    }
}