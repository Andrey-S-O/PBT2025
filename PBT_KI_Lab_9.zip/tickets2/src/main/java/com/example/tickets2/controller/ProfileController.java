package com.example.tickets2.controller;

import com.example.tickets2.model.Ticket;
import com.example.tickets2.service.SecureTicketService;
import com.example.tickets2.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * Контролер для особистого кабінету користувача
 */
@Controller
@RequestMapping("/profile")
public class ProfileController {

    @Autowired
    private SecureTicketService ticketService;

    @Autowired
    private UserService userService;

    /**
     * Відображення особистого кабінету користувача
     */
    @GetMapping
    public String showProfile(Model model, Authentication authentication) {
        String username = authentication.getName();
        var user = userService.getUserByUsername(username);

        model.addAttribute("user", user);
        model.addAttribute("customer", user.getCustomer());

        // Отримання квитків користувача
        List<Ticket> userTickets = ticketService.getUserTickets();
        model.addAttribute("tickets", userTickets);

        return "profile";
    }

    /**
     * Покупка квитка
     */
    @PostMapping("/purchase")
    public String purchaseTicket(@RequestParam Long ticketId, Model model) {
        try {
            Ticket ticket = ticketService.purchaseTicket(ticketId);
            model.addAttribute("successMessage",
                    "Квиток успішно придбано! Номер місця: " + ticket.getNumber());
        } catch (RuntimeException e) {
            model.addAttribute("errorMessage", "Помилка при покупці квитка: " + e.getMessage());
        }

        return "redirect:/profile";
    }

    /**
     * Скасування покупки квитка
     */
    @PostMapping("/cancel")
    public String cancelTicket(@RequestParam Long ticketId, Model model) {
        try {
            ticketService.cancelTicketPurchase(ticketId);
            model.addAttribute("successMessage", "Покупку квитка скасовано");
        } catch (RuntimeException e) {
            model.addAttribute("errorMessage", "Помилка при скасуванні покупки: " + e.getMessage());
        }

        return "redirect:/profile";
    }
}