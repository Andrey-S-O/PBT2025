package com.example.tickets2.model;

/**
 * Клас констант для ролей користувачів
 * Визначає доступні ролі в системі та їх права
 */
public class Role {

    // Ролі користувачів
    public static final String ROLE_USER = "ROLE_USER";         // Звичайний користувач
    public static final String ROLE_ADMIN = "ROLE_ADMIN";       // Адміністратор
    public static final String ROLE_ORGANIZER = "ROLE_ORGANIZER"; // Організатор подій

    // Права доступу (Authorities)
    public static final String VIEW_EVENTS = "VIEW_EVENTS";                 // Перегляд подій
    public static final String ORDER_TICKETS = "ORDER_TICKETS";             // Замовлення квитків
    public static final String MANAGE_EVENTS = "MANAGE_EVENTS";             // Керування подіями
    public static final String MANAGE_USERS = "MANAGE_USERS";               // Керування користувачами
    public static final String MANAGE_TICKETS = "MANAGE_TICKETS";           // Керування квитками
    public static final String ACCESS_ADMIN_PANEL = "ACCESS_ADMIN_PANEL";   // Доступ до адмін панелі

    private Role() {
        // Утилітарний клас
    }
}