package com.example.tickets2.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * DTO для реєстрації нового користувача
 * Містить валідацію вхідних даних
 */
public class UserRegistrationDTO {

    @NotBlank(message = "Ім'я користувача обов'язкове")
    @Size(min = 3, max = 50, message = "Ім'я користувача має містити від 3 до 50 символів")
    private String username;

    @NotBlank(message = "Пароль обов'язковий")
    @Size(min = 6, message = "Пароль має містити щонайменше 6 символів")
    private String password;

    @NotBlank(message = "Підтвердження паролю обов'язкове")
    private String confirmPassword;

    @NotBlank(message = "Електронна пошта обов'язкова")
    @Email(message = "Некоректний формат електронної пошти")
    private String email;

    @NotBlank(message = "Повне ім'я обов'язкове")
    private String fullName;

    private String phone; // Необов'язковий номер телефону

    // Конструктори
    public UserRegistrationDTO() {}

    public UserRegistrationDTO(String username, String password, String confirmPassword,
                               String email, String fullName, String phone) {
        this.username = username;
        this.password = password;
        this.confirmPassword = confirmPassword;
        this.email = email;
        this.fullName = fullName;
        this.phone = phone;
    }

    // Гетери та сетери
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getConfirmPassword() { return confirmPassword; }
    public void setConfirmPassword(String confirmPassword) { this.confirmPassword = confirmPassword; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
}