package com.example.tickets2.dto;

/**
 * DTO для місця проведення заходу
 */
public class PlaceDTO {
    private String name;    // Назва місця
    private String address; // Адреса місця

    // Конструктори
    public PlaceDTO() {}

    public PlaceDTO(String name, String address) {
        this.name = name;
        this.address = address;
    }

    // Гетери та сетери
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
}