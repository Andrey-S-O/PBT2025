package com.example.tickets2.service;

import com.example.tickets2.dto.EventCreationDTO;
import com.example.tickets2.model.Event;
import com.example.tickets2.model.Place;
import com.example.tickets2.model.Ticket;
import com.example.tickets2.repository.EventRepository;
import com.example.tickets2.repository.PlaceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Захищений сервіс для роботи з подіями
 * Містить аннотації безпеки для контролю доступу
 */
@Service
public class SecureEventService {

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private PlaceRepository placeRepository;

    @Autowired
    private TicketService ticketService;

    /**
     * Створення нової події з DTO
     * Доступно тільки для організаторів та адміністраторів
     */
    @Transactional
    @PreAuthorize("hasRole('ORGANIZER') or hasRole('ADMIN')")
    public Event createEvent(EventCreationDTO eventDTO) {
        // Пошук або створення місця проведення
        Place place = placeRepository.findByName(eventDTO.getPlace().getName())
                .orElseGet(() -> {
                    Place newPlace = new Place(
                            eventDTO.getPlace().getName(),
                            eventDTO.getPlace().getAddress()
                    );
                    return placeRepository.save(newPlace);
                });

        // Перевірка наявності події в цьому місці на ту саму дату
        List<Event> existingEvents = eventRepository.findByPlaceName(place.getName());
        for (Event existingEvent : existingEvents) {
            if (existingEvent.getEventDate().equals(eventDTO.getEventDate())) {
                throw new RuntimeException("Подія в цьому місці на цю дату вже існує");
            }
        }

        // Створення події
        Event event = new Event(
                eventDTO.getName(),
                eventDTO.getEventDate(),
                place
        );

        Event savedEvent = eventRepository.save(event);

        // Створення квитків для події
        ticketService.createTicketsForEvent(savedEvent, eventDTO.getTickets());

        return savedEvent;
    }

    /**
     * Пошук подій за назвою
     * Доступно для всіх користувачів
     */
    public List<Event> findEventsByName(String name) {
        return eventRepository.findByNameContainingIgnoreCase(name);
    }

    /**
     * Отримання всіх подій
     * Доступно для всіх користувачів
     */
    public List<Event> getAllEvents() {
        return eventRepository.findAll();
    }

    /**
     * Пошук майбутніх подій
     * Доступно для всіх користувачів
     */
    public List<Event> getUpcomingEvents() {
        return eventRepository.findByEventDateAfter(java.time.LocalDateTime.now());
    }

    /**
     * Отримання події за ідентифікатором
     * Доступно для всіх користувачів
     */
    public Event getEventById(Long id) {
        return eventRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Подію не знайдено"));
    }

    /**
     * Видалення події
     * Доступно тільки для адміністраторів
     */
    @PreAuthorize("hasRole('ADMIN')")
    public void deleteEvent(Long id) {
        Event event = getEventById(id);
        eventRepository.delete(event);
    }
}