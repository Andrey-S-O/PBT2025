package com.example.tickets2.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Сутність місця проведення заходу
 * Містить інформацію про локацію, де відбуваються події
 */
@Entity
@Table(name = "places")
public class Place {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;        // Назва місця проведення

    @Column(nullable = false)
    private String address;     // Адреса місця проведення

    @OneToMany(mappedBy = "place", cascade = CascadeType.ALL)
    private List<Event> events = new ArrayList<>(); // Список подій на цьому місці

    // Конструктори
    public Place() {}

    public Place(String name, String address) {
        this.name = name;
        this.address = address;
    }

    // Гетери та сетери
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public List<Event> getEvents() { return events; }
    public void setEvents(List<Event> events) { this.events = events; }
}