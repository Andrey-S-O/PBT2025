package com.example.tickets2.controller;

import com.example.tickets2.dto.EventCreationDTO;
import com.example.tickets2.model.Event;
import com.example.tickets2.model.Ticket;
import com.example.tickets2.service.EventService;
import com.example.tickets2.service.TicketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Контролер для роботи з подіями через веб-інтерфейс
 * Використовує Thymeleaf для відображення сторінок
 */
@Controller
@RequestMapping("/events")
public class EventController {

    @Autowired
    private EventService eventService;

    @Autowired
    private TicketService ticketService;

    /**
     * Відображення головної сторінки з майбутніми подіями
     * @param model модель для передачі даних у шаблон
     * @return назва шаблону
     */
    @GetMapping
    public String showEventsPage(Model model) {
        List<Event> upcomingEvents = eventService.getUpcomingEvents();
        model.addAttribute("events", upcomingEvents);
        model.addAttribute("message", "Майбутні події");
        return "events";
    }

    /**
     * Відображення форми для створення нової події
     * @param model модель для передачі даних у шаблон
     * @return назва шаблону
     */
    @GetMapping("/create")
    public String showCreateEventForm(Model model) {
        model.addAttribute("eventDTO", new EventCreationDTO());
        model.addAttribute("message", "Створення нової події");
        return "create-event";
    }

    /**
     * Обробка створення нової події
     * @param eventDTO DTO з даними події
     * @param model модель для передачі даних у шаблон
     * @return перенаправлення на сторінку подій
     */
    @PostMapping("/create")
    public String createEvent(@ModelAttribute EventCreationDTO eventDTO, Model model) {
        try {
            eventService.createEvent(eventDTO);
            model.addAttribute("successMessage", "Подію успішно створено!");
        } catch (Exception e) {
            model.addAttribute("errorMessage", "Помилка при створенні події: " + e.getMessage());
        }
        return "redirect:/events";
    }

    /**
     * Пошук подій за назвою
     * @param name назва події для пошуку
     * @param model модель для передачі даних у шаблон
     * @return назва шаблону
     */
    @GetMapping("/search")
    public String searchEvents(@RequestParam String name, Model model) {
        List<Event> events = eventService.findEventsByName(name);
        model.addAttribute("events", events);
        model.addAttribute("message", "Результати пошуку для: " + name);
        return "events";
    }

    /**
     * Відображення вільних квитків для події
     * @param eventName назва події
     * @param model модель для передачі даних у шаблон
     * @return назва шаблону
     */
    @GetMapping("/{eventName}/tickets")
    public String showFreeTickets(@PathVariable String eventName, Model model) {
        List<Ticket> freeTickets = ticketService.findFreeTicketsByEventName(eventName);
        model.addAttribute("tickets", freeTickets);
        model.addAttribute("eventName", eventName);
        model.addAttribute("message", "Вільні квитки для події: " + eventName);
        return "tickets";
    }
}