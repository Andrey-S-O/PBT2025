package com.example.tickets2.service;

import com.example.tickets2.dto.UserRegistrationDTO;
import com.example.tickets2.model.Customer;
import com.example.tickets2.model.Role;
import com.example.tickets2.model.User;
import com.example.tickets2.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Сервіс для роботи з користувачами системи
 * Відповідає за реєстрацію, автентифікацію та управління користувачами
 */
@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    /**
     * Реєстрація нового користувача
     * @param registrationDTO DTO з даними для реєстрації
     * @return зареєстрований користувач
     * @throws RuntimeException якщо користувач вже існує або паролі не співпадають
     */
    @Transactional
    public User registerUser(UserRegistrationDTO registrationDTO) {
        // Перевірка унікальності імені користувача та email
        if (userRepository.existsByUsername(registrationDTO.getUsername())) {
            throw new RuntimeException("Користувач з таким іменем вже існує");
        }

        if (userRepository.existsByEmail(registrationDTO.getEmail())) {
            throw new RuntimeException("Користувач з такою електронною поштою вже існує");
        }

        // Перевірка співпадіння паролів
        if (!registrationDTO.getPassword().equals(registrationDTO.getConfirmPassword())) {
            throw new RuntimeException("Паролі не співпадають");
        }

        // Створення нового користувача
        User user = new User();
        user.setUsername(registrationDTO.getUsername());
        user.setPassword(passwordEncoder.encode(registrationDTO.getPassword()));
        user.setEmail(registrationDTO.getEmail());
        user.setFullName(registrationDTO.getFullName());

        // Додавання ролі USER за замовчуванням
        user.addRole(Role.ROLE_USER);

        // Створення профілю покупця
        Customer customer = new Customer();
        customer.setName(registrationDTO.getFullName());
        customer.setEmail(registrationDTO.getEmail());
        customer.setPhone(registrationDTO.getPhone());

        user.setCustomer(customer);

        return userRepository.save(user);
    }

    /**
     * Отримання користувача за іменем користувача
     * @param username ім'я користувача
     * @return користувач
     * @throws RuntimeException якщо користувач не знайдений
     */
    public User getUserByUsername(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Користувача не знайдено"));
    }

    /**
     * Перевірка існування користувача за іменем користувача
     * @param username ім'я користувача
     * @return true, якщо користувач існує
     */
    public boolean userExists(String username) {
        return userRepository.existsByUsername(username);
    }

    /**
     * Перевірка існування користувача за електронною поштою
     * @param email електронна пошта
     * @return true, якщо користувач існує
     */
    public boolean emailExists(String email) {
        return userRepository.existsByEmail(email);
    }
}