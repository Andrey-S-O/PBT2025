package com.example.tickets.repository;

import com.example.tickets.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

/**
 * Репозиторій для роботи з клієнтами
 */
@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {

    /**
     * Пошук клієнта за електронною поштою
     * @param email електронна пошта
     * @return Optional з клієнтом, якщо знайдено
     */
    Optional<Customer> findByEmail(String email);
}