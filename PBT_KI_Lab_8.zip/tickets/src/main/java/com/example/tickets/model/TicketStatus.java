package com.example.tickets.model;

/**
 * Перелік статусів квитка
 * FREE - вільний квиток
 * SOLD - проданий квиток
 */
public enum TicketStatus {
    FREE,      // Квиток вільний для покупки
    SOLD       // Квиток вже проданий
}