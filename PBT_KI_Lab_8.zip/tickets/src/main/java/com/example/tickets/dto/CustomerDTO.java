package com.example.tickets.dto;

/**
 * DTO для створення нового клієнта
 */
public class CustomerDTO {
    private String name;    // Ім'я клієнта
    private String email;   // Електронна пошта
    private String phone;   // Номер телефону

    // Конструктори
    public CustomerDTO() {}

    public CustomerDTO(String name, String email, String phone) {
        this.name = name;
        this.email = email;
        this.phone = phone;
    }

    // Гетери та сетери
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
}