package com.example.tickets.dto;

import java.time.LocalDateTime;
import java.util.List;

/**
 * DTO для створення нової події
 * Містить всі необхідні дані для створення події та пов'язаних квитків
 */
public class EventCreationDTO {
    private LocalDateTime eventDate;        // Дата та час проведення події
    private String name;                    // Назва події
    private List<TicketPackDTO> tickets;    // Список пачок квитків
    private PlaceDTO place;                 // Інформація про місце проведення

    // Конструктори
    public EventCreationDTO() {}

    public EventCreationDTO(String name, LocalDateTime eventDate, PlaceDTO place, List<TicketPackDTO> tickets) {
        this.name = name;
        this.eventDate = eventDate;
        this.place = place;
        this.tickets = tickets;
    }

    // Гетери та сетери
    public LocalDateTime getEventDate() { return eventDate; }
    public void setEventDate(LocalDateTime eventDate) { this.eventDate = eventDate; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public List<TicketPackDTO> getTickets() { return tickets; }
    public void setTickets(List<TicketPackDTO> tickets) { this.tickets = tickets; }

    public PlaceDTO getPlace() { return place; }
    public void setPlace(PlaceDTO place) { this.place = place; }
}