package com.example.tickets.model;

import jakarta.persistence.*;

/**
 * Сутність квитка
 * Містить інформацію про ціну, місце, статус та зв'язки з подією та покупцем
 */
@Entity
@Table(name = "tickets")
public class Ticket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Double cost;        // Ціна квитка

    @Column(nullable = false)
    private String number;      // Номер місця/квитка

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TicketStatus status = TicketStatus.FREE; // Статус квитка (за замовчуванням - вільний)

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;  // Власник квитка (може бути null, якщо квиток вільний)

    @ManyToOne
    @JoinColumn(name = "event_id", nullable = false)
    private Event event;        // Подія, для якої призначений квиток

    // Конструктори
    public Ticket() {}

    public Ticket(Double cost, String number, Event event) {
        this.cost = cost;
        this.number = number;
        this.event = event;
        this.status = TicketStatus.FREE;
    }

    // Гетери та сетери
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Double getCost() { return cost; }
    public void setCost(Double cost) { this.cost = cost; }

    public String getNumber() { return number; }
    public void setNumber(String number) { this.number = number; }

    public TicketStatus getStatus() { return status; }
    public void setStatus(TicketStatus status) { this.status = status; }

    public Customer getCustomer() { return customer; }
    public void setCustomer(Customer customer) { this.customer = customer; }

    public Event getEvent() { return event; }
    public void setEvent(Event event) { this.event = event; }
}