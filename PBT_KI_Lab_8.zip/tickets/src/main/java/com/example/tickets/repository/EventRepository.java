package com.example.tickets.repository;

import com.example.tickets.model.Event;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Репозиторій для роботи з подіями
 */
@Repository
public interface EventRepository extends JpaRepository<Event, Long> {

    /**
     * Пошук подій за назвою (з урахуванням регістру)
     * @param name назва події
     * @return список подій з вказаною назвою
     */
    List<Event> findByNameContainingIgnoreCase(String name);

    /**
     * Пошук майбутніх подій (дата більша за поточну)
     * @param currentDate поточна дата
     * @return список майбутніх подій
     */
    List<Event> findByEventDateAfter(LocalDateTime currentDate);

    /**
     * Пошук подій за назвою місця проведення
     * @param placeName назва місця
     * @return список подій на вказаному місці
     */
    @Query("SELECT e FROM Event e WHERE e.place.name = :placeName")
    List<Event> findByPlaceName(String placeName);
}