package com.example.tickets.service;

import com.example.tickets.dto.CustomerDTO;
import com.example.tickets.model.Customer;
import com.example.tickets.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Сервіс для роботи з клієнтами
 * Відповідає за бізнес-логіку пов'язану з клієнтами
 */
@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    /**
     * Створення нового клієнта
     * @param customerDTO DTO з даними клієнта
     * @return створений клієнт
     */
    public Customer createCustomer(CustomerDTO customerDTO) {
        // Перевірка, чи не існує клієнт з такою ж електронною поштою
        if (customerRepository.findByEmail(customerDTO.getEmail()).isPresent()) {
            throw new RuntimeException("Клієнт з такою електронною поштою вже існує");
        }

        Customer customer = new Customer();
        customer.setName(customerDTO.getName());
        customer.setEmail(customerDTO.getEmail());
        customer.setPhone(customerDTO.getPhone());

        return customerRepository.save(customer);
    }

    /**
     * Отримання всіх клієнтів
     * @return список всіх клієнтів
     */
    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    /**
     * Пошук клієнта за ідентифікатором
     * @param id ідентифікатор клієнта
     * @return клієнт
     */
    public Customer getCustomerById(Long id) {
        return customerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Клієнта не знайдено"));
    }

    /**
     * Пошук клієнта за електронною поштою
     * @param email електронна пошта
     * @return клієнт
     */
    public Customer getCustomerByEmail(String email) {
        return customerRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Клієнта не знайдено"));
    }
}