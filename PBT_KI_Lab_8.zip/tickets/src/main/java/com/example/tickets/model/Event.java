package com.example.tickets.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Сутність заходу (події)
 * Містить інформацію про подію, дату проведення та пов'язані квитки
 */
@Entity
@Table(name = "events")
public class Event {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "event_date", nullable = false)
    private LocalDateTime eventDate; // Дата та час проведення заходу

    @Column(nullable = false)
    private String name;            // Назва заходу

    @ManyToOne
    @JoinColumn(name = "place_id", nullable = false)
    private Place place;            // Місце проведення заходу

    @OneToMany(mappedBy = "event", cascade = CascadeType.ALL)
    private List<Ticket> tickets = new ArrayList<>(); // Список квитків на захід

    // Конструктори
    public Event() {}

    public Event(String name, LocalDateTime eventDate, Place place) {
        this.name = name;
        this.eventDate = eventDate;
        this.place = place;
    }

    // Гетери та сетери
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public LocalDateTime getEventDate() { return eventDate; }
    public void setEventDate(LocalDateTime eventDate) { this.eventDate = eventDate; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Place getPlace() { return place; }
    public void setPlace(Place place) { this.place = place; }

    public List<Ticket> getTickets() { return tickets; }
    public void setTickets(List<Ticket> tickets) { this.tickets = tickets; }
}