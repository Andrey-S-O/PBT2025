package com.example.tickets.controller;

import com.example.tickets.dto.CustomerDTO;
import com.example.tickets.model.Customer;
import com.example.tickets.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import org.springframework.web.bind.annotation.*;

/**
 * Контролер для роботи з клієнтами через веб-інтерфейс
 */
@Controller
@RequestMapping("/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    /**
     * Відображення сторінки зі списком клієнтів
     * @param model модель для передачі даних у шаблон
     * @return назва шаблону
     */
    @GetMapping
    public String showCustomersPage(Model model) {
        List<Customer> customers = customerService.getAllCustomers();
        model.addAttribute("customers", customers);
        model.addAttribute("message", "Список клієнтів");
        return "customers";
    }

    /**
     * Відображення форми для створення нового клієнта
     * @param model модель для передачі даних у шаблон
     * @return назва шаблону
     */
    @GetMapping("/create")
    public String showCreateCustomerForm(Model model) {
        model.addAttribute("customerDTO", new CustomerDTO());
        model.addAttribute("message", "Створення нового клієнта");
        return "create-customer";
    }

    /**
     * Обробка створення нового клієнта
     * @param customerDTO DTO з даними клієнта
     * @param model модель для передачі даних у шаблон
     * @return перенаправлення на сторінку клієнтів
     */
    @PostMapping("/create")
    public String createCustomer(@ModelAttribute CustomerDTO customerDTO, Model model) {
        try {
            customerService.createCustomer(customerDTO);
            model.addAttribute("successMessage", "Клієнта успішно створено!");
        } catch (Exception e) {
            model.addAttribute("errorMessage", "Помилка при створенні клієнта: " + e.getMessage());
        }
        return "redirect:/customers";
    }
}