package com.example.tickets.service;

import com.example.tickets.dto.EventCreationDTO;
import com.example.tickets.model.Event;
import com.example.tickets.model.Place;
import com.example.tickets.repository.EventRepository;
import com.example.tickets.repository.PlaceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

/**
 * Сервіс для роботи з подіями
 * Відповідає за бізнес-логіку пов'язану з подіями та квитками
 */
@Service
public class EventService {

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private PlaceRepository placeRepository;

    @Autowired
    private TicketService ticketService;

    /**
     * Створення нової події з DTO
     * @param eventDTO DTO з даними для створення події
     * @return створена подія
     */
    @Transactional
    public Event createEvent(EventCreationDTO eventDTO) {
        // Пошук або створення місця проведення
        Place place = placeRepository.findByName(eventDTO.getPlace().getName())
                .orElseGet(() -> {
                    Place newPlace = new Place(
                            eventDTO.getPlace().getName(),
                            eventDTO.getPlace().getAddress()
                    );
                    return placeRepository.save(newPlace);
                });

        // Створення події
        Event event = new Event(
                eventDTO.getName(),
                eventDTO.getEventDate(),
                place
        );

        Event savedEvent = eventRepository.save(event);

        // Створення квитків для події
        ticketService.createTicketsForEvent(savedEvent, eventDTO.getTickets());

        return savedEvent;
    }

    /**
     * Пошук подій за назвою
     * @param name назва події
     * @return список подій з вказаною назвою
     */
    public List<Event> findEventsByName(String name) {
        return eventRepository.findByNameContainingIgnoreCase(name);
    }

    /**
     * Отримання всіх подій
     * @return список всіх подій
     */
    public List<Event> getAllEvents() {
        return eventRepository.findAll();
    }

    /**
     * Пошук майбутніх подій
     * @return список майбутніх подій
     */
    public List<Event> getUpcomingEvents() {
        return eventRepository.findByEventDateAfter(java.time.LocalDateTime.now());
    }

    /**
     * Отримання події за ідентифікатором
     * @param id ідентифікатор події
     * @return подія
     */
    public Event getEventById(Long id) {
        return eventRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Подію не знайдено"));
    }
}