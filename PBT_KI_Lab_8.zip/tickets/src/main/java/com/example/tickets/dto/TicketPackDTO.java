package com.example.tickets.dto;

/**
 * DTO для пачки квитків
 * Використовується при створенні події для вказівки кількості квитків різної ціни
 */
public class TicketPackDTO {
    private Double cost;    // Ціна за квиток у цій пачці
    private Integer count;  // Кількість квитків з цією ціною

    // Конструктори
    public TicketPackDTO() {}

    public TicketPackDTO(Double cost, Integer count) {
        this.cost = cost;
        this.count = count;
    }

    // Гетери та сетери
    public Double getCost() { return cost; }
    public void setCost(Double cost) { this.cost = cost; }

    public Integer getCount() { return count; }
    public void setCount(Integer count) { this.count = count; }
}