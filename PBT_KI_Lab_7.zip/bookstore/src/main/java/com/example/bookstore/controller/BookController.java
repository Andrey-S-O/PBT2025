package com.example.bookstore.controller;

import com.example.bookstore.dto.BookDTO;
import com.example.bookstore.dto.CreateBookRequest;
import com.example.bookstore.dto.BookSearchRequest;
import com.example.bookstore.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST контролер для управління книгами
 * Надає API endpoints для операцій CRUD та пошуку
 */
@RestController
@RequestMapping("/api/books")
@CrossOrigin(origins = "*") // Дозволяє запити з будь-якого джерела
public class BookController {

    private final BookService bookService;

    @Autowired
    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    /**
     * Отримати список всіх книг
     * @return список книг та статус OK
     */
    @GetMapping
    public ResponseEntity<List<BookDTO>> getAllBooks() {
        List<BookDTO> books = bookService.getAllBooks();
        return ResponseEntity.ok(books);
    }

    /**
     * Отримати книгу за ID
     * @param id ідентифікатор книги
     * @return книга та статус OK, або NOT_FOUND якщо книга не знайдена
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getBookById(@PathVariable Long id) {
        BookDTO book = bookService.getBookById(id);
        if (book != null) {
            return ResponseEntity.ok(book);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Книгу з ID " + id + " не знайдено");
        }
    }

    /**
     * Створити нову книгу
     * @param request дані для створення книги
     * @return створена книга та статус CREATED
     */
    @PostMapping
    public ResponseEntity<?> createBook(@RequestBody CreateBookRequest request) {
        try {
            // Валідація обов'язкових полів
            if (request.getTitle() == null || request.getTitle().trim().isEmpty()) {
                return ResponseEntity.badRequest().body("Назва книги є обов'язковою");
            }
            if (request.getAuthorFullName() == null || request.getAuthorFullName().trim().isEmpty()) {
                return ResponseEntity.badRequest().body("Повне ім'я автора є обов'язковим");
            }
            if (request.getPublicationYear() == null) {
                return ResponseEntity.badRequest().body("Рік видання є обов'язковим");
            }

            BookDTO createdBook = bookService.createBook(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdBook);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Помилка при створенні книги: " + e.getMessage());
        }
    }

    /**
     * Оновити існуючу книгу
     * @param id ідентифікатор книги для оновлення
     * @param request оновлені дані книги
     * @return оновлена книга та статус OK, або NOT_FOUND якщо книга не знайдена
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> updateBook(@PathVariable Long id, @RequestBody CreateBookRequest request) {
        try {
            BookDTO updatedBook = bookService.updateBook(id, request);
            if (updatedBook != null) {
                return ResponseEntity.ok(updatedBook);
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("Книгу з ID " + id + " не знайдено для оновлення");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Помилка при оновленні книги: " + e.getMessage());
        }
    }

    /**
     * Видалити книгу
     * @param id ідентифікатор книги для видалення
     * @return статус OK при успішному видаленні, або NOT_FOUND якщо книга не знайдена
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteBook(@PathVariable Long id) {
        boolean deleted = bookService.deleteBook(id);
        if (deleted) {
            return ResponseEntity.ok("Книгу успішно видалено");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Книгу з ID " + id + " не знайдено для видалення");
        }
    }

    /**
     * Пошук книг за різними параметрами
     * @param searchRequest параметри пошуку
     * @return список знайдених книг та статус OK
     */
    @PostMapping("/search")
    public ResponseEntity<List<BookDTO>> searchBooks(@RequestBody BookSearchRequest searchRequest) {
        List<BookDTO> books = bookService.searchBooks(searchRequest);
        return ResponseEntity.ok(books);
    }

    /**
     * Спрощений пошук за назвою (GET запит)
     * @param title назва книги для пошуку
     * @return список знайдених книг та статус OK
     */
    @GetMapping("/search/title")
    public ResponseEntity<List<BookDTO>> searchByTitle(@RequestParam String title) {
        BookSearchRequest searchRequest = new BookSearchRequest();
        searchRequest.setTitle(title);
        List<BookDTO> books = bookService.searchBooks(searchRequest);
        return ResponseEntity.ok(books);
    }

    /**
     * Спрощений пошук за автором (GET запит)
     * @param author автор для пошуку
     * @return список знайдених книг та статус OK
     */
    @GetMapping("/search/author")
    public ResponseEntity<List<BookDTO>> searchByAuthor(@RequestParam String author) {
        BookSearchRequest searchRequest = new BookSearchRequest();
        searchRequest.setAuthorFullName(author);
        List<BookDTO> books = bookService.searchBooks(searchRequest);
        return ResponseEntity.ok(books);
    }

    /**
     * Отримати список бестселерів
     * @return список бестселерів та статус OK
     */
    @GetMapping("/bestsellers")
    public ResponseEntity<List<BookDTO>> getBestsellers() {
        BookSearchRequest searchRequest = new BookSearchRequest();
        searchRequest.setBestsellersOnly(true);
        List<BookDTO> books = bookService.searchBooks(searchRequest);
        return ResponseEntity.ok(books);
    }
}