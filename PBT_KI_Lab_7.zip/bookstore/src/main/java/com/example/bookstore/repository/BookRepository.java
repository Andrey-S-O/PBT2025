package com.example.bookstore.repository;

import com.example.bookstore.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Репозиторій для роботи з книгами в базі даних
 * Надає методи для основних операцій CRUD та спеціалізовані запити
 */
@Repository
public interface BookRepository extends JpaRepository<Book, Long>, JpaSpecificationExecutor<Book> {

    // Знайти книги за назвою (точний збіг)
    List<Book> findByTitle(String title);

    // Знайти книги за назвою (частковий збіг, ігноруючи регістр)
    List<Book> findByTitleContainingIgnoreCase(String title);

    // Знайти книги за автором (частковий збіг, ігноруючи регістр)
    List<Book> findByAuthorFullNameContainingIgnoreCase(String authorFullName);

    // Знайти книги за роком видання
    List<Book> findByPublicationYear(Integer publicationYear);

    // Знайти книги за жанром (частковий збіг, ігноруючи регістр)
    List<Book> findByGenreContainingIgnoreCase(String genre);

    // Знайти книги за видавництвом (частковий збіг, ігноруючи регістр)
    List<Book> findByPublisherContainingIgnoreCase(String publisher);

    // Знайти книги за кількістю сторінок в діапазоні
    List<Book> findByPageCountBetween(Integer minPages, Integer maxPages);

    // Знайти бестселери
    List<Book> findByIsBestsellerTrue();

    // Знайти книги за роком видання та жанром
    List<Book> findByPublicationYearAndGenreContainingIgnoreCase(Integer publicationYear, String genre);

    // Знайти книги за автором та жанром
    List<Book> findByAuthorFullNameContainingIgnoreCaseAndGenreContainingIgnoreCase(String author, String genre);

    // Спеціальний запит: знайти останнє видання книги за назвою та автором
    @Query("SELECT b FROM Book b WHERE b.title = :title AND b.authorFullName = :author ORDER BY b.publicationYear DESC LIMIT 1")
    Optional<Book> findLatestEditionByTitleAndAuthor(@Param("title") String title, @Param("author") String author);

    // Спеціальний запит: знайти книги видавництва за поточний рік
    @Query("SELECT b FROM Book b WHERE b.publisher = :publisher AND b.publicationYear = YEAR(CURRENT_DATE)")
    List<Book> findByPublisherAndCurrentYear(@Param("publisher") String publisher);

    // Спеціальний запит: пошук за ключовим словом в описі
    @Query("SELECT b FROM Book b WHERE LOWER(b.shortDescription) LIKE LOWER(CONCAT('%', :searchTerm, '%'))")
    List<Book> findBySearchTermInDescription(@Param("searchTerm") String searchTerm);

    // Спеціальний запит: знайти книги за автором, жанром та роком видання
    @Query("SELECT b FROM Book b WHERE b.authorFullName LIKE %:author% AND b.genre LIKE %:genre% AND b.publicationYear = :year")
    List<Book> findByAuthorGenreAndYear(@Param("author") String author, @Param("genre") String genre, @Param("year") Integer year);
}