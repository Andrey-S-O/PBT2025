package com.example.bookstore.dto;

/**
 * DTO для створення нової книги
 * Не включає поля, які генеруються автоматично (id, дати)
 */
public class CreateBookRequest {
    private String title;
    private String authorFullName;
    private Integer publicationYear;
    private String publisher;
    private String genre;
    private Integer pageCount;
    private String shortDescription;
    private Integer circulation;
    private Boolean isBestseller;

    // Конструктори
    public CreateBookRequest() {}

    // Гетери та сетери
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getAuthorFullName() { return authorFullName; }
    public void setAuthorFullName(String authorFullName) { this.authorFullName = authorFullName; }

    public Integer getPublicationYear() { return publicationYear; }
    public void setPublicationYear(Integer publicationYear) { this.publicationYear = publicationYear; }

    public String getPublisher() { return publisher; }
    public void setPublisher(String publisher) { this.publisher = publisher; }

    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }

    public Integer getPageCount() { return pageCount; }
    public void setPageCount(Integer pageCount) { this.pageCount = pageCount; }

    public String getShortDescription() { return shortDescription; }
    public void setShortDescription(String shortDescription) { this.shortDescription = shortDescription; }

    public Integer getCirculation() { return circulation; }
    public void setCirculation(Integer circulation) { this.circulation = circulation; }

    public Boolean getIsBestseller() { return isBestseller; }
    public void setIsBestseller(Boolean isBestseller) { this.isBestseller = isBestseller; }
}