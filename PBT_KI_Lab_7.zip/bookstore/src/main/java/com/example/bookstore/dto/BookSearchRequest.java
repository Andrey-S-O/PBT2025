package com.example.bookstore.dto;

/**
 * DTO для пошуку книг з різними параметрами
 * Використовується для фільтрації книг за різними критеріями
 */
public class BookSearchRequest {
    private String title;
    private String authorFullName;
    private Integer minPages;
    private Integer maxPages;
    private String authorForTitle;
    private String publisher;
    private Integer publicationYear;
    private String genre;
    private Boolean bestsellersOnly;
    private String searchTermInDescription;

    // Конструктори
    public BookSearchRequest() {}

    // Гетери та сетери
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getAuthorFullName() { return authorFullName; }
    public void setAuthorFullName(String authorFullName) { this.authorFullName = authorFullName; }

    public Integer getMinPages() { return minPages; }
    public void setMinPages(Integer minPages) { this.minPages = minPages; }

    public Integer getMaxPages() { return maxPages; }
    public void setMaxPages(Integer maxPages) { this.maxPages = maxPages; }

    public String getAuthorForTitle() { return authorForTitle; }
    public void setAuthorForTitle(String authorForTitle) { this.authorForTitle = authorForTitle; }

    public String getPublisher() { return publisher; }
    public void setPublisher(String publisher) { this.publisher = publisher; }

    public Integer getPublicationYear() { return publicationYear; }
    public void setPublicationYear(Integer publicationYear) { this.publicationYear = publicationYear; }

    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }

    public Boolean getBestsellersOnly() { return bestsellersOnly; }
    public void setBestsellersOnly(Boolean bestsellersOnly) { this.bestsellersOnly = bestsellersOnly; }

    public String getSearchTermInDescription() { return searchTermInDescription; }
    public void setSearchTermInDescription(String searchTermInDescription) { this.searchTermInDescription = searchTermInDescription; }
}