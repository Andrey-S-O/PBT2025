package com.example.bookstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Головний клас Spring Boot додатку
 * Запускає весь REST API для управління книгами
 */
@SpringBootApplication
public class BookstoreApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookstoreApplication.class, args);
        System.out.println("=========================================");
        System.out.println(" REST API для управління книгами запущено!");
        System.out.println(" Доступні endpoints:");
        System.out.println("   GET    /api/books - Отримати всі книги");
        System.out.println("   GET    /api/books/{id} - Отримати книгу за ID");
        System.out.println("   POST   /api/books - Створити нову книгу");
        System.out.println("   PUT    /api/books/{id} - Оновити книгу");
        System.out.println("   DELETE /api/books/{id} - Видалити книгу");
        System.out.println("   POST   /api/books/search - Пошук книг");
        System.out.println("   GET    /api/books/search/title - Пошук за назвою");
        System.out.println("   GET    /api/books/search/author - Пошук за автором");
        System.out.println("   GET    /api/books/bestsellers - Отримати бестселери");
        System.out.println("=========================================");
    }
}