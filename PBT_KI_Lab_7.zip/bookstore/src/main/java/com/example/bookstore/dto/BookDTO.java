package com.example.bookstore.dto;

import java.time.LocalDateTime;

/**
 * DTO для передачі даних про книгу клієнту
 * Використовується для відображення даних без зайвих деталей
 */
public class BookDTO {
    private Long id;
    private String title;
    private String authorFullName;
    private Integer publicationYear;
    private String publisher;
    private String genre;
    private Integer pageCount;
    private String shortDescription;
    private Integer circulation;
    private Boolean isBestseller;
    private LocalDateTime createdAt;

    // Конструктори
    public BookDTO() {}

    public BookDTO(Long id, String title, String authorFullName, Integer publicationYear,
                   String publisher, String genre, Integer pageCount,
                   String shortDescription, Integer circulation, Boolean isBestseller) {
        this.id = id;
        this.title = title;
        this.authorFullName = authorFullName;
        this.publicationYear = publicationYear;
        this.publisher = publisher;
        this.genre = genre;
        this.pageCount = pageCount;
        this.shortDescription = shortDescription;
        this.circulation = circulation;
        this.isBestseller = isBestseller;
    }

    // Гетери та сетери
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getAuthorFullName() { return authorFullName; }
    public void setAuthorFullName(String authorFullName) { this.authorFullName = authorFullName; }

    public Integer getPublicationYear() { return publicationYear; }
    public void setPublicationYear(Integer publicationYear) { this.publicationYear = publicationYear; }

    public String getPublisher() { return publisher; }
    public void setPublisher(String publisher) { this.publisher = publisher; }

    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }

    public Integer getPageCount() { return pageCount; }
    public void setPageCount(Integer pageCount) { this.pageCount = pageCount; }

    public String getShortDescription() { return shortDescription; }
    public void setShortDescription(String shortDescription) { this.shortDescription = shortDescription; }

    public Integer getCirculation() { return circulation; }
    public void setCirculation(Integer circulation) { this.circulation = circulation; }

    public Boolean getIsBestseller() { return isBestseller; }
    public void setIsBestseller(Boolean isBestseller) { this.isBestseller = isBestseller; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}