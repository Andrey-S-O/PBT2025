package com.example.bookstore.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Сущність книги, що представляє таблицу в базі даних
 * Включає всі необхідні поля про книгу згідно з вимогами
 */
@Entity
@Table(name = "books")
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "title", nullable = false, length = 500)
    private String title;

    @Column(name = "author_full_name", nullable = false, length = 255)
    private String authorFullName;

    @Column(name = "publication_year", nullable = false)
    private Integer publicationYear;

    @Column(name = "publisher", nullable = false, length = 255)
    private String publisher;

    @Column(name = "genre", nullable = false, length = 100)
    private String genre;

    @Column(name = "page_count", nullable = false)
    private Integer pageCount;

    @Column(name = "short_description", columnDefinition = "TEXT")
    private String shortDescription;

    @Column(name = "circulation")
    private Integer circulation;

    @Column(name = "is_bestseller")
    private Boolean isBestseller = false;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    // Конструктори
    public Book() {}

    public Book(String title, String authorFullName, Integer publicationYear,
                String publisher, String genre, Integer pageCount,
                String shortDescription, Integer circulation, Boolean isBestseller) {
        this.title = title;
        this.authorFullName = authorFullName;
        this.publicationYear = publicationYear;
        this.publisher = publisher;
        this.genre = genre;
        this.pageCount = pageCount;
        this.shortDescription = shortDescription;
        this.circulation = circulation;
        this.isBestseller = isBestseller;
    }

    // Методи життєвого циклу
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Гетери та сетери
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getAuthorFullName() { return authorFullName; }
    public void setAuthorFullName(String authorFullName) { this.authorFullName = authorFullName; }

    public Integer getPublicationYear() { return publicationYear; }
    public void setPublicationYear(Integer publicationYear) { this.publicationYear = publicationYear; }

    public String getPublisher() { return publisher; }
    public void setPublisher(String publisher) { this.publisher = publisher; }

    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }

    public Integer getPageCount() { return pageCount; }
    public void setPageCount(Integer pageCount) { this.pageCount = pageCount; }

    public String getShortDescription() { return shortDescription; }
    public void setShortDescription(String shortDescription) { this.shortDescription = shortDescription; }

    public Integer getCirculation() { return circulation; }
    public void setCirculation(Integer circulation) { this.circulation = circulation; }

    public Boolean getIsBestseller() { return isBestseller; }
    public void setIsBestseller(Boolean isBestseller) { this.isBestseller = isBestseller; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}