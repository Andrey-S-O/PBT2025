package com.example.bookstore.service;

import com.example.bookstore.dto.BookDTO;
import com.example.bookstore.dto.CreateBookRequest;
import com.example.bookstore.dto.BookSearchRequest;
import com.example.bookstore.entity.Book;
import com.example.bookstore.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Сервісний шар для бізнес-логіки роботи з книгами
 * Обробляє операції CRUD та складні пошукові запити
 */
@Service
public class BookService {

    private final BookRepository bookRepository;

    @Autowired
    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    /**
     * Отримати всі книги
     * @return список всіх книг у вигляді DTO
     */
    public List<BookDTO> getAllBooks() {
        return bookRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Знайти книгу за ID
     * @param id ідентифікатор книги
     * @return книга у вигляді DTO або null, якщо не знайдено
     */
    public BookDTO getBookById(Long id) {
        Optional<Book> book = bookRepository.findById(id);
        return book.map(this::convertToDTO).orElse(null);
    }

    /**
     * Створити нову книгу
     * @param request DTO з даними для створення книги
     * @return створена книга у вигляді DTO
     */
    public BookDTO createBook(CreateBookRequest request) {
        Book book = new Book(
                request.getTitle(),
                request.getAuthorFullName(),
                request.getPublicationYear(),
                request.getPublisher(),
                request.getGenre(),
                request.getPageCount(),
                request.getShortDescription(),
                request.getCirculation(),
                request.getIsBestseller()
        );

        Book savedBook = bookRepository.save(book);
        return convertToDTO(savedBook);
    }

    /**
     * Оновити існуючу книгу
     * @param id ідентифікатор книги для оновлення
     * @param request DTO з оновленими даними
     * @return оновлена книга у вигляді DTO або null, якщо книга не знайдена
     */
    public BookDTO updateBook(Long id, CreateBookRequest request) {
        Optional<Book> existingBook = bookRepository.findById(id);

        if (existingBook.isPresent()) {
            Book book = existingBook.get();
            book.setTitle(request.getTitle());
            book.setAuthorFullName(request.getAuthorFullName());
            book.setPublicationYear(request.getPublicationYear());
            book.setPublisher(request.getPublisher());
            book.setGenre(request.getGenre());
            book.setPageCount(request.getPageCount());
            book.setShortDescription(request.getShortDescription());
            book.setCirculation(request.getCirculation());
            book.setIsBestseller(request.getIsBestseller());

            Book updatedBook = bookRepository.save(book);
            return convertToDTO(updatedBook);
        }

        return null;
    }

    /**
     * Видалити книгу за ID
     * @param id ідентифікатор книги для видалення
     * @return true, якщо книга видалена, false - якщо не знайдена
     */
    public boolean deleteBook(Long id) {
        if (bookRepository.existsById(id)) {
            bookRepository.deleteById(id);
            return true;
        }
        return false;
    }

    /**
     * Пошук книг за різними параметрами
     * @param searchRequest об'єкт з параметрами пошуку
     * @return список знайдених книг у вигляді DTO
     */
    public List<BookDTO> searchBooks(BookSearchRequest searchRequest) {
        List<Book> books;

        // Пошук за назвою
        if (searchRequest.getTitle() != null && !searchRequest.getTitle().isEmpty()) {
            books = bookRepository.findByTitleContainingIgnoreCase(searchRequest.getTitle());
        }
        // Пошук за автором
        else if (searchRequest.getAuthorFullName() != null && !searchRequest.getAuthorFullName().isEmpty()) {
            books = bookRepository.findByAuthorFullNameContainingIgnoreCase(searchRequest.getAuthorFullName());
        }
        // Пошук за кількістю сторінок
        else if (searchRequest.getMinPages() != null || searchRequest.getMaxPages() != null) {
            Integer minPages = searchRequest.getMinPages() != null ? searchRequest.getMinPages() : 0;
            Integer maxPages = searchRequest.getMaxPages() != null ? searchRequest.getMaxPages() : Integer.MAX_VALUE;
            books = bookRepository.findByPageCountBetween(minPages, maxPages);
        }
        // Останнє видання книги за назвою та автором
        else if (searchRequest.getAuthorForTitle() != null && !searchRequest.getAuthorForTitle().isEmpty()) {
            // Це спрощена реалізація - в реальному додатку потрібен більш складний підхід
            books = bookRepository.findByAuthorFullNameContainingIgnoreCase(searchRequest.getAuthorForTitle());
        }
        // Книги видавництва за поточний рік
        else if (searchRequest.getPublisher() != null && !searchRequest.getPublisher().isEmpty()) {
            books = bookRepository.findByPublisherAndCurrentYear(searchRequest.getPublisher());
        }
        // Пошук за роком видання
        else if (searchRequest.getPublicationYear() != null) {
            books = bookRepository.findByPublicationYear(searchRequest.getPublicationYear());
        }
        // Пошук за жанром, автором та роком видання
        else if (searchRequest.getGenre() != null && searchRequest.getAuthorFullName() != null && searchRequest.getPublicationYear() != null) {
            books = bookRepository.findByAuthorGenreAndYear(
                    searchRequest.getAuthorFullName(),
                    searchRequest.getGenre(),
                    searchRequest.getPublicationYear()
            );
        }
        // Бестселери
        else if (searchRequest.getBestsellersOnly() != null && searchRequest.getBestsellersOnly()) {
            books = bookRepository.findByIsBestsellerTrue();
        }
        // Пошук за ключовим словом в описі
        else if (searchRequest.getSearchTermInDescription() != null && !searchRequest.getSearchTermInDescription().isEmpty()) {
            books = bookRepository.findBySearchTermInDescription(searchRequest.getSearchTermInDescription());
        }
        // Якщо параметри не вказані, повертаємо всі книги
        else {
            books = bookRepository.findAll();
        }

        return books.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Конвертує сутність Book в BookDTO
     * @param book сутність книги
     * @return DTO об'єкт книги
     */
    private BookDTO convertToDTO(Book book) {
        BookDTO dto = new BookDTO();
        dto.setId(book.getId());
        dto.setTitle(book.getTitle());
        dto.setAuthorFullName(book.getAuthorFullName());
        dto.setPublicationYear(book.getPublicationYear());
        dto.setPublisher(book.getPublisher());
        dto.setGenre(book.getGenre());
        dto.setPageCount(book.getPageCount());
        dto.setShortDescription(book.getShortDescription());
        dto.setCirculation(book.getCirculation());
        dto.setIsBestseller(book.getIsBestseller());
        dto.setCreatedAt(book.getCreatedAt());
        return dto;
    }
}