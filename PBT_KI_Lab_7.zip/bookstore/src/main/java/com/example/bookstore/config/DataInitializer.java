package com.example.bookstore.config;

import com.example.bookstore.entity.Book;
import com.example.bookstore.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * Клас для ініціалізації тестових даних при запуску додатку
 * Додає кілька прикладів книг для тестування функціоналу
 */
@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private BookRepository bookRepository;

    @Override
    public void run(String... args) throws Exception {
        // Додаємо тестові дані, якщо база даних порожня
        if (bookRepository.count() == 0) {
            System.out.println(" Ініціалізація тестових даних про книги...");

            bookRepository.save(new Book(
                    "Хіба ревуть воли, як ясла повні?",
                    "Панас Мирний",
                    1880,
                    "Українська письменніцька спілка",
                    "Роман",
                    450,
                    "Соціально-побутовий роман про життя українського селянства",
                    5000,
                    true
            ));

            bookRepository.save(new Book(
                    "Тигролови",
                    "Іван Багряний",
                    1944,
                    "Українське видавництво",
                    "Пригоди",
                    320,
                    "Захоплююча повість про полювання на тигрів та виживання в дикій природі",
                    3000,
                    false
            ));

            bookRepository.save(new Book(
                    "Камінний хрест",
                    "Василь Стефаник",
                    1900,
                    "Літературне агентство",
                    "Новели",
                    280,
                    "Збірка психологічних новел про життя галицьких селян",
                    2500,
                    true
            ));

            bookRepository.save(new Book(
                    "Собор",
                    "Олесь Гончар",
                    1968,
                    "Радянський письменник",
                    "Роман",
                    550,
                    "Філософський роман про духовність та моральні цінності",
                    10000,
                    true
            ));

            bookRepository.save(new Book(
                    "Майстерня брехні",
                    "Володимир Винниченко",
                    1920,
                    "Зарубіжна література",
                    "Драма",
                    190,
                    "Психологічна драма про боротьбу з внутрішніми демонами",
                    2000,
                    false
            ));

            System.out.println(" Тестові дані успішно додано до бази даних!");
            System.out.println(" Загальна кількість книг: " + bookRepository.count());
        }
    }
}