package org.example;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

/**
 * Головний клас додатку "Бібліотечний каталог".
 * Відповідає за взаємодію з користувачем через консольний інтерфейс.
 * Координує роботу сервісів та відображення інформації.
 */
public class LibraryCatalogApp {
    // Сервіс для бізнес-логіки каталогу
    private final LibraryService service;
    // Сканер для читання вводу користувача
    private final Scanner scanner;

    /**
     * Конструктор додатку - ініціалізує залежності
     */
    public LibraryCatalogApp() {
        // Створюємо реалізацію репозиторію та передаємо її в сервіс
        LibraryRepository repository = new LibraryRepositoryImpl();
        this.service = new LibraryService(repository);
        this.scanner = new Scanner(System.in);
    }

    /**
     * Головний метод запуску додатку
     * Відображає головне меню та обробляє вибір користувача
     */
    public void run() {
        System.out.println("=== ЛАСКАВО ПРОСИМО ДО СИСТЕМИ БІБЛІОТЕЧНОГО КАТАЛОГУ ===");

        boolean running = true;
        while (running) {
            displayMainMenu();
            String choice = scanner.nextLine();

            // Обробка вибору користувача
            switch (choice) {
                case "1":
                    initializeTestData();
                    break;
                case "2":
                    addSpecificItemMenu();
                    break;
                case "3":
                    addRandomItem();
                    break;
                case "4":
                    removeItemMenu();
                    break;
                case "5":
                    updateItemMenu();
                    break;
                case "6":
                    displayAllItems();
                    break;
                case "7":
                    displayItemsGroupedByType();
                    break;
                case "8":
                    searchItemsMenu();
                    break;
                case "9":
                    displayItemsWithIds();
                    break;
                case "0":
                    running = false;
                    System.out.println("Дякуємо за використання системи бібліотечного каталогу. До побачення!");
                    break;
                default:
                    System.out.println("Невірний вибір. Будь ласка, спробуйте ще раз.");
            }
        }
    }

    /**
     * Відображення головного меню додатку
     */
    private void displayMainMenu() {
        System.out.println("\n=== ГОЛОВНЕ МЕНЮ ===");
        System.out.println("1. Ініціалізувати тестові дані");
        System.out.println("2. Додати конкретний елемент");
        System.out.println("3. Додати випадковий елемент");
        System.out.println("4. Видалити елемент");
        System.out.println("5. Оновити елемент");
        System.out.println("6. Відобразити всі елементи");
        System.out.println("7. Відобразити елементи згруповані за типом");
        System.out.println("8. Пошук елементів");
        System.out.println("9. Відобразити елементи з ID");
        System.out.println("0. Вийти");
        System.out.print("Введіть ваш вибір: ");
    }

    /**
     * Ініціалізація тестових даних через сервіс
     */
    private void initializeTestData() {
        service.initializeTestData();
    }

    /**
     * Меню для додавання конкретного елементу
     * Запитує у користувача тип елементу та його дані
     */
    private void addSpecificItemMenu() {
        System.out.println("\n=== ДОДАВАННЯ КОНКРЕТНОГО ЕЛЕМЕНТУ ===");
        System.out.println("Виберіть тип елементу:");
        System.out.println("1. Книга");
        System.out.println("2. Газета");
        System.out.println("3. Альманах");
        System.out.print("Введіть ваш вибір: ");

        String typeChoice = scanner.nextLine();

        // Виклик відповідного методу залежно від вибору типу
        switch (typeChoice) {
            case "1":
                addBook();
                break;
            case "2":
                addNewspaper();
                break;
            case "3":
                addAlmanac();
                break;
            default:
                System.out.println("Невірний вибір.");
        }
    }

    /**
     * Додавання нової книги - запит даних у користувача
     */
    private void addBook() {
        System.out.println("\n--- Додати нову книгу ---");
        System.out.print("Введіть назву: ");
        String title = scanner.nextLine();
        System.out.print("Введіть автора: ");
        String author = scanner.nextLine();
        System.out.print("Введіть жанр: ");
        String genre = scanner.nextLine();
        System.out.print("Введіть рік: ");
        int year = Integer.parseInt(scanner.nextLine());
        System.out.print("Введіть видавництво: ");
        String publisher = scanner.nextLine();
        System.out.print("Введіть кількість сторінок: ");
        int pages = Integer.parseInt(scanner.nextLine());

        // Створення об'єкта книги за допомогою патерну Builder
        Book book = Book.builder()
                .title(title)
                .author(author)
                .genre(genre)
                .year(year)
                .publisher(publisher)
                .pages(pages)
                .build();

        service.addSpecificItem(book);
    }

    /**
     * Додавання нової газети - запит даних у користувача
     */
    private void addNewspaper() {
        System.out.println("\n--- Додати нову газету ---");
        System.out.print("Введіть назву газети: ");
        String name = scanner.nextLine();
        System.out.print("Введіть номер випуску: ");
        int issueNumber = Integer.parseInt(scanner.nextLine());
        System.out.print("Введіть рік видання: ");
        int year = Integer.parseInt(scanner.nextLine());
        System.out.print("Введіть видавництво: ");
        String publisher = scanner.nextLine();

        // Для спрощення використовуємо поточну дату
        LocalDate publicationDate = LocalDate.now();

        // Проста настройка колонок - одна колонка за замовчуванням
        List<NewspaperColumn> columns = List.of(
                new NewspaperColumn("Головні новини", "Редакційна команда")
        );

        Newspaper newspaper = Newspaper.builder()
                .name(name)
                .issueNumber(issueNumber)
                .publicationDate(publicationDate)
                .publisher(publisher)
                .year(year)
                .columns(columns)
                .build();

        service.addSpecificItem(newspaper);
    }

    /**
     * Додавання нового альманаху - запит даних у користувача
     */
    private void addAlmanac() {
        System.out.println("\n--- Додати новий альманах ---");
        System.out.print("Введіть назву альманаху: ");
        String name = scanner.nextLine();
        System.out.print("Введіть жанр: ");
        String genre = scanner.nextLine();
        System.out.print("Введіть рік: ");
        int year = Integer.parseInt(scanner.nextLine());
        System.out.print("Введіть видавництво: ");
        String publisher = scanner.nextLine();
        System.out.print("Введіть кількість сторінок: ");
        int pages = Integer.parseInt(scanner.nextLine());

        // Для спрощення створюємо один приклад твору
        Book sampleWork = Book.builder()
                .title("Приклад твору в " + name)
                .author("Різні автори")
                .genre("Збірник")
                .year(year)
                .publisher(publisher)
                .pages(10)
                .build();

        Almanac almanac = Almanac.builder()
                .almanacName(name)
                .genre(genre)
                .year(year)
                .publisher(publisher)
                .pages(pages)
                .works(List.of(sampleWork))
                .build();

        service.addSpecificItem(almanac);
    }

    /**
     * Додавання випадкового елементу через сервіс
     */
    private void addRandomItem() {
        service.addRandomItem();
    }

    /**
     * Меню для видалення елементу
     * Спочатку відображає елементи з ID, потім запитує ID для видалення
     */
    private void removeItemMenu() {
        // Показуємо всі елементи з їх ID для зручності
        service.displayAllItemsWithIds();
        System.out.print("\nВведіть ID елементу для видалення: ");
        try {
            int id = Integer.parseInt(scanner.nextLine());
            service.removeItem(id);
        } catch (NumberFormatException e) {
            System.out.println("Невірний формат ID.");
        }
    }

    /**
     * Меню для оновлення елементу
     * У спрощеній версії пропонує повторно ввести дані елементу
     */
    private void updateItemMenu() {
        service.displayAllItemsWithIds();
        System.out.println("\nПримітка: Для оновлення потрібно повторно ввести дані елементу.");
        System.out.print("Введіть ID елементу для оновлення: ");
        try {
            int id = Integer.parseInt(scanner.nextLine());
            // У справжньому додатку тут буде більш складна логіка оновлення
            System.out.println("Будь ласка, повторно введіть дані елементу:");
            addSpecificItemMenu();
        } catch (NumberFormatException e) {
            System.out.println("Невірний формат ID.");
        }
    }

    /**
     * Відображення всіх елементів каталогу
     */
    private void displayAllItems() {
        service.displayAllItems();
    }

    /**
     * Відображення елементів, згрупованих за типом
     */
    private void displayItemsGroupedByType() {
        service.displayItemsGroupedByType();
    }

    /**
     * Меню для пошуку елементів
     * Запитує критерій пошуку та значення для пошуку
     */
    private void searchItemsMenu() {
        System.out.println("\n=== ПОШУК ЕЛЕМЕНТІВ ===");
        System.out.println("Шукати за:");
        System.out.println("1. Назвою");
        System.out.println("2. Видавництвом");
        System.out.println("3. Роком видання");
        System.out.println("4. Автором");
        System.out.print("Введіть ваш вибір: ");

        String searchChoice = scanner.nextLine();
        String criteria = "";
        String prompt = "";

        // Визначаємо критерій пошуку та текст підказки
        switch (searchChoice) {
            case "1":
                criteria = "title";
                prompt = "Введіть назву для пошуку: ";
                break;
            case "2":
                criteria = "publisher";
                prompt = "Введіть видавництво для пошуку: ";
                break;
            case "3":
                criteria = "year";
                prompt = "Введіть рік для пошуку: ";
                break;
            case "4":
                criteria = "author";
                prompt = "Введіть автора для пошуку: ";
                break;
            default:
                System.out.println("Невірний вибір.");
                return;
        }

        System.out.print(prompt);
        String value = scanner.nextLine();

        // Виконуємо пошук через сервіс
        service.searchItems(criteria, value);
    }

    /**
     * Відображення елементів з їх ID
     */
    private void displayItemsWithIds() {
        service.displayAllItemsWithIds();
    }

    /**
     * Головний метод програми - точка входу
     */
    public static void main(String[] args) {
        // Створюємо екземпляр додатку та запускаємо його
        LibraryCatalogApp app = new LibraryCatalogApp();
        app.run();
    }
}