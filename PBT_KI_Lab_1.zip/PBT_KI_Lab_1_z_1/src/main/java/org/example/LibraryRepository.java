package org.example;

import java.util.List;
import java.util.Optional;

/**
 * Інтерфейс репозиторію для роботи з бібліотечним каталогом.
 * Визначає контракт для всіх операцій з даними.
 * Відповідає принципу інверсії залежностей (Dependency Inversion) з SOLID -
 * клієнтський код залежить від абстракції, а не від конкретної реалізації.
 */
public interface LibraryRepository {
    /**
     * Додати новий елемент до каталогу
     * @param item публікація для додавання
     */
    void addItem(Publication item);

    /**
     * Видалити елемент за ідентифікатором
     * @param id ідентифікатор елемента
     * @return true якщо елемент був видалений, false якщо не знайдено
     */
    boolean removeItem(int id);

    /**
     * Отримати елемент за ідентифікатором
     * @param id ідентифікатор елемента
     * @return Optional з елементом, якщо знайдено
     */
    Optional<Publication> getItem(int id);

    /**
     * Отримати всі елементи каталогу
     * @return список всіх публікацій
     */
    List<Publication> getAllItems();

    /**
     * Пошук елементів за критеріями
     * @param criteria тип критерію пошуку (title, publisher, year, author)
     * @param value значення для пошуку
     * @return список знайдених публікацій
     */
    List<Publication> searchByCriteria(String criteria, String value);

    /**
     * Отримати елементи за типом
     * @param type тип публікації (BOOK, NEWSPAPER, ALMANAC)
     * @return список публікацій вказаного типу
     */
    List<Publication> getItemsByType(String type);

    /**
     * Оновити існуючий елемент
     * @param id ідентифікатор елемента для оновлення
     * @param updatedItem оновлена версія елемента
     * @return true якщо елемент був оновлений, false якщо не знайдено
     */
    boolean updateItem(int id, Publication updatedItem);

    /**
     * Очистити весь каталог
     */
    void clear();

    /**
     * Отримати наступний доступний ідентифікатор
     * @return наступний ID для нового елемента
     */
    int getNextId();
}