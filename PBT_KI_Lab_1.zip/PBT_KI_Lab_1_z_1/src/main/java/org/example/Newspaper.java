package org.example;

import lombok.*;
import java.time.LocalDate;
import java.util.List;

/**
 * Клас, що представляє газету в бібліотечному каталозі.
 * Наслідується від LibraryItem та додає специфічні для газет властивості.
 */
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class Newspaper extends LibraryItem {
    // Специфічні поля для газет
    private int issueNumber;           // Номер випуску газети
    private String name;               // Назва газети
    private LocalDate publicationDate; // Дата публікації
    private List<NewspaperColumn> columns; // Список колонок газети

    /**
     * Конструктор з використанням патерну Builder
     */
    @Builder
    public Newspaper(String name, int issueNumber, LocalDate publicationDate,
                     List<NewspaperColumn> columns, String publisher, int year) {
        this.name = name;
        this.issueNumber = issueNumber;
        this.publicationDate = publicationDate;
        this.columns = columns;
        this.publisher = publisher;
        this.year = year;
        // Формуємо заголовок як комбінацію назви та номера випуску
        this.title = name + " - Випуск №" + issueNumber;
    }

    /**
     * Реалізація методу отримання типу публікації
     * @return рядок "NEWSPAPER" - ідентифікатор типу газети
     */
    @Override
    public String getType() {
        return "NEWSPAPER";
    }

    /**
     * Реалізація методу виводу інформації про газету
     * Виводить детальну інформацію про газету та її колонки
     */
    @Override
    public void displayInfo() {
        System.out.println("Тип: " + getType());
        System.out.println("Назва: " + name);
        System.out.println("Номер випуску: " + issueNumber);
        System.out.println("Дата публікації: " + publicationDate);
        System.out.println("Видавництво: " + publisher);
        System.out.println("Рік: " + year);
        System.out.println("Колонки:");
        // Виводимо інформацію про кожну колонку
        for (NewspaperColumn column : columns) {
            System.out.println("  - " + column.getColumnName() + " від " + column.getJournalist());
        }
        System.out.println("---------------------------");
    }
}