package org.example;

import lombok.RequiredArgsConstructor;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;

/**
 * Сервісний клас для бізнес-логіки бібліотечного каталогу.
 * Використовує Lombok @RequiredArgsConstructor для автоматичного створення конструктора.
 * Відповідає принципу єдиного обов'язку - обробка бізнес-логіки.
 */
@RequiredArgsConstructor
public class LibraryService {
    // Репозиторій для роботи з даними - ін'єкція залежності через конструктор
    private final LibraryRepository repository;
    // Генератор випадкових чисел для створення випадкових елементів
    private final Random random = new Random();

    /**
     * Ініціалізація тестових даних для каталогу.
     * Створює приклади книг, газет та альманахів для демонстрації.
     */
    public void initializeTestData() {
        System.out.println("Ініціалізація тестових даних...");

        // Додаємо тестові книги
        repository.addItem(Book.builder()
                .title("Великий Гетсбі")
                .author("Ф. Скотт Фіцджеральд")
                .genre("Художня література")
                .year(1925)
                .publisher("Scribner")
                .pages(218)
                .build());

        repository.addItem(Book.builder()
                .title("Убити пересмішника")
                .author("Харпер Лі")
                .genre("Художня література")
                .year(1960)
                .publisher("J.B. Lippincott & Co.")
                .pages(281)
                .build());

        repository.addItem(Book.builder()
                .title("1984")
                .author("Джордж Орвелл")
                .genre("Антиутопія")
                .year(1949)
                .publisher("Secker & Warburg")
                .pages(328)
                .build());

        // Додаємо тестові газети
        repository.addItem(Newspaper.builder()
                .name("Щоденні Новини")
                .issueNumber(123)
                .publicationDate(LocalDate.of(2023, 10, 15))
                .publisher("News Corp")
                .year(2023)
                .columns(List.of(
                        new NewspaperColumn("Політика", "Іван Іванов"),
                        new NewspaperColumn("Спорт", "Марія Петренко"),
                        new NewspaperColumn("Розваги", "Микола Коваль")
                ))
                .build());

        repository.addItem(Newspaper.builder()
                .name("Ранковий Час")
                .issueNumber(456)
                .publicationDate(LocalDate.of(2023, 11, 1))
                .publisher("Times Media")
                .year(2023)
                .columns(List.of(
                        new NewspaperColumn("Бізнес", "Ольга Сидоренко"),
                        new NewspaperColumn("Технології", "Данило Білий")
                ))
                .build());

        // Додаємо тестові альманахи
        Book story1 = Book.builder()
                .title("Ворон")
                .author("Едгар Аллан По")
                .genre("Поезія")
                .year(1845)
                .publisher("American Review")
                .pages(4)
                .build();

        Book story2 = Book.builder()
                .title("Серце-обличчя")
                .author("Едгар Аллан По")
                .genre("Жахи")
                .year(1843)
                .publisher("Pioneer")
                .pages(8)
                .build();

        Book story3 = Book.builder()
                .title("Падіння дому Ашерів")
                .author("Едгар Аллан По")
                .genre("Готика")
                .year(1839)
                .publisher("Burton's Gentleman's Magazine")
                .pages(45)
                .build();

        repository.addItem(Almanac.builder()
                .almanacName("Найкращі твори Едгара По")
                .genre("Збірник")
                .year(2020)
                .publisher("Classic Publishers")
                .pages(300)
                .works(List.of(story1, story2, story3))
                .build());

        Book poem1 = Book.builder()
                .title("Сонет 18")
                .author("Вільям Шекспір")
                .genre("Поезія")
                .year(1609)
                .publisher("Thomas Thorpe")
                .pages(1)
                .build();

        Book poem2 = Book.builder()
                .title("Дорога не взята")
                .author("Роберт Фрост")
                .genre("Поезія")
                .year(1916)
                .publisher("Henry Holt")
                .pages(2)
                .build();

        repository.addItem(Almanac.builder()
                .almanacName("Збірник відомих поем")
                .genre("Поезія")
                .year(2018)
                .publisher("Poetry House")
                .pages(150)
                .works(List.of(poem1, poem2))
                .build());

        System.out.println("Тестові дані ініціалізовано. Загальна кількість елементів: " + repository.getAllItems().size());
    }

    /**
     * Додати конкретний елемент до каталогу
     * @param item публікація для додавання
     */
    public void addSpecificItem(Publication item) {
        repository.addItem(item);
        System.out.println("Елемент успішно додано. Загальна кількість елементів: " + repository.getAllItems().size());
    }

    /**
     * Додати випадковий елемент до каталогу
     * Створює елемент випадкового типу з випадковими даними
     */
    public void addRandomItem() {
        Publication randomItem = createRandomItem();
        repository.addItem(randomItem);
        System.out.println("Випадковий елемент успішно додано. Загальна кількість елементів: " + repository.getAllItems().size());
    }

    /**
     * Видалити елемент за ID
     * @param id ідентифікатор елемента для видалення
     * @return true якщо елемент був видалений
     */
    public boolean removeItem(int id) {
        boolean removed = repository.removeItem(id);
        if (removed) {
            System.out.println("Елемент з ID " + id + " успішно видалено.");
        } else {
            System.out.println("Елемент з ID " + id + " не знайдено.");
        }
        return removed;
    }

    /**
     * Оновити існуючий елемент
     * @param id ідентифікатор елемента для оновлення
     * @param updatedItem оновлена версія елемента
     * @return true якщо оновлення пройшло успішно
     */
    public boolean updateItem(int id, Publication updatedItem) {
        boolean updated = repository.updateItem(id, updatedItem);
        if (updated) {
            System.out.println("Елемент з ID " + id + " успішно оновлено.");
        } else {
            System.out.println("Елемент з ID " + id + " не знайдено.");
        }
        return updated;
    }

    /**
     * Відобразити всі елементи каталогу
     * Виводить повну інформацію про кожен елемент
     */
    public void displayAllItems() {
        List<Publication> items = repository.getAllItems();
        if (items.isEmpty()) {
            System.out.println("Каталог порожній.");
            return;
        }

        System.out.println("\n=== ПОВНИЙ БІБЛІОТЕЧНИЙ КАТАЛОГ ===");
        System.out.println("Загальна кількість елементів: " + items.size());
        System.out.println("=================================");

        // Виводимо інформацію про кожен елемент з порядковим номером
        for (int i = 0; i < items.size(); i++) {
            System.out.println("Елемент №" + (i + 1) + ":");
            items.get(i).displayInfo();
        }
    }

    /**
     * Відобразити елементи, згруповані за типом
     * Виводить книги, газети та альманахи окремими групами
     */
    public void displayItemsGroupedByType() {
        List<Publication> items = repository.getAllItems();
        if (items.isEmpty()) {
            System.out.println("Каталог порожній.");
            return;
        }

        System.out.println("\n=== БІБЛІОТЕЧНИЙ КАТАЛОГ (ЗГРУПОВАНО ЗА ТИПОМ) ===");

        // Відображаємо книги
        List<Publication> books = repository.getItemsByType("BOOK");
        if (!books.isEmpty()) {
            System.out.println("\n--- КНИГИ (" + books.size() + " елементів) ---");
            books.forEach(Publication::displayInfo);
        }

        // Відображаємо газети
        List<Publication> newspapers = repository.getItemsByType("NEWSPAPER");
        if (!newspapers.isEmpty()) {
            System.out.println("\n--- ГАЗЕТИ (" + newspapers.size() + " елементів) ---");
            newspapers.forEach(Publication::displayInfo);
        }

        // Відображаємо альманахи
        List<Publication> almanacs = repository.getItemsByType("ALMANAC");
        if (!almanacs.isEmpty()) {
            System.out.println("\n--- АЛЬМАНАХИ (" + almanacs.size() + " елементів) ---");
            almanacs.forEach(Publication::displayInfo);
        }
    }

    /**
     * Пошук елементів за критеріями
     * @param criteria тип критерію (title, publisher, year, author)
     * @param value значення для пошуку
     */
    public void searchItems(String criteria, String value) {
        List<Publication> results = repository.searchByCriteria(criteria, value);

        if (results.isEmpty()) {
            System.out.println("Елементів, що відповідають критеріям пошуку, не знайдено.");
            return;
        }

        System.out.println("\n=== РЕЗУЛЬТАТИ ПОШУКУ ===");
        System.out.println("Пошук за " + criteria + ": '" + value + "'");
        System.out.println("Знайдено " + results.size() + " елемент(ів):");
        System.out.println("=========================");

        // Виводимо знайдені елементи з порядковими номерами
        for (int i = 0; i < results.size(); i++) {
            System.out.println("Результат №" + (i + 1) + ":");
            results.get(i).displayInfo();
        }
    }

    /**
     * Відобразити всі елементи з їх ID
     * Корисно для операцій, що потребують знання ID (видалення, оновлення)
     */
    public void displayAllItemsWithIds() {
        Map<Integer, Publication> items = ((LibraryRepositoryImpl) repository).getItemsMap();

        if (items.isEmpty()) {
            System.out.println("Каталог порожній.");
            return;
        }

        System.out.println("\n=== ЕЛЕМЕНТИ КАТАЛОГУ З ID ===");
        // Виводимо ID, тип та назву кожного елемента
        for (Map.Entry<Integer, Publication> entry : items.entrySet()) {
            System.out.println("ID: " + entry.getKey() + " - " + entry.getValue().getType() +
                    ": " + entry.getValue().getTitle());
        }
    }

    /**
     * Приватний метод для створення випадкового елемента
     * @return випадкова публікація (книга, газета або альманах)
     */
    private Publication createRandomItem() {
        int choice = random.nextInt(3); // Випадкове число 0, 1 або 2
        String randomSuffix = String.valueOf(random.nextInt(1000)); // Випадковий суфікс для унікальності

        switch (choice) {
            case 0: // Створюємо випадкову книгу
                String[] authors = {"Іван Франко", "Леся Українка", "Тарас Шевченко", "Ліна Костенко", "Михайло Коцюбинський"};
                String[] genres = {"Художня література", "Детектив", "Наукова фантастика", "Біографія", "Історична"};
                String[] publishers = {"Радянський письменник", "А-ба-ба-га-ла-ма-га", "Видавництво Старого Лева", "Навчальна книга", "Фоліо"};

                return Book.builder()
                        .title("Випадкова книга " + randomSuffix)
                        .author(authors[random.nextInt(authors.length)])
                        .genre(genres[random.nextInt(genres.length)])
                        .year(1900 + random.nextInt(124)) // Рік від 1900 до 2024
                        .publisher(publishers[random.nextInt(publishers.length)])
                        .pages(100 + random.nextInt(500)) // Від 100 до 600 сторінок
                        .build();

            case 1: // Створюємо випадкову газету
                String[] newspaperNames = {"Щоденний хронік", "Вечірня пошта", "Ранковий вісник", "Тижнева газета", "Метро таймс"};
                String[] journalistNames = {"Анна Коваленко", "Богдан Мельник", "Вікторія Савченко", "Григорій Іваненко", "Дарія Литвин"};
                String[] columnTypes = {"Новини", "Спорт", "Бізнес", "Розваги", "Технології", "Здоров'я"};

                // Створюємо список з 2 випадкових колонок
                List<NewspaperColumn> columns = List.of(
                        new NewspaperColumn(columnTypes[random.nextInt(columnTypes.length)],
                                journalistNames[random.nextInt(journalistNames.length)]),
                        new NewspaperColumn(columnTypes[random.nextInt(columnTypes.length)],
                                journalistNames[random.nextInt(journalistNames.length)])
                );

                return Newspaper.builder()
                        .name(newspaperNames[random.nextInt(newspaperNames.length)])
                        .issueNumber(1 + random.nextInt(1000)) // Номер від 1 до 1000
                        .publicationDate(LocalDate.now().minusDays(random.nextInt(365))) // Дата від сьогодні до року назад
                        .publisher("News Corp " + randomSuffix)
                        .year(2020 + random.nextInt(4)) // Рік від 2020 до 2024
                        .columns(columns)
                        .build();

            case 2: // Створюємо випадковий альманах
                // Спочатку створюємо випадковий твір для альманаху
                Book randomWork = Book.builder()
                        .title("Твір з колекції " + randomSuffix)
                        .author("Автор " + random.nextInt(100))
                        .genre("Оповідання")
                        .year(2000 + random.nextInt(24)) // Рік від 2000 до 2024
                        .publisher("Різні")
                        .pages(10 + random.nextInt(50)) // Від 10 до 60 сторінок
                        .build();

                String[] almanacGenres = {"Збірник", "Антологія", "Компіляція", "Читанка"};

                return Almanac.builder()
                        .almanacName("Альманах " + randomSuffix)
                        .genre(almanacGenres[random.nextInt(almanacGenres.length)])
                        .year(2010 + random.nextInt(14)) // Рік від 2010 до 2024
                        .publisher("Видавництво колекцій")
                        .pages(200 + random.nextInt(300)) // Від 200 до 500 сторінок
                        .works(List.of(randomWork))
                        .build();

            default:
                throw new IllegalStateException("Невірний випадковий вибір");
        }
    }
}