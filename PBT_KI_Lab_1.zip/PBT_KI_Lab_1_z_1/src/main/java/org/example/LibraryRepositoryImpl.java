package org.example;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Реалізація інтерфейсу LibraryRepository.
 * Використовує HashMap для зберігання даних та Stream API для пошуку та фільтрації.
 * Відповідає принципу єдиного обов'язку (Single Responsibility) - тільки робота з даними.
 */
public class LibraryRepositoryImpl implements LibraryRepository {
    // Колекція для зберігання публікацій: ключ - ID, значення - публікація
    private final Map<Integer, Publication> items;
    // Лічильник для генерації унікальних ID
    private int nextId;

    /**
     * Конструктор - ініціалізує колекції та лічильник ID
     */
    public LibraryRepositoryImpl() {
        this.items = new HashMap<>();
        this.nextId = 1;
    }

    /**
     * Додати нову публікацію до каталогу
     * Присвоює унікальний ID та зберігає в колекції
     */
    @Override
    public void addItem(Publication item) {
        items.put(nextId, item);
        nextId++; // Збільшуємо лічильник для наступного елемента
    }

    /**
     * Видалити публікацію за ID
     * @return true якщо елемент існував і був видалений
     */
    @Override
    public boolean removeItem(int id) {
        return items.remove(id) != null;
    }

    /**
     * Отримати публікацію за ID
     * @return Optional з публікацією або пустий Optional якщо не знайдено
     */
    @Override
    public Optional<Publication> getItem(int id) {
        return Optional.ofNullable(items.get(id));
    }

    /**
     * Отримати всі публікації з каталогу
     * @return список всіх публікацій
     */
    @Override
    public List<Publication> getAllItems() {
        return new ArrayList<>(items.values());
    }

    /**
     * Пошук публікацій за різними критеріями
     * Використовує Stream API для фільтрації
     */
    @Override
    public List<Publication> searchByCriteria(String criteria, String value) {
        return items.values().stream()
                .filter(item -> matchesCriteria(item, criteria, value))
                .collect(Collectors.toList());
    }

    /**
     * Отримати публікації за типом
     * Використовує Stream API для фільтрації за типом
     */
    @Override
    public List<Publication> getItemsByType(String type) {
        return items.values().stream()
                .filter(item -> item.getType().equalsIgnoreCase(type))
                .collect(Collectors.toList());
    }

    /**
     * Оновити існуючу публікацію
     * @return true якщо оновлення пройшло успішно
     */
    @Override
    public boolean updateItem(int id, Publication updatedItem) {
        if (items.containsKey(id)) {
            items.put(id, updatedItem);
            return true;
        }
        return false;
    }

    /**
     * Очистити весь каталог - видалити всі публікації
     * Також скидає лічильник ID до початкового значення
     */
    @Override
    public void clear() {
        items.clear();
        nextId = 1;
    }

    /**
     * Отримати наступний доступний ID
     * @return наступний ID для нового елемента
     */
    @Override
    public int getNextId() {
        return nextId;
    }

    /**
     * Приватний метод для перевірки відповідності публікації критеріям пошуку
     * @param item публікація для перевірки
     * @param criteria тип критерію (title, publisher, year, author)
     * @param value значення для пошуку
     * @return true якщо публікація відповідає критеріям
     */
    private boolean matchesCriteria(Publication item, String criteria, String value) {
        // Перевірка на пусте значення
        if (value == null || value.isEmpty()) return false;

        // Обробка різних типів критеріїв
        switch (criteria.toLowerCase()) {
            case "title":
                // Пошук за назвою (нечутливий до регістру)
                return item.getTitle().toLowerCase().contains(value.toLowerCase());
            case "publisher":
                // Пошук за видавництвом (нечутливий до регістру)
                return item.getPublisher().toLowerCase().contains(value.toLowerCase());
            case "year":
                // Пошук за роком видання
                try {
                    return item.getYear() == Integer.parseInt(value);
                } catch (NumberFormatException e) {
                    return false; // Некоректний формат року
                }
            case "author":
                // Пошук за автором (для книг та творів в альманасі)
                if (item instanceof Book) {
                    // Для книг - перевіряємо автора книги
                    return ((Book) item).getAuthor().toLowerCase().contains(value.toLowerCase());
                } else if (item instanceof Almanac) {
                    // Для альманахів - перевіряємо авторів всіх творів
                    return ((Almanac) item).getWorks().stream()
                            .anyMatch(work -> work.getAuthor().toLowerCase().contains(value.toLowerCase()));
                }
                return false;
            default:
                return false; // Невідомий критерій
        }
    }

    /**
     * Метод для отримання копії мапи елементів
     * Використовується для відображення елементів з їх ID
     * @return копія мапи елементів
     */
    public Map<Integer, Publication> getItemsMap() {
        return new HashMap<>(items);
    }
}