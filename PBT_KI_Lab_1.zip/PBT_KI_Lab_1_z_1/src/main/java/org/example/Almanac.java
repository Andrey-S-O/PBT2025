package org.example;

import lombok.*;
import java.util.List;

/**
 * Клас, що представляє альманах (збірник творів) в бібліотечному каталозі.
 * Наслідується від LibraryItem та містить список творів (книг), що входять до альманаху.
 */
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class Almanac extends LibraryItem {
    // Специфічні поля для альманахів
    private String almanacName; // Назва альманаху
    private String genre;       // Жанр альманаху
    private int pages;         // Загальна кількість сторінок
    private List<Book> works;  // Список творів, що входять до альманаху

    /**
     * Конструктор з використанням патерну Builder
     */
    @Builder
    public Almanac(String almanacName, String genre, int year,
                   String publisher, int pages, List<Book> works) {
        this.almanacName = almanacName;
        this.genre = genre;
        this.year = year;
        this.publisher = publisher;
        this.pages = pages;
        this.works = works;
        // Назва публікації співпадає з назвою альманаху
        this.title = almanacName;
    }

    /**
     * Реалізація методу отримання типу публікації
     * @return рядок "ALMANAC" - ідентифікатор типу альманаху
     */
    @Override
    public String getType() {
        return "ALMANAC";
    }

    /**
     * Реалізація методу виводу інформації про альманах
     * Виводить інформацію про альманах та список творів, що до нього входять
     */
    @Override
    public void displayInfo() {
        System.out.println("Тип: " + getType());
        System.out.println("Назва альманаху: " + almanacName);
        System.out.println("Жанр: " + genre);
        System.out.println("Рік: " + year);
        System.out.println("Видавництво: " + publisher);
        System.out.println("Сторінок: " + pages);
        System.out.println("Включені твори (" + works.size() + "):");
        // Виводимо інформацію про кожен твір у альманасі
        for (Book work : works) {
            System.out.println("  - " + work.getTitle() + " від " + work.getAuthor());
        }
        System.out.println("---------------------------");
    }
}