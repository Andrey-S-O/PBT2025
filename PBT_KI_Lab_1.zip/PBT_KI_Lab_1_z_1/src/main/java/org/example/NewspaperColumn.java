package org.example;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Клас, що представляє колонку в газеті.
 * Це простий клас даних (value object) для зберігання інформації про колонку.
 * Використовує Lombok анотації для автоматичного створення:
 * - геттерів, сеттерів, toString, equals, hashCode (@Data)
 * - конструктора з усіма параметрами (@AllArgsConstructor)
 */
@Data
@AllArgsConstructor
public class NewspaperColumn {
    private String columnName;   // Назва колонки
    private String journalist;   // Ім'я журналіста, що відповідає за колонку
}