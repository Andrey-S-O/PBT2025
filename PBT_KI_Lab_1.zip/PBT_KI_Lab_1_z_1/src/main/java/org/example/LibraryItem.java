package org.example;

import lombok.Getter;
import lombok.Setter;

/**
 * Абстрактний базовий клас для всіх бібліотечних елементів.
 * Реалізує інтерфейс Publication та надає базові поля.
 * Використовує Lombok для автоматичного створення геттерів та сеттерів.
 */
@Getter
@Setter
public abstract class LibraryItem implements Publication {
    // Загальні поля для всіх типів публікацій
    protected String title;        // Назва публікації
    protected String publisher;    // Видавництво
    protected int year;           // Рік видання

    /**
     * Абстрактний метод для отримання типу публікації
     * Має бути реалізований у кожному конкретному класі-нащадку
     */
    @Override
    public abstract String getType();

    /**
     * Абстрактний метод для виводу інформації
     * Кожен клас-нащадок має свою реалізацію виводу
     */
    @Override
    public abstract void displayInfo();
}