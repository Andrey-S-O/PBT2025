package org.example;

/**
 * Базовий інтерфейс для всіх типів публікацій у бібліотеці.
 * Відповідає принципу розділення інтерфейсів (Interface Segregation Principle)
 * з SOLID, містить лише необхідні методи для всіх типів публікацій.
 */
public interface Publication {
    /**
     * Отримати назву публікації
     * @return назва публікації
     */
    String getTitle();

    /**
     * Отримати видавництво
     * @return назва видавництва
     */
    String getPublisher();

    /**
     * Отримати рік видання
     * @return рік видання
     */
    int getYear();

    /**
     * Отримати тип публікації (BOOK, NEWSPAPER, ALMANAC)
     * @return тип публікації
     */
    String getType();

    /**
     * Вивести інформацію про публікацію на екран
     * Використовує System.out.println для виводу
     */
    void displayInfo();
}