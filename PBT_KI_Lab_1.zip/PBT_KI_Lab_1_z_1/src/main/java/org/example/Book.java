package org.example;

import lombok.*;
import java.util.Objects;

/**
 * Клас, що представляє книгу в бібліотечному каталозі.
 * Наслідується від LibraryItem та реалізує специфічні для книги властивості.
 * Використовує Lombok анотації для автоматичного створення:
 * - геттерів та сеттерів (@Getter, @Setter)
 * - конструктора без параметрів (@NoArgsConstructor)
 * - методу toString з включенням полів батьківського класу (@ToString(callSuper = true))
 * - патерну Builder для зручного створення об'єктів (@Builder)
 */
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class Book extends LibraryItem {
    // Специфічні поля для книг
    private String author;   // Автор книги
    private String genre;    // Жанр книги
    private int pages;      // Кількість сторінок

    /**
     * Конструктор з використанням патерну Builder від Lombok
     * Дозволяє створювати об'єкти ланцюжковим викликом методів
     */
    @Builder
    public Book(String title, String author, String genre, int year,
                String publisher, int pages) {
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.year = year;
        this.publisher = publisher;
        this.pages = pages;
    }

    /**
     * Реалізація методу отримання типу публікації
     * @return рядок "BOOK" - ідентифікатор типу книги
     */
    @Override
    public String getType() {
        return "BOOK";
    }

    /**
     * Реалізація методу виводу інформації про книгу
     * Використовує System.out.println для форматованого виводу
     */
    @Override
    public void displayInfo() {
        System.out.println("Тип: " + getType());
        System.out.println("Назва: " + title);
        System.out.println("Автор: " + author);
        System.out.println("Жанр: " + genre);
        System.out.println("Рік: " + year);
        System.out.println("Видавництво: " + publisher);
        System.out.println("Сторінок: " + pages);
        System.out.println("---------------------------");
    }
}