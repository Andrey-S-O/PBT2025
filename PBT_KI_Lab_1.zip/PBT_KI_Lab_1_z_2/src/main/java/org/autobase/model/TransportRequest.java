package org.autobase.model;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Клас, що представляє запит на перевезення.
 * Містить інформацію про пункт призначення та вантаж.
 */
@Data
@AllArgsConstructor
public class TransportRequest {
    // Унікальний ідентифікатор запиту
    private final String id;
    // Пункт призначення перевезення
    private final Destination destination;
    // Вантаж для перевезення
    private final Cargo cargo;

    /**
     * Метод для отримання інформації про запит на перевезення
     * @return Рядок з інформацією про запит
     */
    public String getInfo() {
        return String.format("Запит %s: %s -> %s", id, cargo.getInfo(), destination.getInfo());
    }

    /**
     * Розраховує загальний необхідний рівень навичок для цього запиту
     * @return Сума необхідного досвіду та складності маршруту
     */
    public int getTotalRequiredSkill() {
        return cargo.getRequiredExperience() + destination.getRouteComplexity();
    }
}