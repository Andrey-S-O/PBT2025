package org.autobase.model;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Клас, що представляє вантаж для перевезення.
 * Використовує Lombok для автоматичного створення геттерів, сеттерів та конструктора.
 */
@Data // Lombok анотація - генерує гетери, сетери, toString, equals, hashCode
@AllArgsConstructor // Lombok анотація - генерує конструктор з усіма полями
public class Cargo {
    // Тип вантажу (електроніка, продукти харчування тощо)
    private final String type;
    // Вага вантажу в тонах
    private final double weight;
    // Необхідний досвід водія для перевезення цього вантажу (шкала 1-10)
    private final int requiredExperience;

    /**
     * Метод для отримання інформації про вантаж у зручному форматі
     * @return Рядок з інформацією про вантаж
     */
    public String getInfo() {
        return String.format("%s (%.1f тон, досвід: %d)", type, weight, requiredExperience);
    }
}