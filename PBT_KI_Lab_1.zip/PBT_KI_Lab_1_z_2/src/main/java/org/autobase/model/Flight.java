package org.autobase.model;

import lombok.Data;
import java.time.LocalDateTime;
import java.util.UUID;
import java.time.format.DateTimeFormatter;

/**
 * Клас, що представляє рейс - виконання запиту на перевезення.
 * Містить інформацію про водія, автомобіль, стан рейсу та оплату.
 */
@Data
public class Flight {
    // Форматер для відображення часу
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm");

    // Унікальний ідентифікатор рейсу (генерується автоматично)
    private final String id = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    // Запит на перевезення, який виконується
    private TransportRequest request;
    // Водій, призначений на рейс
    private Driver driver;
    // Автомобіль, призначений на рейс
    private Car car;
    // Стан рейсу
    private FlightStatus status = FlightStatus.PENDING;
    // Час початку рейсу
    private LocalDateTime startTime;
    // Час завершення рейсу
    private LocalDateTime endTime;
    // Сума оплати за рейс
    private double payment;
    // Нотатки водія після рейсу
    private String driverNotes;
    // Стан автомобіля після рейсу
    private CarCondition carConditionAfterFlight;

    /**
     * Конструктор для створення рейсу з запитом, водієм та автомобілем
     * @param request Запит на перевезення
     * @param driver Водій для рейсу
     * @param car Автомобіль для рейсу
     */
    public Flight(TransportRequest request, Driver driver, Car car) {
        this.request = request;
        this.driver = driver;
        this.car = car;
    }

    /**
     * Перелік можливих станів рейсу
     */
    public enum FlightStatus {
        PENDING,      // Очікує призначення
        IN_PROGRESS,  // В процесі виконання
        COMPLETED,    // Успішно завершений
        BROKEN_DOWN   // Аварійна ситуація
    }

    /**
     * Перелік можливих станів автомобіля після рейсу
     */
    public enum CarCondition {
        EXCELLENT,    // Відмінний стан
        GOOD,         // Добрий стан
        FAIR,         // Задовільний стан
        NEEDS_REPAIR, // Потребує ремонту
        BROKEN_DOWN   // Аварійний стан
    }

    /**
     * Починає рейс - встановлює статус та час початку
     */
    public void startFlight() {
        this.status = FlightStatus.IN_PROGRESS;
        this.startTime = LocalDateTime.now();
        this.driver.setAvailable(false);
        this.car.setAvailable(false);

        System.out.println("\n === ПОЧАТОК РЕЙСУ ===");
        System.out.println(" ID рейсу: " + id);
        System.out.println(" Водій: " + driver.getName());
        System.out.println(" Автомобіль: " + car.getModel() + " (" + car.getLicensePlate() + ")");
        System.out.println(" Маршрут: " + request.getDestination().getInfo());
        System.out.println(" Вантаж: " + request.getCargo().getInfo());
        System.out.println(" Час початку: " + startTime.format(TIME_FORMATTER));
        System.out.println(" Оплата: $" + String.format("%.2f", payment));
        System.out.println("=========================\n");
    }

    /**
     * Завершує рейс - оновлює статус, час завершення та нотатки
     * @param notes Нотатки водія
     * @param condition Стан автомобіля після рейсу
     */
    public void completeFlight(String notes, CarCondition condition) {
        this.status = FlightStatus.COMPLETED;
        this.endTime = LocalDateTime.now();
        this.driverNotes = notes;
        this.carConditionAfterFlight = condition;

        System.out.println("\n === РЕЙС ЗАВЕРШЕНО ===");
        System.out.println(" ID рейсу: " + id);
        System.out.println(" Водій: " + driver.getName());
        System.out.println(" Нотатки водія: " + notes);
        System.out.println(" Стан автомобіля: " + getCarConditionDescription(condition));
        System.out.println(" Час завершення: " + endTime.format(TIME_FORMATTER));
        System.out.println(" Отримано оплати: $" + String.format("%.2f", payment));
        System.out.println("==========================\n");

        // Обробка стану автомобіля після рейсу
        if (condition == CarCondition.NEEDS_REPAIR || condition == CarCondition.BROKEN_DOWN) {
            car.markForRepair();
        } else {
            car.completeTrip();
        }

        // Оновлення інформації водія
        driver.completeFlight(this);
    }

    /**
     * Імітує поломку автомобіля під час рейсу
     */
    public void breakdown() {
        this.status = FlightStatus.BROKEN_DOWN;
        car.markForRepair();
        System.out.println("\n !!! ПОЛОМКА !!! Рейс " + id + " - Автомобіль " +
                car.getLicensePlate() + " потребує ремонту!\n");
    }

    /**
     * Повертає текстовий опис стану автомобіля
     * @param condition Стан автомобіля
     * @return Текстове представлення стану
     */
    private String getCarConditionDescription(CarCondition condition) {
        switch (condition) {
            case EXCELLENT: return "Відмінний стан";
            case GOOD: return "Добрий стан";
            case FAIR: return "Задовільний стан";
            case NEEDS_REPAIR: return "Потребує ремонту";
            case BROKEN_DOWN: return "Аварійний стан";
            default: return "Невідомий стан";
        }
    }
}