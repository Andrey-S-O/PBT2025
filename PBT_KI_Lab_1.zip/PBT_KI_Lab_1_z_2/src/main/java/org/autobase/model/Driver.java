package org.autobase.model;

import lombok.Data;
import java.util.ArrayList;
import java.util.List;

/**
 * Клас, що представляє водія автобази.
 * Зберігає інформацію про досвід, доступність та історію рейсів.
 */
@Data
public class Driver {
    // Унікальний ідентифікатор водія
    private final String id;
    // Ім'я водія
    private final String name;
    // Рівень досвіду водія (шкала 1-10)
    private final int experience;
    // Прапорець, що вказує чи доступний водій для нового рейсу
    private boolean available = true;
    // Список завершених рейсів водія
    private final List<Flight> completedFlights = new ArrayList<>();
    // Загальний заробіток водія
    private double totalEarnings = 0.0;

    /**
     * Перевіряє, чи може водій обробити складність маршруту
     * @param requiredComplexity Необхідна складність маршруту
     * @return true, якщо досвід водія достатній для маршруту
     */
    public boolean canHandleComplexity(int requiredComplexity) {
        return experience >= requiredComplexity;
    }

    /**
     * Додає завершений рейс до історії водія та оновлює заробіток
     * @param flight Завершений рейс
     */
    public void completeFlight(Flight flight) {
        completedFlights.add(flight);
        totalEarnings += flight.getPayment();
        this.available = true; // Робить водія доступним для нового рейсу
        System.out.println("Водій " + name + " завершив рейс. Загальний заробіток: $" + totalEarnings);
    }

    /**
     * Метод для отримання інформації про водія
     * @return Рядок з інформацією про водія
     */
    public String getInfo() {
        return String.format("%s (досвід: %d, доступний: %s, завершено: %d рейсів)",
                name, experience, available ? "так" : "ні", completedFlights.size());
    }
}