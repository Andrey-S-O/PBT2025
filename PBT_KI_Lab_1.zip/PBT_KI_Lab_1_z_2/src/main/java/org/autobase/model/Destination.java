package org.autobase.model;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Клас, що представляє пункт призначення перевезення.
 * Включає інформацію про відстань та складність маршруту.
 */
@Data
@AllArgsConstructor
public class Destination {
    // Назва пункту призначення
    private final String name;
    // Відстань до пункту призначення в кілометрах
    private final double distance;
    // Складність маршруту (шкала 1-10)
    private final int routeComplexity;

    /**
     * Метод для отримання інформації про пункт призначення
     * @return Рядок з інформацією про пункт призначення
     */
    public String getInfo() {
        return String.format("%s (%.0f км, складність: %d)", name, distance, routeComplexity);
    }
}