package org.autobase.model;

import lombok.Data;

/**
 * Клас, що представляє автомобіль автобази.
 * Зберігає інформацію про вантажопідйомність, стан та історію поїздок.
 */
@Data
public class Car {
    // Державний номер автомобіля
    private final String licensePlate;
    // Модель автомобіля
    private final String model;
    // Вантажопідйомність автомобіля в тонах
    private final double carryingCapacity;
    // Складність керування автомобілем (шкала 1-10)
    private final int complexity;
    // Прапорець доступності автомобіля
    private boolean available = true;
    // Прапорець необхідності ремонту
    private boolean needsRepair = false;
    // Лічильник завершених поїздок
    private int tripsCompleted = 0;

    /**
     * Перевіряє, чи може автомобіль перевозити вказану вагу
     * @param weight Вага вантажу
     * @return true, якщо автомобіль може перевозити вантаж та не потребує ремонту
     */
    public boolean canCarryWeight(double weight) {
        return weight <= carryingCapacity && !needsRepair;
    }

    /**
     * Розраховує коефіцієнт використання вантажопідйомності
     * @param cargoWeight Вага вантажу
     * @return Коефіцієнт використання (0-1)
     */
    public double getUtilizationRate(double cargoWeight) {
        return cargoWeight / carryingCapacity;
    }

    /**
     * Позначає автомобіль як той, що потребує ремонту
     */
    public void markForRepair() {
        needsRepair = true;
        available = false;
        System.out.println(" Автомобіль " + licensePlate + " потребує ремонту!");
    }

    /**
     * Завершує ремонт автомобіля та робить його доступним
     */
    public void completeRepair() {
        needsRepair = false;
        available = true;
        System.out.println(" Автомобіль " + licensePlate + " відремонтовано та готовий до роботи");
    }

    /**
     * Завершує поїздку та збільшує лічильник поїздок
     */
    public void completeTrip() {
        tripsCompleted++;
        available = true;
    }

    /**
     * Метод для отримання інформації про автомобіль
     * @return Рядок з інформацією про автомобіль
     */
    public String getInfo() {
        return String.format("%s %s (вантажопідйомність: %.1f тон, складність: %d, доступний: %s, потребує ремонту: %s)",
                model, licensePlate, carryingCapacity, complexity,
                available ? "так" : "ні", needsRepair ? "так" : "ні");
    }
}