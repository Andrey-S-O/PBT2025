package org.autobase.service;

import org.autobase.model.*;
import org.autobase.service.impl.*;
import java.util.*;

/**
 * Головний сервіс диспетчера, що керує всіма операціями автобази.
 * Відповідає за принцип інверсії залежностей (Dependency Inversion) -
 * залежить від абстракцій, а не конкретних реалізацій.
 */
public class DispatcherService {

    // Списки всіх ресурсів системи
    private final List<Driver> drivers = new ArrayList<>();
    private final List<Car> cars = new ArrayList<>();
    private final List<Flight> activeFlights = new ArrayList<>();
    private final List<Flight> completedFlights = new ArrayList<>();
    private final List<TransportRequest> pendingRequests = new ArrayList<>();

    // Залежності сервісу (впроваджені через інтерфейси)
    private final DriverSelector driverSelector = new ExperienceBasedDriverSelector();
    private final CarSelector carSelector = new OptimizedCarSelector();
    private final PaymentCalculator paymentCalculator = new DistanceBasedPaymentCalculator();
    private final RepairService repairService = new SimpleRepairService();

    // Генератор випадкових чисел для імітації реальних подій
    private final Random random = new Random();

    /**
     * Додає нового водія до системи
     * @param driver Водій для додавання
     */
    public void addDriver(Driver driver) {
        drivers.add(driver);
        System.out.println(" Додано водія: " + driver.getInfo());
    }

    /**
     * Додає новий автомобіль до системи
     * @param car Автомобіль для додавання
     */
    public void addCar(Car car) {
        cars.add(car);
        System.out.println(" Додано автомобіль: " + car.getInfo());
    }

    /**
     * Додає новий запит на перевезення
     * @param request Запит на перевезення
     */
    public void addTransportRequest(TransportRequest request) {
        pendingRequests.add(request);
        System.out.println(" Новий запит на перевезення: " + request.getInfo());
    }

    /**
     * Обробляє всі очікуючі запити на перевезення
     */
    public void processPendingRequests() {
        System.out.println("\n === ОБРОБКА ОЧІКУЮЧИХ ЗАПИТІВ ===");
        System.out.println("Очікуючих запитів: " + pendingRequests.size());

        List<TransportRequest> processed = new ArrayList<>();

        // Спроба призначити рейс для кожного очікуючого запиту
        for (TransportRequest request : pendingRequests) {
            System.out.println("\n--- Обробка запиту " + request.getId() + " ---");
            Optional<Flight> flight = assignFlight(request);
            if (flight.isPresent()) {
                processed.add(request);
                System.out.println(" Рейс успішно призначено для запиту " + request.getId());
            } else {
                System.out.println(" Не вдалося призначити рейс для запиту " + request.getId());
            }
        }

        // Видалення оброблених запитів
        pendingRequests.removeAll(processed);
        System.out.println("\n Залишилось очікуючих запитів: " + pendingRequests.size());
    }

    /**
     * Призначає рейс для запиту на перевезення
     * @param request Запит на перевезення
     * @return Optional з призначеним рейсом або пустий, якщо призначити не вдалося
     */
    public Optional<Flight> assignFlight(TransportRequest request) {
        List<Driver> availableDrivers = getAvailableDrivers();
        List<Car> availableCars = getAvailableCars();

        // Перевірка наявності водіїв
        if (availableDrivers.isEmpty()) {
            System.out.println(" Немає доступних водіїв для запиту " + request.getId());
            return Optional.empty();
        }

        // Перевірка наявності автомобілів
        if (availableCars.isEmpty()) {
            System.out.println(" Немає доступних автомобілів для запиту " + request.getId());
            return Optional.empty();
        }

        // Вибір водія та автомобіля
        Optional<Driver> selectedDriver = driverSelector.selectDriver(request, availableDrivers);
        Optional<Car> selectedCar = carSelector.selectCar(request, availableCars);

        // Створення рейсу, якщо знайдені водій та автомобіль
        if (selectedDriver.isPresent() && selectedCar.isPresent()) {
            Flight flight = createFlight(request, selectedDriver.get(), selectedCar.get());
            activeFlights.add(flight);
            return Optional.of(flight);
        }

        System.out.println(" Не вдалося знайти підходящого водія/автомобіль для запиту " + request.getId());
        return Optional.empty();
    }

    /**
     * Створює новий рейс
     * @param request Запит на перевезення
     * @param driver Обраний водій
     * @param car Обраний автомобіль
     * @return Створений рейс
     */
    private Flight createFlight(TransportRequest request, Driver driver, Car car) {
        // Створення рейсу з використанням конструктора
        Flight flight = new Flight(request, driver, car);

        // Розрахунок оплати перед початком рейсу
        flight.setPayment(paymentCalculator.calculatePayment(flight));

        // Початок рейсу
        flight.startFlight();
        return flight;
    }

    /**
     * Імітує випадкову поломку автомобіля під час рейсу
     */
    public void simulateRandomBreakdown() {
        if (!activeFlights.isEmpty() && random.nextDouble() < 0.3) { // 30% ймовірність поломки
            Flight randomFlight = activeFlights.get(random.nextInt(activeFlights.size()));
            if (randomFlight.getStatus() == Flight.FlightStatus.IN_PROGRESS) {
                randomFlight.breakdown();
            }
        }
    }

    /**
     * Завершує випадковий активний рейс
     */
    public void completeRandomFlight() {
        if (!activeFlights.isEmpty()) {
            List<Flight> inProgressFlights = activeFlights.stream()
                    .filter(flight -> flight.getStatus() == Flight.FlightStatus.IN_PROGRESS)
                    .toList();

            if (!inProgressFlights.isEmpty()) {
                Flight flight = inProgressFlights.get(random.nextInt(inProgressFlights.size()));

                // Можливі нотатки водія
                String[] notes = {
                        "Плавна поїздка, хороші погодні умови",
                        "Інтенсивний рух, але прибув вчасно",
                        "Дорожні роботи спричинили невеликі затримки",
                        "Відмінний стан доріг, добре вклались в час",
                        "Легкий дощ, але без проблем",
                        "Туман уповільнив рух на деяких ділянках"
                };

                // Можливі стани автомобіля після рейсу (з різною ймовірністю)
                Flight.CarCondition[] conditions = {
                        Flight.CarCondition.EXCELLENT,
                        Flight.CarCondition.GOOD,
                        Flight.CarCondition.GOOD,
                        Flight.CarCondition.FAIR,
                        Flight.CarCondition.FAIR,
                        Flight.CarCondition.NEEDS_REPAIR
                };

                // Випадковий вибір нотаток та стану
                String note = notes[random.nextInt(notes.length)];
                Flight.CarCondition condition = conditions[random.nextInt(conditions.length)];

                // Завершення рейсу
                flight.completeFlight(note, condition);
                activeFlights.remove(flight);
                completedFlights.add(flight);
            }
        }
    }

    /**
     * Ремонтує випадковий автомобіль, що потребує ремонту
     */
    public void repairRandomCar() {
        List<Car> brokenCars = cars.stream()
                .filter(Car::isNeedsRepair)
                .toList();

        if (!brokenCars.isEmpty()) {
            Car car = brokenCars.get(random.nextInt(brokenCars.size()));
            repairService.completeRepair(car);
        }
    }

    /**
     * Отримує список доступних водіїв
     * @return Список доступних водіїв
     */
    private List<Driver> getAvailableDrivers() {
        return drivers.stream()
                .filter(Driver::isAvailable)
                .toList();
    }

    /**
     * Отримує список доступних автомобілів
     * @return Список доступних автомобілів
     */
    private List<Car> getAvailableCars() {
        return cars.stream()
                .filter(car -> car.isAvailable() && !car.isNeedsRepair())
                .toList();
    }

    /**
     * Генерує щоденний звіт про стан автобази
     */
    public void generateDailyReport() {
        System.out.println("\n === ЩОДЕННИЙ ЗВІТ АВТОБАЗИ ===");
        System.out.println(" Всього водіїв: " + drivers.size());
        System.out.println(" Всього автомобілів: " + cars.size());
        System.out.println(" Активних рейсів: " + activeFlights.size());
        System.out.println(" Завершених рейсів: " + completedFlights.size());
        System.out.println(" Очікуючих запитів: " + pendingRequests.size());

        System.out.println("\n---  Статистика водіїв ---");
        drivers.forEach(driver ->
                System.out.println("   " + driver.getInfo() + " - Заробіток: $" +
                        String.format("%.2f", driver.getTotalEarnings()))
        );

        System.out.println("\n---  Статистика автомобілів ---");
        cars.forEach(car ->
                System.out.println("   " + car.getInfo() + " - Поїздок: " + car.getTripsCompleted())
        );

        long availableDrivers = drivers.stream().filter(Driver::isAvailable).count();
        long availableCars = cars.stream().filter(car -> car.isAvailable() && !car.isNeedsRepair()).count();
        long brokenCars = cars.stream().filter(Car::isNeedsRepair).count();

        System.out.println("\n---  Загальна статистика ---");
        System.out.println("   Доступних водіїв: " + availableDrivers + "/" + drivers.size());
        System.out.println("   Доступних автомобілів: " + availableCars + "/" + cars.size());
        System.out.println("   Автомобілів, що потребують ремонту: " + brokenCars);

        double totalEarnings = drivers.stream().mapToDouble(Driver::getTotalEarnings).sum();
        System.out.println("   Загальний заробіток: $" + String.format("%.2f", totalEarnings));
        System.out.println("============================\n");
    }

    // Методи для отримання даних (використовуються для тестування)
    public List<Driver> getDrivers() { return new ArrayList<>(drivers); }
    public List<Car> getCars() { return new ArrayList<>(cars); }
    public List<Flight> getActiveFlights() { return new ArrayList<>(activeFlights); }
    public List<Flight> getCompletedFlights() { return new ArrayList<>(completedFlights); }
    public List<TransportRequest> getPendingRequests() { return new ArrayList<>(pendingRequests); }
}