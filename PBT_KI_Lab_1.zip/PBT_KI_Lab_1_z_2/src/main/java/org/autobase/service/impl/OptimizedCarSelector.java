package org.autobase.service.impl;

import org.autobase.model.Car;
import org.autobase.model.TransportRequest;
import org.autobase.service.CarSelector;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/**
 * Реалізація вибору автомобіля на основі оптимізації використання вантажопідйомності.
 * Обирає автомобіль з найближчим коефіцієнтом використання до оптимального.
 */
public class OptimizedCarSelector implements CarSelector {

    // Оптимальний коефіцієнт використання вантажопідйомності (80%)
    private static final double OPTIMAL_UTILIZATION = 0.8;

    /**
     * Вибирає автомобіль, що найкраще підходить для перевезення вантажу
     */
    @Override
    public Optional<Car> selectCar(TransportRequest request, List<Car> availableCars) {
        double cargoWeight = request.getCargo().getWeight();

        System.out.println(" Вибір автомобіля для вантажу " + cargoWeight + " тон");

        Optional<Car> selectedCar = availableCars.stream()
                // Фільтрує автомобілі, що можуть перевозити вантаж
                .filter(car -> {
                    boolean canCarry = car.canCarryWeight(cargoWeight);
                    if (!canCarry) {
                        System.out.println("    Автомобіль " + car.getLicensePlate() +
                                " пропущений (вантажопідйомність: " + car.getCarryingCapacity() +
                                ", потребує ремонту: " + (car.isNeedsRepair() ? "так" : "ні") + ")");
                    }
                    return canCarry;
                })
                // Обирає автомобіль з найближчим коефіцієнтом використання до оптимального
                .min(Comparator.comparingDouble(car ->
                        Math.abs(car.getUtilizationRate(cargoWeight) - OPTIMAL_UTILIZATION)))
                .map(car -> {
                    double utilization = car.getUtilizationRate(cargoWeight);
                    System.out.println("    Обраний автомобіль: " + car.getLicensePlate() +
                            " (вантажопідйомність: " + car.getCarryingCapacity() +
                            ", використання: " + String.format("%.1f%%", utilization * 100) + ")");
                    return car;
                });

        if (selectedCar.isEmpty()) {
            System.out.println("    Не знайдено підходящого автомобіля для вантажу " + cargoWeight + " тон");
        }

        return selectedCar;
    }
}