package org.autobase.service.impl;

import org.autobase.model.Car;
import org.autobase.service.RepairService;
import java.util.HashSet;
import java.util.Set;

/**
 * Проста реалізація сервісу ремонту автомобілів.
 * Відстежує автомобілі, що знаходяться в ремонті.
 */
public class SimpleRepairService implements RepairService {

    // Множина номерів автомобілів, що знаходяться в ремонті
    private final Set<String> carsUnderRepair = new HashSet<>();

    /**
     * Запитує ремонт для автомобіля
     */
    @Override
    public void requestRepair(Car car) {
        car.setNeedsRepair(true);
        carsUnderRepair.add(car.getLicensePlate());
        System.out.println(" Запит на ремонт автомобіля: " + car.getLicensePlate());
    }

    /**
     * Завершує ремонт автомобіля
     */
    @Override
    public void completeRepair(Car car) {
        car.setNeedsRepair(false);
        carsUnderRepair.remove(car.getLicensePlate());
        car.setAvailable(true);
        System.out.println(" Ремонт завершено для автомобіля: " + car.getLicensePlate());
    }

    /**
     * Перевіряє, чи знаходиться автомобіль в ремонті
     */
    @Override
    public boolean isUnderRepair(Car car) {
        return carsUnderRepair.contains(car.getLicensePlate());
    }
}