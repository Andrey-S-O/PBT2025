package org.autobase.service.impl;

import org.autobase.model.Flight;
import org.autobase.service.PaymentCalculator;

/**
 * Реалізація розрахунку оплати на основі відстані, складності та досвіду.
 * Оплата включає базову ставку та бонуси за досвід, складність та вагу вантажу.
 */
public class DistanceBasedPaymentCalculator implements PaymentCalculator {

    // Базова ставка за кілометр
    private static final double BASE_RATE_PER_KM = 2.5;
    // Коефіцієнт бонусу за досвід
    private static final double EXPERIENCE_BONUS_RATE = 0.1;
    // Коефіцієнт бонусу за складність маршруту
    private static final double COMPLEXITY_BONUS_RATE = 0.15;
    // Коефіцієнт бонусу за вагу вантажу
    private static final double CARGO_BONUS_RATE = 0.05;

    /**
     * Розраховує оплату за рейс з урахуванням різних факторів
     */
    @Override
    public double calculatePayment(Flight flight) {
        // Базова оплата за відстань
        double basePayment = flight.getRequest().getDestination().getDistance() * BASE_RATE_PER_KM;
        // Бонус за досвід водія
        double experienceBonus = basePayment * (flight.getDriver().getExperience() * EXPERIENCE_BONUS_RATE);
        // Бонус за складність маршруту
        double complexityBonus = basePayment * (flight.getRequest().getDestination().getRouteComplexity() * COMPLEXITY_BONUS_RATE);
        // Бонус за вагу вантажу
        double cargoBonus = basePayment * (flight.getRequest().getCargo().getWeight() * CARGO_BONUS_RATE);

        // Загальна оплата
        double totalPayment = basePayment + experienceBonus + complexityBonus + cargoBonus;

        System.out.println(" Розрахунок оплати за рейс:");
        System.out.println("    Базова оплата (" + flight.getRequest().getDestination().getDistance() +
                " км × $" + BASE_RATE_PER_KM + "): $" + String.format("%.2f", basePayment));
        System.out.println("    Бонус за досвід (" + flight.getDriver().getExperience() + "): $" +
                String.format("%.2f", experienceBonus));
        System.out.println("   ️ Бонус за складність (" + flight.getRequest().getDestination().getRouteComplexity() +
                "): $" + String.format("%.2f", complexityBonus));
        System.out.println("    Бонус за вантаж (" + flight.getRequest().getCargo().getWeight() +
                " тон): $" + String.format("%.2f", cargoBonus));
        System.out.println("    Загальна оплата: $" + String.format("%.2f", totalPayment));

        return totalPayment;
    }
}