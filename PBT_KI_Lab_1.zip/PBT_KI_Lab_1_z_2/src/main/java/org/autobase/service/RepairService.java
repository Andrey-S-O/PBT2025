package org.autobase.service;

import org.autobase.model.Car;

/**
 * Інтерфейс для сервісу ремонту автомобілів.
 * Відповідає за принцип єдиного обов'язку (Single Responsibility) -
 * відповідає лише за управління ремонтом автомобілів.
 */
public interface RepairService {
    /**
     * Запитує ремонт для автомобіля
     * @param car Автомобіль, що потребує ремонту
     */
    void requestRepair(Car car);

    /**
     * Завершує ремонт автомобіля
     * @param car Відремонтований автомобіль
     */
    void completeRepair(Car car);

    /**
     * Перевіряє, чи знаходиться автомобіль в ремонті
     * @param car Автомобіль для перевірки
     * @return true, якщо автомобіль в ремонті
     */
    boolean isUnderRepair(Car car);
}