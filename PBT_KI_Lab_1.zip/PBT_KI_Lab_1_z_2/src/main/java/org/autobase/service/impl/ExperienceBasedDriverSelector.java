package org.autobase.service.impl;

import org.autobase.model.Driver;
import org.autobase.model.TransportRequest;
import org.autobase.service.DriverSelector;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/**
 * Реалізація вибору водія на основі досвіду.
 * Водій з найбільшим досвідом обирається для найскладніших завдань.
 */
public class ExperienceBasedDriverSelector implements DriverSelector {

    /**
     * Вибирає водія на основі необхідного досвіду для маршруту та вантажу
     */
    @Override
    public Optional<Driver> selectDriver(TransportRequest request, List<Driver> availableDrivers) {
        int totalRequiredSkill = request.getTotalRequiredSkill();

        System.out.println(" Вибір водія для запиту " + request.getId() +
                " (необхідний рівень: " + totalRequiredSkill + ")");

        Optional<Driver> selectedDriver = availableDrivers.stream()
                // Фільтрує водіїв, що мають достатній досвід
                .filter(driver -> {
                    boolean canHandle = driver.canHandleComplexity(totalRequiredSkill);
                    if (!canHandle) {
                        System.out.println("    Водій " + driver.getName() + " пропущений (досвід: " +
                                driver.getExperience() + " < необхідний: " + totalRequiredSkill + ")");
                    }
                    return canHandle;
                })
                // Обирає водія з найбільшим досвідом
                .max(Comparator.comparingInt(Driver::getExperience))
                .map(driver -> {
                    System.out.println("    Обраний водій: " + driver.getName() +
                            " (досвід: " + driver.getExperience() + ")");
                    return driver;
                });

        if (selectedDriver.isEmpty()) {
            System.out.println("   Не знайдено підходящого водія для запиту " + request.getId());
        }

        return selectedDriver;
    }
}