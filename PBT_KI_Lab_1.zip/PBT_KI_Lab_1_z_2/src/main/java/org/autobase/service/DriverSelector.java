package org.autobase.service;

import org.autobase.model.Driver;
import org.autobase.model.TransportRequest;
import java.util.List;
import java.util.Optional;

/**
 * Інтерфейс для стратегії вибору водія.
 * Відповідає за принцип відкритості/закритості (Open/Closed) -
 * можна додавати нові стратегії вибору без зміни існуючого коду.
 */
public interface DriverSelector {
    /**
     * Вибирає найбільш підходящого водія для запиту на перевезення
     * @param request Запит на перевезення
     * @param availableDrivers Список доступних водіїв
     * @return Optional з обраним водієм або пустий, якщо підходящого не знайдено
     */
    Optional<Driver> selectDriver(TransportRequest request, List<Driver> availableDrivers);
}