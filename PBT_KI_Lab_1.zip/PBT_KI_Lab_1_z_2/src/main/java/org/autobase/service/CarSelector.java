package org.autobase.service;

import org.autobase.model.Car;
import org.autobase.model.TransportRequest;
import java.util.List;
import java.util.Optional;

/**
 * Інтерфейс для стратегії вибору автомобіля.
 * Відповідає за принцип розділення інтерфейсів (Interface Segregation) -
 * інтерфейс має лише один метод, що робить його вузькоспеціалізованим.
 */
public interface CarSelector {
    /**
     * Вибирає найбільш підходящий автомобіль для запиту на перевезення
     * @param request Запит на перевезення
     * @param availableCars Список доступних автомобілів
     * @return Optional з обраним автомобілем або пустий, якщо підходящого не знайдено
     */
    Optional<Car> selectCar(TransportRequest request, List<Car> availableCars);
}