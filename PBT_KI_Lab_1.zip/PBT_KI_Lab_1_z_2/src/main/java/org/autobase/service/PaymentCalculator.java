package org.autobase.service;

import org.autobase.model.Flight;

/**
 * Інтерфейс для стратегії розрахунку оплати.
 * Відповідає за принцип підстановки Лісков (Liskov Substitution) -
 * будь-яка реалізація може бути використана замість інтерфейсу.
 */
public interface PaymentCalculator {
    /**
     * Розраховує оплату за рейс
     * @param flight Рейс для розрахунку оплати
     * @return Сума оплати
     */
    double calculatePayment(Flight flight);
}