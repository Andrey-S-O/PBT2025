package org.autobase;

import org.autobase.model.*;
import org.autobase.service.DispatcherService;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * Головний клас програми "Автобаза".
 * Запускає систему та імітує роботу автобази протягом кількох днів.
 */
public class AutobaseApplication {

    // Генератор випадкових чисел для імітації
    private static final Random random = new Random();

    /**
     * Точка входу в програму
     * @param args Аргументи командного рядка (не використовуються)
     */
    public static void main(String[] args) {
        System.out.println(" === СИСТЕМА УПРАВЛІННЯ АВТОБАЗОЮ ЗАПУСКАЄТЬСЯ ===\n");

        // Створення сервісу диспетчера
        DispatcherService dispatcher = new DispatcherService();

        // Ініціалізація системи водіями та автомобілями
        initializeSystem(dispatcher);

        // Імітація роботи протягом 5 днів
        for (int day = 1; day <= 5; day++) {
            simulateDay(dispatcher, day);
        }

        // Фінальний звіт
        generateFinalReport(dispatcher);

        System.out.println(" === РОБОТУ СИСТЕМИ АВТОБАЗИ ЗАВЕРШЕНО ===\n");
    }

    /**
     * Ініціалізує систему початковими даними
     * @param dispatcher Сервіс диспетчера для ініціалізації
     */
    private static void initializeSystem(DispatcherService dispatcher) {
        System.out.println(" === ІНІЦІАЛІЗАЦІЯ СИСТЕМИ АВТОБАЗИ ===\n");

        // Створення списку водіїв
        List<Driver> drivers = Arrays.asList(
                new Driver("D001", "Іван Петренко", 8),
                new Driver("D002", "Марія Коваленко", 6),
                new Driver("D003", "Богдан Шевченко", 9),
                new Driver("D004", "Олена Бойко", 4),
                new Driver("D005", "Тарас Лисенко", 7)
        );

        // Створення списку автомобілів
        List<Car> cars = Arrays.asList(
                new Car("АА1234АА", "Volvo FH16", 20.0, 6),
                new Car("ВВ5678ВВ", "Scania R500", 18.0, 5),
                new Car("СС9012СС", "MAN TGX", 15.0, 4),
                new Car("ЕЕ3456ЕЕ", "DAF XF", 12.0, 3),
                new Car("НН7890НН", "Renault T", 16.0, 4)
        );

        // Додавання водіїв та автомобілів до системи
        drivers.forEach(dispatcher::addDriver);
        cars.forEach(dispatcher::addCar);

        System.out.println("\n === ІНІЦІАЛІЗАЦІЯ СИСТЕМИ ЗАВЕРШЕНА ===\n");
    }

    /**
     * Імітує один день роботи автобази
     * @param dispatcher Сервіс диспетчера
     * @param day Номер дня
     */
    private static void simulateDay(DispatcherService dispatcher, int day) {
        System.out.println(" === ПОЧАТОК ДНЯ " + day + " ===\n");

        // Генерація випадкових запитів на перевезення для дня
        int requestsCount = random.nextInt(3) + 3; // 3-5 запитів на день
        System.out.println(" Генерація " + requestsCount + " запитів на перевезення...");

        for (int i = 0; i < requestsCount; i++) {
            TransportRequest request = generateRandomRequest("ЗАПИТ_Д" + day + "_" + (i + 1));
            dispatcher.addTransportRequest(request);
        }

        // Обробка очікуючих запитів
        dispatcher.processPendingRequests();

        // Імітація завершення деяких рейсів
        int flightsToComplete = Math.min(dispatcher.getActiveFlights().size(), random.nextInt(3) + 1);
        System.out.println("\n Завершення " + flightsToComplete + " рейсів...");
        for (int i = 0; i < flightsToComplete; i++) {
            dispatcher.completeRandomFlight();
        }

        // Імітація випадкових поломок
        System.out.println("\n Перевірка можливих поломок...");
        dispatcher.simulateRandomBreakdown();

        // Ремонт деяких автомобілів (50% ймовірність)
        if (random.nextDouble() < 0.5) {
            System.out.println("\n️ Ремонт автомобілів...");
            dispatcher.repairRandomCar();
        }

        // Генерація щоденного звіту
        dispatcher.generateDailyReport();

        System.out.println(" === ДЕНЬ " + day + " ЗАВЕРШЕНО ===\n");
    }

    /**
     * Генерує випадковий запит на перевезення
     * @param id Ідентифікатор запиту
     * @return Згенерований запит на перевезення
     */
    private static TransportRequest generateRandomRequest(String id) {
        // Список можливих пунктів призначення
        List<Destination> destinations = Arrays.asList(
                new Destination("Київ", 300, 3),
                new Destination("Львів", 500, 5),
                new Destination("Одеса", 1200, 7),
                new Destination("Харків", 2000, 9),
                new Destination("Дніпро", 400, 4),
                new Destination("Запоріжжя", 600, 5)
        );

        // Список можливих типів вантажу
        List<Cargo> cargoTypes = Arrays.asList(
                new Cargo("Електроніка", 8.5, 7),
                new Cargo("Продукти харчування", 12.0, 3),
                new Cargo("Будівельні матеріали", 18.0, 6),
                new Cargo("Хімічні речовини", 5.0, 9),
                new Cargo("Меблі", 10.0, 4),
                new Cargo("Автозапчастини", 15.0, 5)
        );

        // Випадковий вибір пункту призначення та вантажу
        Destination dest = destinations.get(random.nextInt(destinations.size()));
        Cargo cargo = cargoTypes.get(random.nextInt(cargoTypes.size()));

        return new TransportRequest(id, dest, cargo);
    }

    /**
     * Генерує фінальний звіт про роботу системи
     * @param dispatcher Сервіс диспетчера
     */
    private static void generateFinalReport(DispatcherService dispatcher) {
        System.out.println(" === ФІНАЛЬНИЙ ЗВІТ ПРО РОБОТУ АВТОБАЗИ ===\n");

        double totalEarnings = dispatcher.getDrivers().stream()
                .mapToDouble(Driver::getTotalEarnings)
                .sum();

        int totalTrips = dispatcher.getCars().stream()
                .mapToInt(Car::getTripsCompleted)
                .sum();

        int completedFlights = dispatcher.getCompletedFlights().size();

        System.out.println("  Загальна статистика за весь період:");
        System.out.println("   Загальний заробіток: $" + String.format("%.2f", totalEarnings));
        System.out.println("   Завершено рейсів: " + completedFlights);
        System.out.println("   Виконано поїздок: " + totalTrips);

        System.out.println("\n--- Найкращі водії ---");
        dispatcher.getDrivers().stream()
                .sorted((d1, d2) -> Double.compare(d2.getTotalEarnings(), d1.getTotalEarnings()))
                .limit(3)
                .forEach(driver ->
                        System.out.println("    " + driver.getName() + " - $" +
                                String.format("%.2f", driver.getTotalEarnings()) +
                                " (" + driver.getCompletedFlights().size() + " рейсів)")
                );

        System.out.println("\n--- Найактивніші автомобілі ---");
        dispatcher.getCars().stream()
                .sorted((c1, c2) -> Integer.compare(c2.getTripsCompleted(), c1.getTripsCompleted()))
                .limit(3)
                .forEach(car ->
                        System.out.println("    " + car.getLicensePlate() + " - " +
                                car.getTripsCompleted() + " поїздок")
                );

        System.out.println("\n========================================\n");
    }
}