package org.example.database;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.example.entity.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

/**
 * Клас для керування підключенням до бази даних та основними операціями.
 */
public class DatabaseManager {

    private SessionFactory sessionFactory;
    private Scanner scanner;
    private DateTimeFormatter dateFormatter;

    /**
     * Конструктор, ініціалізує сканер та форматер дат.
     */
    public DatabaseManager() {
        this.scanner = new Scanner(System.in);
        this.dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    }

    /**
     * Метод для підключення до бази даних.
     * Створює SessionFactory з конфігураційного файлу.
     */
    public void connect() {
        try {
            // Створення SessionFactory з hibernate.cfg.xml
            Configuration configuration = new Configuration().configure();
            sessionFactory = configuration.buildSessionFactory();
            System.out.println("Підключення до бази даних успішне!");
        } catch (Exception e) {
            System.err.println("Помилка підключення до бази даних: " + e.getMessage());
            throw new RuntimeException("Не вдалося підключитися до бази даних", e);
        }
    }

    /**
     * Метод для відключення від бази даних.
     * Закриває SessionFactory.
     */
    public void disconnect() {
        if (sessionFactory != null && !sessionFactory.isClosed()) {
            sessionFactory.close();
            System.out.println("Відключення від бази даних успішне!");
        }
        if (scanner != null) {
            scanner.close();
        }
    }

    /**
     * Утилітний метод для отримання сесії з SessionFactory.
     * @return активну Hibernate сесію
     */
    private Session getSession() {
        if (sessionFactory == null || sessionFactory.isClosed()) {
            throw new IllegalStateException("Сесія не активна. Спочатку підключіться до бази даних.");
        }
        return sessionFactory.openSession();
    }

    /**
     * Метод для додавання нового запису (CRUD - Create).
     * Демонструє додавання різних сутностей.
     */
    public void addRecord() {
        System.out.println("\n=== ДОДАВАННЯ НОВОГО ЗАПИСУ ===");
        System.out.println("1. Додати продавця");
        System.out.println("2. Додати покупця");
        System.out.println("3. Додати товар");
        System.out.println("4. Додати продаж");
        System.out.print("Виберіть опцію: ");

        int choice = scanner.nextInt();
        scanner.nextLine(); // Очистка буфера

        try (Session session = getSession()) {
            Transaction transaction = session.beginTransaction();

            try {
                switch (choice) {
                    case 1 -> addSeller(session);
                    case 2 -> addBuyer(session);
                    case 3 -> addProduct(session);
                    case 4 -> addSale(session);
                    default -> System.out.println("Невірний вибір!");
                }

                transaction.commit();
                System.out.println("Запис успішно додано!");
            } catch (Exception e) {
                transaction.rollback();
                System.err.println("Помилка при додаванні запису: " + e.getMessage());
            }
        }
    }

    /**
     * Додає нового продавця до бази даних.
     */
    private void addSeller(Session session) {
        System.out.print("Введіть ім'я продавця: ");
        String name = scanner.nextLine();

        System.out.print("Введіть телефон продавця: ");
        String phone = scanner.nextLine();

        System.out.print("Введіть email продавця: ");
        String email = scanner.nextLine();

        Seller seller = new Seller(name, phone, email);
        session.save(seller);
    }

    /**
     * Додає нового покупця до бази даних.
     */
    private void addBuyer(Session session) {
        System.out.print("Введіть ім'я покупця: ");
        String name = scanner.nextLine();

        System.out.print("Введіть телефон покупця: ");
        String phone = scanner.nextLine();

        System.out.print("Введіть email покупця: ");
        String email = scanner.nextLine();

        Buyer buyer = new Buyer(name, phone, email);
        session.save(buyer);
    }

    /**
     * Додає новий товар до бази даних.
     */
    private void addProduct(Session session) {
        System.out.print("Введіть назву товару: ");
        String name = scanner.nextLine();

        Product product = new Product(name);
        session.save(product);
    }

    /**
     * Додає новий продаж до бази даних.
     */
    private void addSale(Session session) {
        // Відображення існуючих продавців
        System.out.println("\nІснуючі продавці:");
        displayAllSellers();

        System.out.print("Введіть ID продавця: ");
        Long sellerId = scanner.nextLong();
        Seller seller = session.get(Seller.class, sellerId);

        // Відображення існуючих покупців
        System.out.println("\nІснуючі покупці:");
        displayAllBuyers();

        System.out.print("Введіть ID покупця: ");
        Long buyerId = scanner.nextLong();
        Buyer buyer = session.get(Buyer.class, buyerId);

        // Відображення існуючих товарів
        System.out.println("\nІснуючі товари:");
        displayAllProducts();

        System.out.print("Введіть ID товару: ");
        Long productId = scanner.nextLong();
        Product product = session.get(Product.class, productId);

        System.out.print("Введіть ціну продажу: ");
        Double price = scanner.nextDouble();
        scanner.nextLine(); // Очистка буфера

        System.out.print("Введіть дату продажу (yyyy-MM-dd HH:mm): ");
        String dateStr = scanner.nextLine();
        LocalDateTime saleDate = LocalDateTime.parse(dateStr, dateFormatter);

        Sale sale = new Sale(seller, buyer, product, price, saleDate);
        session.save(sale);
    }

    /**
     * Метод для видалення запису (CRUD - Delete).
     */
    public void deleteRecord() {
        System.out.println("\n=== ВИДАЛЕННЯ ЗАПИСУ ===");
        System.out.println("1. Видалити продавця");
        System.out.println("2. Видалити покупця");
        System.out.println("3. Видалити товар");
        System.out.println("4. Видалити продаж");
        System.out.print("Виберіть опцію: ");

        int choice = scanner.nextInt();
        scanner.nextLine(); // Очистка буфера

        try (Session session = getSession()) {
            Transaction transaction = session.beginTransaction();

            try {
                switch (choice) {
                    case 1 -> deleteSeller(session);
                    case 2 -> deleteBuyer(session);
                    case 3 -> deleteProduct(session);
                    case 4 -> deleteSale(session);
                    default -> System.out.println("Невірний вибір!");
                }

                transaction.commit();
                System.out.println("Запис успішно видалено!");
            } catch (Exception e) {
                transaction.rollback();
                System.err.println("Помилка при видаленні запису: " + e.getMessage());
            }
        }
    }

    /**
     * Видаляє продавця за ID.
     */
    private void deleteSeller(Session session) {
        System.out.print("Введіть ID продавця для видалення: ");
        Long id = scanner.nextLong();

        Seller seller = session.get(Seller.class, id);
        if (seller != null) {
            session.delete(seller);
        } else {
            System.out.println("Продавець з таким ID не знайдений!");
        }
    }

    /**
     * Видаляє покупця за ID.
     */
    private void deleteBuyer(Session session) {
        System.out.print("Введіть ID покупця для видалення: ");
        Long id = scanner.nextLong();

        Buyer buyer = session.get(Buyer.class, id);
        if (buyer != null) {
            session.delete(buyer);
        } else {
            System.out.println("Покупець з таким ID не знайдений!");
        }
    }

    /**
     * Видаляє товар за ID.
     */
    private void deleteProduct(Session session) {
        System.out.print("Введіть ID товару для видалення: ");
        Long id = scanner.nextLong();

        Product product = session.get(Product.class, id);
        if (product != null) {
            session.delete(product);
        } else {
            System.out.println("Товар з таким ID не знайдений!");
        }
    }

    /**
     * Видаляє продаж за ID.
     */
    private void deleteSale(Session session) {
        System.out.print("Введіть ID продажу для видалення: ");
        Long id = scanner.nextLong();

        Sale sale = session.get(Sale.class, id);
        if (sale != null) {
            session.delete(sale);
        } else {
            System.out.println("Продаж з таким ID не знайдений!");
        }
    }

    /**
     * Метод для оновлення запису (CRUD - Update).
     */
    public void updateRecord() {
        System.out.println("\n=== ОНОВЛЕННЯ ЗАПИСУ ===");
        System.out.println("1. Оновити продавця");
        System.out.println("2. Оновити покупця");
        System.out.println("3. Оновити товар");
        System.out.println("4. Оновити продаж");
        System.out.print("Виберіть опцію: ");

        int choice = scanner.nextInt();
        scanner.nextLine(); // Очистка буфера

        try (Session session = getSession()) {
            Transaction transaction = session.beginTransaction();

            try {
                switch (choice) {
                    case 1 -> updateSeller(session);
                    case 2 -> updateBuyer(session);
                    case 3 -> updateProduct(session);
                    case 4 -> updateSale(session);
                    default -> System.out.println("Невірний вибір!");
                }

                transaction.commit();
                System.out.println("Запис успішно оновлено!");
            } catch (Exception e) {
                transaction.rollback();
                System.err.println("Помилка при оновленні запису: " + e.getMessage());
            }
        }
    }

    /**
     * Оновлює інформацію про продавця.
     */
    private void updateSeller(Session session) {
        System.out.print("Введіть ID продавця для оновлення: ");
        Long id = scanner.nextLong();
        scanner.nextLine(); // Очистка буфера

        Seller seller = session.get(Seller.class, id);
        if (seller != null) {
            System.out.print("Введіть нове ім'я продавця (поточне: " + seller.getName() + "): ");
            String name = scanner.nextLine();
            if (!name.isEmpty()) seller.setName(name);

            System.out.print("Введіть новий телефон (поточний: " + seller.getPhone() + "): ");
            String phone = scanner.nextLine();
            if (!phone.isEmpty()) seller.setPhone(phone);

            System.out.print("Введіть новий email (поточний: " + seller.getEmail() + "): ");
            String email = scanner.nextLine();
            if (!email.isEmpty()) seller.setEmail(email);

            session.update(seller);
        } else {
            System.out.println("Продавець з таким ID не знайдений!");
        }
    }

    // Аналогічні методи updateBuyer, updateProduct, updateSale
    // (реалізація схожа на updateSeller)

    /**
     * Відображає всіх продавців.
     */
    public void displayAllSellers() {
        try (Session session = getSession()) {
            Query<Seller> query = session.createQuery("FROM Seller ORDER BY id", Seller.class);
            List<Seller> sellers = query.getResultList();

            if (sellers.isEmpty()) {
                System.out.println("Список продавців порожній!");
            } else {
                System.out.println("\n=== СПИСОК ВСІХ ПРОДАВЦІВ ===");
                sellers.forEach(System.out::println);
                System.out.println("Усього продавців: " + sellers.size());
            }
        }
    }

    /**
     * Відображає всіх покупців.
     */
    public void displayAllBuyers() {
        try (Session session = getSession()) {
            Query<Buyer> query = session.createQuery("FROM Buyer ORDER BY id", Buyer.class);
            List<Buyer> buyers = query.getResultList();

            if (buyers.isEmpty()) {
                System.out.println("Список покупців порожній!");
            } else {
                System.out.println("\n=== СПИСОК ВСІХ ПОКУПЦІВ ===");
                buyers.forEach(System.out::println);
                System.out.println("Усього покупців: " + buyers.size());
            }
        }
    }

    /**
     * Відображає всі товари.
     */
    public void displayAllProducts() {
        try (Session session = getSession()) {
            Query<Product> query = session.createQuery("FROM Product ORDER BY id", Product.class);
            List<Product> products = query.getResultList();

            if (products.isEmpty()) {
                System.out.println("Список товарів порожній!");
            } else {
                System.out.println("\n=== СПИСОК ВСІХ ТОВАРІВ ===");
                products.forEach(System.out::println);
                System.out.println("Усього товарів: " + products.size());
            }
        }
    }

    /**
     * Відображає інформацію про всі транзакції.
     */
    public void displayAllSales() {
        try (Session session = getSession()) {
            Query<Sale> query = session.createQuery(
                    "FROM Sale s JOIN FETCH s.seller JOIN FETCH s.buyer JOIN FETCH s.product ORDER BY s.saleDate DESC",
                    Sale.class
            );
            List<Sale> sales = query.getResultList();

            if (sales.isEmpty()) {
                System.out.println("Список продажів порожній!");
            } else {
                System.out.println("\n=== ІНФОРМАЦІЯ ПРО ВСІ ТРАНЗАКЦІЇ ===");
                sales.forEach(sale -> {
                    System.out.printf("ID: %d | Дата: %s | Продавець: %s | Покупець: %s | Товар: %s | Ціна: %.2f%n",
                            sale.getId(),
                            sale.getSaleDate().format(dateFormatter),
                            sale.getSeller().getName(),
                            sale.getBuyer().getName(),
                            sale.getProduct().getName(),
                            sale.getPrice()
                    );
                });
                System.out.println("Усього транзакцій: " + sales.size());

                // Підсумкова статистика
                double totalAmount = sales.stream().mapToDouble(Sale::getPrice).sum();
                System.out.printf("Загальна сума продажів: %.2f%n", totalAmount);
            }
        }
    }

    /**
     * Відображає інформацію про транзакції за конкретну дату.
     */
    public void displaySalesByDate() {
        System.out.print("Введіть дату (yyyy-MM-dd): ");
        String dateStr = scanner.nextLine();
        LocalDate date = LocalDate.parse(dateStr);

        try (Session session = getSession()) {
            Query<Sale> query = session.createQuery(
                    "FROM Sale s WHERE DATE(s.saleDate) = :date ORDER BY s.saleDate",
                    Sale.class
            );
            query.setParameter("date", date);
            List<Sale> sales = query.getResultList();

            if (sales.isEmpty()) {
                System.out.println("Немає продажів за цю дату!");
            } else {
                System.out.println("\n=== ПРОДАЖІ ЗА " + date + " ===");
                sales.forEach(sale -> {
                    System.out.printf("Час: %s | Продавець: %s | Покупець: %s | Товар: %s | Ціна: %.2f%n",
                            sale.getSaleDate().format(DateTimeFormatter.ofPattern("HH:mm")),
                            sale.getSeller().getName(),
                            sale.getBuyer().getName(),
                            sale.getProduct().getName(),
                            sale.getPrice()
                    );
                });

                double dailyTotal = sales.stream().mapToDouble(Sale::getPrice).sum();
                System.out.printf("Загальна сума за день: %.2f (кількість: %d)%n", dailyTotal, sales.size());
            }
        }
    }

    /**
     * Відображає інформацію про транзакції за діапазон дат.
     */
    public void displaySalesByDateRange() {
        System.out.print("Введіть початкову дату (yyyy-MM-dd): ");
        String startDateStr = scanner.nextLine();
        LocalDate startDate = LocalDate.parse(startDateStr);

        System.out.print("Введіть кінцеву дату (yyyy-MM-dd): ");
        String endDateStr = scanner.nextLine();
        LocalDate endDate = LocalDate.parse(endDateStr);

        try (Session session = getSession()) {
            Query<Sale> query = session.createQuery(
                    "FROM Sale s WHERE DATE(s.saleDate) BETWEEN :startDate AND :endDate ORDER BY s.saleDate",
                    Sale.class
            );
            query.setParameter("startDate", startDate);
            query.setParameter("endDate", endDate);
            List<Sale> sales = query.getResultList();

            if (sales.isEmpty()) {
                System.out.println("Немає продажів за вказаний період!");
            } else {
                System.out.println("\n=== ПРОДАЖІ ЗА ПЕРІОД " + startDate + " - " + endDate + " ===");
                sales.forEach(sale -> {
                    System.out.printf("Дата: %s | Продавець: %s | Покупець: %s | Товар: %s | Ціна: %.2f%n",
                            sale.getSaleDate().format(dateFormatter),
                            sale.getSeller().getName(),
                            sale.getBuyer().getName(),
                            sale.getProduct().getName(),
                            sale.getPrice()
                    );
                });

                double periodTotal = sales.stream().mapToDouble(Sale::getPrice).sum();
                System.out.printf("Загальна сума за період: %.2f (кількість: %d)%n", periodTotal, sales.size());
            }
        }
    }

    /**
     * Відображає інформацію про транзакції конкретного продавця.
     */
    public void displaySalesBySeller() {
        displayAllSellers();
        System.out.print("Введіть ID продавця: ");
        Long sellerId = scanner.nextLong();

        try (Session session = getSession()) {
            Query<Sale> query = session.createQuery(
                    "FROM Sale s WHERE s.seller.id = :sellerId ORDER BY s.saleDate DESC",
                    Sale.class
            );
            query.setParameter("sellerId", sellerId);
            List<Sale> sales = query.getResultList();

            if (sales.isEmpty()) {
                System.out.println("Цей продавець не має продажів!");
            } else {
                Seller seller = session.get(Seller.class, sellerId);
                System.out.println("\n=== ПРОДАЖІ ПРОДАВЦЯ: " + seller.getName() + " ===");
                sales.forEach(sale -> {
                    System.out.printf("Дата: %s | Покупець: %s | Товар: %s | Ціна: %.2f%n",
                            sale.getSaleDate().format(dateFormatter),
                            sale.getBuyer().getName(),
                            sale.getProduct().getName(),
                            sale.getPrice()
                    );
                });

                double sellerTotal = sales.stream().mapToDouble(Sale::getPrice).sum();
                System.out.printf("Загальна сума продажів: %.2f (кількість: %d)%n", sellerTotal, sales.size());
            }
        }
    }

    /**
     * Відображає інформацію про транзакції конкретного покупця.
     */
    public void displaySalesByBuyer() {
        displayAllBuyers();
        System.out.print("Введіть ID покупця: ");
        Long buyerId = scanner.nextLong();

        try (Session session = getSession()) {
            Query<Sale> query = session.createQuery(
                    "FROM Sale s WHERE s.buyer.id = :buyerId ORDER BY s.saleDate DESC",
                    Sale.class
            );
            query.setParameter("buyerId", buyerId);
            List<Sale> sales = query.getResultList();

            if (sales.isEmpty()) {
                System.out.println("Цей покупець не має покупок!");
            } else {
                Buyer buyer = session.get(Buyer.class, buyerId);
                System.out.println("\n=== ПОКУПКИ ПОКУПЦЯ: " + buyer.getName() + " ===");
                sales.forEach(sale -> {
                    System.out.printf("Дата: %s | Продавець: %s | Товар: %s | Ціна: %.2f%n",
                            sale.getSaleDate().format(dateFormatter),
                            sale.getSeller().getName(),
                            sale.getProduct().getName(),
                            sale.getPrice()
                    );
                });

                double buyerTotal = sales.stream().mapToDouble(Sale::getPrice).sum();
                System.out.printf("Загальна сума покупок: %.2f (кількість: %d)%n", buyerTotal, sales.size());
            }
        }
    }

    /**
     * Відображає найуспішнішого продавця (за максимальною сумою продажів).
     */
    public void displayTopSeller() {
        try (Session session = getSession()) {
            Query<Object[]> query = session.createQuery(
                    "SELECT s.seller, SUM(s.price) as total " +
                            "FROM Sale s " +
                            "GROUP BY s.seller " +
                            "ORDER BY total DESC",
                    Object[].class
            );
            query.setMaxResults(1);

            List<Object[]> result = query.getResultList();

            if (result.isEmpty()) {
                System.out.println("Немає даних про продажі!");
            } else {
                Object[] row = result.get(0);
                Seller seller = (Seller) row[0];
                Double totalSales = (Double) row[1];

                System.out.println("\n=== НАЙУСПІШНІШИЙ ПРОДАВЕЦЬ ===");
                System.out.println("Продавець: " + seller.getName());
                System.out.println("Загальна сума продажів: " + String.format("%.2f", totalSales));
                System.out.println("Контакти: " + seller.getPhone() + " | " + seller.getEmail());
            }
        }
    }

    /**
     * Відображає найуспішнішого покупця (за максимальною сумою покупок).
     */
    public void displayTopBuyer() {
        try (Session session = getSession()) {
            Query<Object[]> query = session.createQuery(
                    "SELECT s.buyer, SUM(s.price) as total " +
                            "FROM Sale s " +
                            "GROUP BY s.buyer " +
                            "ORDER BY total DESC",
                    Object[].class
            );
            query.setMaxResults(1);

            List<Object[]> result = query.getResultList();

            if (result.isEmpty()) {
                System.out.println("Немає даних про покупки!");
            } else {
                Object[] row = result.get(0);
                Buyer buyer = (Buyer) row[0];
                Double totalPurchases = (Double) row[1];

                System.out.println("\n=== НАЙУСПІШНІШИЙ ПОКУПЕЦЬ ===");
                System.out.println("Покупець: " + buyer.getName());
                System.out.println("Загальна сума покупок: " + String.format("%.2f", totalPurchases));
                System.out.println("Контакти: " + buyer.getPhone() + " | " + buyer.getEmail());
            }
        }
    }

    /**
     * Відображає середню суму покупки.
     */
    public void displayAverageSaleAmount() {
        try (Session session = getSession()) {
            Query<Double> query = session.createQuery(
                    "SELECT AVG(s.price) FROM Sale s",
                    Double.class
            );
            Double average = query.getSingleResult();

            System.out.println("\n=== СЕРЕДНЯ СУМА ПОКУПКИ ===");
            if (average != null) {
                System.out.println("Середня сума покупки: " + String.format("%.2f", average));
            } else {
                System.out.println("Немає даних для розрахунку середньої суми!");
            }
        }
    }

    /**
     * Відображає найпопулярніший товар (за кількістю продажів).
     */
    public void displayMostPopularProduct() {
        try (Session session = getSession()) {
            Query<Object[]> query = session.createQuery(
                    "SELECT s.product, COUNT(s) as salesCount " +
                            "FROM Sale s " +
                            "GROUP BY s.product " +
                            "ORDER BY salesCount DESC",
                    Object[].class
            );
            query.setMaxResults(1);

            List<Object[]> result = query.getResultList();

            if (result.isEmpty()) {
                System.out.println("Немає даних про продажі товарів!");
            } else {
                Object[] row = result.get(0);
                Product product = (Product) row[0];
                Long salesCount = (Long) row[1];

                System.out.println("\n=== НАЙПОПУЛЯРНІШИЙ ТОВАР ===");
                System.out.println("Товар: " + product.getName());
                System.out.println("Кількість продажів: " + salesCount);

                // Додаткова інформація: загальна сума продажів цього товару
                Query<Double> totalQuery = session.createQuery(
                        "SELECT SUM(s.price) FROM Sale s WHERE s.product.id = :productId",
                        Double.class
                );
                totalQuery.setParameter("productId", product.getId());
                Double totalAmount = totalQuery.getSingleResult();

                if (totalAmount != null) {
                    System.out.println("Загальна сума продажів цього товару: " + String.format("%.2f", totalAmount));
                }
            }
        }
    }
}