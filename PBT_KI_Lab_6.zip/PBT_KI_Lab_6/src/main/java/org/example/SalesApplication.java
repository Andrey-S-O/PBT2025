package org.example;

import org.example.database.DatabaseManager;

import java.util.Scanner;

/**
 * Головний клас програми для роботи з базою даних продажів.
 * Надає користувацький інтерфейс для взаємодії з системою.
 */
public class SalesApplication {

    public static void main(String[] args) {
        System.out.println(" ЗАПУСК ПРОГРАМИ ДЛЯ РОБОТИ З БАЗОЮ ДАНИХ 'SALES'");
        System.out.println("===================================================\n");

        DatabaseManager dbManager = new DatabaseManager();
        Scanner scanner = new Scanner(System.in);

        try {
            // Підключення до бази даних
            dbManager.connect();

            boolean running = true;

            while (running) {
                displayMenu();
                System.out.print("\n Виберіть опцію: ");

                try {
                    int choice = scanner.nextInt();
                    scanner.nextLine(); // Очистка буфера

                    switch (choice) {
                        case 1 -> dbManager.addRecord();
                        case 2 -> dbManager.deleteRecord();
                        case 3 -> dbManager.updateRecord();
                        case 4 -> dbManager.displayAllSellers();
                        case 5 -> dbManager.displayAllBuyers();
                        case 6 -> dbManager.displayAllProducts();
                        case 7 -> dbManager.displayAllSales();
                        case 8 -> dbManager.displaySalesByDate();
                        case 9 -> dbManager.displaySalesByDateRange();
                        case 10 -> dbManager.displaySalesBySeller();
                        case 11 -> dbManager.displaySalesByBuyer();
                        case 12 -> dbManager.displayTopSeller();
                        case 13 -> dbManager.displayTopBuyer();
                        case 14 -> dbManager.displayAverageSaleAmount();
                        case 15 -> dbManager.displayMostPopularProduct();
                        case 0 -> {
                            System.out.println("\n Завершення роботи програми...");
                            running = false;
                        }
                        default -> System.out.println("Невірний вибір! Спробуйте ще раз.");
                    }

                    System.out.println("\n Натисніть Enter для продовження...");
                    scanner.nextLine();

                } catch (Exception e) {
                    System.err.println("Помилка: " + e.getMessage());
                    scanner.nextLine(); // Очистка буфера після помилки
                }
            }

        } catch (Exception e) {
            System.err.println("Критична помилка: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Відключення від бази даних
            dbManager.disconnect();
            scanner.close();
            System.out.println("Програму завершено.");
        }
    }

    /**
     * Відображає головне меню програми.
     */
    private static void displayMenu() {
        System.out.println("\n=== ГОЛОВНЕ МЕНЮ ===");
        System.out.println("=== ОСНОВНІ ОПЕРАЦІЇ ===");
        System.out.println("1. Додати новий запис");
        System.out.println("2. Видалити запис");
        System.out.println("3. Оновити запис");

        System.out.println("\n=== ПЕРЕГЛЯД ДАНИХ ===");
        System.out.println("4. Показати всіх продавців");
        System.out.println("5. Показати всіх покупців");
        System.out.println("6. Показати всі товари");
        System.out.println("7. Показати всі транзакції");

        System.out.println("\n=== АНАЛІТИКА ТА ЗВІТИ ===");
        System.out.println("8. Продажі за конкретну дату");
        System.out.println("9. Продажі за діапазон дат");
        System.out.println("10. Продажі конкретного продавця");
        System.out.println("11. Покупки конкретного покупця");
        System.out.println("12. Найуспішніший продавець");
        System.out.println("13. Найуспішніший покупець");
        System.out.println("14. Середня сума покупки");
        System.out.println("15. Найпопулярніший товар");

        System.out.println("\n0. 🚪 Вийти з програми");
    }
}