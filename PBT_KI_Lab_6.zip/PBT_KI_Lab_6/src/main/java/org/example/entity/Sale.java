package org.example.entity;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * Суть "Продаж" представляє інформацію про транзакцію продажу.
 * Зв'язує продавця, покупця та товар.
 */
@Entity
@Table(name = "sales")
public class Sale {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "sale_id")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "seller_id", nullable = false)
    private Seller seller;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "buyer_id", nullable = false)
    private Buyer buyer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;

    @Column(name = "price", nullable = false)
    private Double price;

    @Column(name = "sale_date", nullable = false)
    private LocalDateTime saleDate;

    // Конструктори
    public Sale() {
        // Потрібен для Hibernate
    }

    public Sale(Seller seller, Buyer buyer, Product product, Double price, LocalDateTime saleDate) {
        this.seller = seller;
        this.buyer = buyer;
        this.product = product;
        this.price = price;
        this.saleDate = saleDate;
    }

    // Гетери та сетери
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Seller getSeller() {
        return seller;
    }

    public void setSeller(Seller seller) {
        this.seller = seller;
    }

    public Buyer getBuyer() {
        return buyer;
    }

    public void setBuyer(Buyer buyer) {
        this.buyer = buyer;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public LocalDateTime getSaleDate() {
        return saleDate;
    }

    public void setSaleDate(LocalDateTime saleDate) {
        this.saleDate = saleDate;
    }

    @Override
    public String toString() {
        return String.format("Продаж [ID: %d, Продавець: %s, Покупець: %s, Товар: %s, Ціна: %.2f, Дата: %s]",
                id, seller.getName(), buyer.getName(), product.getName(), price, saleDate);
    }
}