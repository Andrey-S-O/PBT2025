package org.example.entity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Суть "Покупець" представляє інформацію про покупця у системі.
 * Містить особисту інформацію та список покупок.
 */
@Entity
@Table(name = "buyers")
public class Buyer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "buyer_id")
    private Long id;

    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @Column(name = "phone", length = 20)
    private String phone;

    @Column(name = "email", length = 100)
    private String email;

    @OneToMany(mappedBy = "buyer", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Sale> purchases = new ArrayList<>();

    // Конструктори
    public Buyer() {
        // Потрібен для Hibernate
    }

    public Buyer(String name, String phone, String email) {
        this.name = name;
        this.phone = phone;
        this.email = email;
    }

    // Гетери та сетери
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<Sale> getPurchases() {
        return purchases;
    }

    public void setPurchases(List<Sale> purchases) {
        this.purchases = purchases;
    }

    // Метод для додавання покупки
    public void addPurchase(Sale sale) {
        purchases.add(sale);
        sale.setBuyer(this);
    }

    @Override
    public String toString() {
        return String.format("Покупець [ID: %d, Ім'я: %s, Телефон: %s, Email: %s]",
                id, name, phone, email);
    }
}