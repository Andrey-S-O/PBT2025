package org.example.entity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Суть "Продавець" представляє інформацію про продавця у системі.
 * Містить особисту інформацію та список продажів.
 */
@Entity
@Table(name = "sellers")
public class Seller {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "seller_id")
    private Long id;

    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @Column(name = "phone", length = 20)
    private String phone;

    @Column(name = "email", length = 100)
    private String email;

    @OneToMany(mappedBy = "seller", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Sale> sales = new ArrayList<>();

    // Конструктори
    public Seller() {
        // Потрібен для Hibernate
    }

    public Seller(String name, String phone, String email) {
        this.name = name;
        this.phone = phone;
        this.email = email;
    }

    // Гетери та сетери
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<Sale> getSales() {
        return sales;
    }

    public void setSales(List<Sale> sales) {
        this.sales = sales;
    }

    // Метод для додавання продажу
    public void addSale(Sale sale) {
        sales.add(sale);
        sale.setSeller(this);
    }

    @Override
    public String toString() {
        return String.format("Продавець [ID: %d, Ім'я: %s, Телефон: %s, Email: %s]",
                id, name, phone, email);
    }
}