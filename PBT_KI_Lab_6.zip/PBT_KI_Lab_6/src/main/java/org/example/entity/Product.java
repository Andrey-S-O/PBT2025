package org.example.entity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Суть "Товар" представляє інформацію про товар у системі.
 * Містить назву товару та список продажів цього товару.
 */
@Entity
@Table(name = "products")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "product_id")
    private Long id;

    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Sale> sales = new ArrayList<>();

    // Конструктори
    public Product() {
        // Потрібен для Hibernate
    }

    public Product(String name) {
        this.name = name;
    }

    // Гетери та сетери
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Sale> getSales() {
        return sales;
    }

    public void setSales(List<Sale> sales) {
        this.sales = sales;
    }

    // Метод для додавання продажу
    public void addSale(Sale sale) {
        sales.add(sale);
        sale.setProduct(this);
    }

    @Override
    public String toString() {
        return String.format("Товар [ID: %d, Назва: %s]", id, name);
    }
}